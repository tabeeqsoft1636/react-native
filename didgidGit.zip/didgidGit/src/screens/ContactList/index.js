/* eslint-disable react-hooks/exhaustive-deps */
import React, {Component, useState, useRef, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
  ActivityIndicator,
} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';
import DropdownAlert from 'react-native-dropdownalert';
import ListItem from '../../components/ListItem';
import {syncContactData} from 'theme/apiCalls';
function contactList(props) {
  let dropDownAlertRef = useRef();
  let [contacts, setContacts] = useState([]);
  let [searchContacts, setSearchContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [phoneData, setPhoneData] = useState([]);

  const inviteFriends = async () => {
    let formData = new FormData();

    formData.append('profile', 'Personal');

    phoneData.map((item, index) => {
      const no = item.phoneNumbers[0].number;
      formData.append(`contacts[${index}]phone`, no);
    });

    try {
      syncContactData(formData, res => {
        if (res.sucess) {
          props.navigation.navigate('MainAllContacts');
          dropDownAlertRef.alertWithType('sucess', 'Success', res);
        } else {
          dropDownAlertRef.alertWithType('error', 'Error', res.error);
        }
      });
    } catch (error) {
      dropDownAlertRef.alertWithType('error', 'Error', error);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    const {contacts: con} = props.route.params;
    setContacts(con);
    setSearchContacts(con);
    setIsLoading(false);
  }, []);

  const search = text => {
    if (text) {
      const con = contacts.filter(
        item =>
          item.phoneNumbers[0].number.includes(text) ||
          item.displayName.includes(text),
      );
      setSearchContacts(con);
    } else {
      setSearchContacts(contacts);
    }
  };
  const selectContact = contact => {
    let obj = phoneData;
    var index = obj.findIndex(x => x.recordID === contact.recordID);
    index === -1 ? obj.push(contact) : obj.splice(index, 1);
    setPhoneData([...obj]);
  };
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={{marginTop: 15}}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('../../../assets/images/right.png')}
            />
          </TouchableOpacity>
          <Text style={styles.syncedTitle}>Synced Contacts</Text>
          <TouchableOpacity
            style={styles.categotyTouch}
            onPress={() => alert('In Progress')}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('../../../assets/images/category.png')}
            />
          </TouchableOpacity>
        </View>
        <View style={{marginTop: '7%'}}>
          <Text style={styles.allContacts}>All Contacts</Text>
        </View>
        <View style={styles.inputView}>
          <Image
            resizeMode="contain"
            style={{width: 18, height: 18, marginLeft: 10}}
            source={require('../../../assets/images/search.png')}
          />
          <TextInput
            style={styles.textInputStyle}
            onChangeText={search}
            placeholder="Search Contacts Here"
            placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
          />
        </View>
        {isLoading ? (
          <View style={[styles.Loadercontainer, styles.Loaderhorizontal]}>
            <ActivityIndicator size="large" color={'#fff'} />
          </View>
        ) : (
          <View style={styles.flatListView}>
            <FlatList
              data={searchContacts}
              renderItem={contact => {
                return (
                  <View>
                    <ListItem
                      key={contact.item.recordID}
                      item={contact.item}
                      onPress={selectContact}
                      phoneData={phoneData}
                    />
                  </View>
                );
              }}
              keyExtractor={item => item.recordID}
            />

            <View
              style={{
                bottom: 10,
                backgroundColor: '#000',
              }}>
              <TouchableOpacity onPress={inviteFriends} style={styles.btnView}>
                <Text style={styles.btnText}>Invite Friends</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 20,
    marginTop: '12%',
  },
  imageView: {
    // marginBottom: 17,
    // alignSelf: "center"
  },
  syncedTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    textAlign: 'center',
    alignSelf: 'center',
    marginTop: 10,
  },
  categotyTouch: {
    marginTop: 15,
    backgroundColor: ' rgba(255, 255, 255, 0.4)',
    width: '11%',
    borderRadius: 10,
    alignSelf: 'center',
    padding: 8,
  },
  allContacts: {
    color: '#fff',
    fontSize: 18,
    marginLeft: '5%',
    fontWeight: '600',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },
  flatListView: {flex: 1, marginTop: '2%'},
  header: {
    backgroundColor: '#4591ed',
    color: 'white',
    paddingHorizontal: 15,
    paddingVertical: 15,
    fontSize: 20,
  },
  searchBar: {
    backgroundColor: '#f0eded',
    paddingHorizontal: 30,
    paddingVertical: Platform.OS === 'android' ? undefined : 15,
  },
  inputView: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#757374',
    borderRadius: 10,
    width: '93%',
    alignSelf: 'center',
    marginTop: '4%',
    marginBottom: 10,
  },
  textInputStyle: {
    backgroundColor: '#757374',
    width: '87%',
    textAlign: 'center',
    color: '#fff',
    borderRadius: 10,
    fontSize: 14,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '93%',
    marginTop: '2%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
});
export default contactList;
