//import liraries
import React, {useState, useEffect} from 'react';
import {
  View,
  StyleSheet,
  SafeAreaView,
  FlatList,
  ActivityIndicator,
  Platform,
} from 'react-native';

import ListItem from 'components/InvitesList';
import {receivedInvitesAPI} from 'theme/apiCalls';
function Invites(props) {
  const [isLoading, setIsLoading] = useState(false);
  const [receiveData, setReceiveData] = useState([]);
  useEffect(() => {
    const unsubscribe = props.navigation.addListener('focus', () => {
      InvitesList();
    });
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const InvitesList = () => {
    setIsLoading(true);
    try {
      receivedInvitesAPI(res => {
        if (res.sucess) {
          setReceiveData(res.sucess);
        }
        setIsLoading(false);
      });
    } catch (error) {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        {isLoading ? (
          <View style={[styles.Loadercontainer, styles.Loaderhorizontal]}>
            <ActivityIndicator size="large" color={'#fff'} />
          </View>
        ) : (
          <View style={styles.flatListView}>
            <FlatList
              data={receiveData}
              renderItem={item => {
                return (
                  <View>
                    <ListItem
                      key={item.id}
                      item={item}
                      navigation={props.navigation}
                      InvitesList={InvitesList}
                    />
                  </View>
                );
              }}
              keyExtractor={item => item.recordID}
            />
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  headerView: {flexDirection: 'row', marginHorizontal: 20, marginTop: '12%'},
  imageView: {
    // marginBottom: 17,
    // alignSelf: "center"
  },
  syncedTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    textAlign: 'center',
    alignSelf: 'center',
    marginTop: 10,
  },
  requestView: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 5,
    marginLeft: -30,
  },
  categotyTouch: {
    marginTop: 15,
    backgroundColor: ' rgba(255, 255, 255, 0.4)',
    width: '11%',
    borderRadius: 10,
    alignSelf: 'center',
    padding: 8,
  },
  allContacts: {
    color: '#fff',
    fontSize: 13,
    marginLeft: '5%',
    fontWeight: '600',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },
  allContactsView: {marginTop: '10%', marginLeft: 10, flexDirection: 'row'},
  flatListView: {flex: 1, marginTop: '6%'},
  header: {
    backgroundColor: '#4591ed',
    color: 'white',
    paddingHorizontal: 15,
    paddingVertical: 15,
    fontSize: 20,
  },
  searchBar: {
    backgroundColor: '#f0eded',
    paddingHorizontal: 30,
    paddingVertical: Platform.OS === 'android' ? undefined : 15,
  },
  inputView: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#757374',
    borderRadius: 10,
    width: '93%',
    alignSelf: 'center',
    marginTop: '4%',
    marginBottom: 10,
  },
  textInputStyle: {
    backgroundColor: '#757374',
    width: '87%',
    textAlign: 'center',
    color: '#fff',
    borderRadius: 10,
    fontSize: 14,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '93%',
    marginTop: '2%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
});
export default Invites;
