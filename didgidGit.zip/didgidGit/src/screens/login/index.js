/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState, useRef} from 'react';
import {
  View,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Platform,
} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';

import {Text} from 'react-native-paper';
import DropdownAlert from 'react-native-dropdownalert';

import {
  Container,
  MainContainer,
  Wrapper,
  LogoImage,
  ImageWrapper,
  TextWrapper,
  DescriptionText,
  DescriptionText2,
  TextinputWrapper,
  TextinputView,
  InputText,
  ForgetText,
  LoginBtn,
} from './style';
import {expressions} from '../../utils/functions';
import {LoginApi} from 'theme/apiCalls';
// import { TextInput } from 'react-native-paper';
// create a component
function loginScreen(props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  let dropDownAlertRef = useRef();

  const validation = () => {
    let valid = true;
    if (email === '') {
      console.log('true');
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Email');
    } else if (!expressions.email.test(email) || email.includes(' ')) {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Valid Email');
    } else if (password === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Password');
    } else {
      return valid;
    }
  };

  const apiCall = async () => {
    let valid = validation();
    if (valid) {
      const userDetail = {
        email: email,
        password: password,
      };
      try {
        LoginApi(userDetail, async res => {
          if (res.sucess) {
            await AsyncStorage.setItem(
              '@loginInfo',
              JSON.stringify(res.sucess.user),
            );
            await AsyncStorage.setItem(
              'token',
              JSON.stringify(res.sucess.token),
            );
            dropDownAlertRef.alertWithType(
              'error',
              'Error',
              'Successfully Login',
            );
            props.navigation.navigate('MainAllContacts');
          } else {
            dropDownAlertRef.alertWithType('error', 'Error', res.error);
          }
        });
      } catch (error) {
        if (error.res) {
          console.log(error.res.data);
          dropDownAlertRef.alertWithType(
            'error',
            'Error',
            error.res.data.detail,
          );
        } else {
          // Something happened in setting up the request that triggered an Error
          console.log('Error', error.message);
        }
      }
    }

    // dropDownAlertRef.alertWithType('success', 'Success', 'Login Success');
  };
  return (
    <MainContainer>
      {/*
          <Header title='LOGIN' navigation={this.props.navigation} />
        */}
      <SafeAreaView />
      <Container behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <Wrapper>
          <ImageWrapper>
            <LogoImage
              resizeMode="contain"
              //   style={styles.logoStyle}
              source={require('../../assets/images/logo.png')}
            />
          </ImageWrapper>
          <TextWrapper>
            <DescriptionText allowFontScaling={false}>
              Please Log In To Your Account.
            </DescriptionText>
            <DescriptionText2 allowFontScaling={false}>
              Use your personal email to log into your account.
            </DescriptionText2>
          </TextWrapper>
          <TextinputWrapper>
            <TextinputView>
              <Image
                style={{width: 20, height: 20, marginLeft: '2%'}}
                source={require('../../assets/images/Message.png')}
              />
              <InputText
                onChangeText={text => setEmail(text)}
                placeholder="Type Your Email"
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </TextinputView>
            <TextinputView>
              <Image
                style={{width: 17, height: 19, marginLeft: '2%'}}
                source={require('../../assets/images/Lock.png')}
              />
              <InputText
                onChangeText={text => setPassword(text)}
                placeholder="Type Your Password"
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
                secureTextEntry={true}
              />
            </TextinputView>
            <TouchableOpacity
              onPress={() => props.navigation.navigate('otpScreen')}>
              <ForgetText allowFontScaling={false}>Forgot Password</ForgetText>
            </TouchableOpacity>
          </TextinputWrapper>

          <LoginBtn onPress={() => apiCall()}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Sign In
            </Text>
          </LoginBtn>
        </Wrapper>
        <DropdownAlert
          ref={ref => {
            dropDownAlertRef = ref;
          }}
        />
        <View style={{flexDirection: 'row', justifyContent: 'center'}}>
          <Text allowFontScaling={false} style={{color: 'white', fontSize: 10}}>
            Don't Have Any Account?{' '}
          </Text>
          <TouchableOpacity
            onPress={() => props.navigation.navigate('SignUpScreen')}>
            <Text
              allowFontScaling={false}
              style={{color: '#F5365B', fontSize: 10}}>
              Sign Up
            </Text>
          </TouchableOpacity>
        </View>
      </Container>
    </MainContainer>
  );
}

//make this component available to the app
export default loginScreen;
