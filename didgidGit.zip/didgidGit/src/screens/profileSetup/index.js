/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState} from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
} from 'react-native';
import styles from './style';
import {business, sideGig, personal} from 'theme/apiCalls';

const data = [
  {
    id: 1,
    name: 'Business',
    image: require('../../../assets/images/business.png'),
    description:
      'Use the Business profile to enter your work information and contacts. Always stay connected regardless of getting a new job or moving to a new company.',
  },
  {
    id: 2,
    name: 'Personal',
    image: require('../../../assets/images/personal.png'),
    description:
      'Use the personal profile for always being connected to your friends and family.',
  },
  {
    id: 3,
    name: 'Side Gig',
    image: require('../../../assets/images/gig.png'),
    description:
      'Have a Side Gig? Set up a profile here for your side business. Keep your contacts in this profile separate from your work or personal contact list.',
  },
];
// create a component
function profileSetup(props) {
  const [profileName, setProfileName] = useState('');

  const _onContinue = async () => {
    if (!profileName) {
      // eslint-disable-next-line no-alert
      alert('Select Profile to Continue');
    } else {
      let apiType = '';
      if (profileName === 'Business') {
        apiType = business;
      }
      if (profileName === 'Personal') {
        apiType = personal;
      }
      if (profileName === 'Side Gig') {
        apiType = sideGig;
      }
      try {
        apiType(res => {
          console.log('api Res', res, typeof res);
          if (res.sucess) {
            props.navigation.navigate('userProfileSetup', {name: profileName});
          } else {
            // eslint-disable-next-line no-alert
            alert(res.error);
          }
        });
      } catch (error) {
        console.log(error);
      }
    }
  };
  return (
    <View style={styles.container}>
      <SafeAreaView />
      <View style={styles.mainContainer}>
        <Text style={styles.profileText}>Profile setup</Text>
        <Text style={styles.profileDesc}>
          Select the profile you wish to set up.
        </Text>
      </View>
      <FlatList
        style={styles.contentList}
        columnWrapperStyle={styles.listContainer}
        data={data}
        keyExtractor={item => {
          return item.id;
        }}
        renderItem={({item}) => {
          return (
            <TouchableOpacity
              style={[
                styles.card,
                profileName === item.name ? styles.border : styles.nonBorder,
              ]}
              onPress={() => {
                setProfileName(item.name);
              }}>
              <View style={styles.imageBackView}>
                <Image
                  resizeMode="contain"
                  style={styles.image}
                  source={item.image}
                />
              </View>

              <View style={styles.cardContent}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.description}>{item.description}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
      <View style={{width: '100%'}}>
        <TouchableOpacity
          onPress={() => {
            _onContinue();
          }}
          style={styles.btnView}>
          <Text style={styles.btnText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

//make this component available to the app
export default profileSetup;
