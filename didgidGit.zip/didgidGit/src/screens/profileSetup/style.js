import {StyleSheet, Platform} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // marginTop:20,
    backgroundColor: 'black',
  },
  profileText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '600',
    fontStyle: 'normal',
    fontSize: 22,
  },
  profileDesc: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 13,
  },
  mainContainer: {
    marginTop: 50,
    flexDirection: 'column',
    marginLeft: 15,
  },
  imageBackView: {
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    borderRadius: 12,
  },
  contentList: {
    flex: 1,
  },
  cardContent: {
    marginLeft: 20,
    marginTop: 10,
    width: '50%',
  },
  image: {
    width: 120,
    // height:120,
    borderRadius: 12,
    marginTop: 6,
  },

  card: {
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginLeft: 20,
    marginRight: 20,
    marginTop: 20,
    backgroundColor: '#2D2D2D',
    paddingTop: 10,
    paddingLeft: 10,
    paddingBottom: 10,
    flexDirection: 'row',
    borderRadius: 12,
  },

  name: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '700',
    fontStyle: 'normal',
    fontSize: 13,
    lineHeight: 28,
  },
  description: {
    color: '#rgba(255, 255, 255, 0.8)',
    fontFamily: 'Rubik-Regular',
    fontWeight: '300',
    fontStyle: 'normal',
    fontSize: 10,
    lineHeight: 15,
  },
  followButton: {
    marginTop: 10,
    height: 35,
    width: 100,
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#dcdcdc',
  },
  followButtonText: {
    color: '#dcdcdc',
    fontSize: 12,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '80%',
    top: Platform.OS === 'ios' ? '-15%' : '-2%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
  border: {
    borderWidth: 1,
    borderColor: 'red',
  },
  back: {
    width: '10%',
  },
});
export default styles;
