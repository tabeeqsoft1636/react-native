//import liraries
import React, {useEffect, useRef, useState} from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

const PERSONAL = 'Personal';
const SIDE_GIG = 'Side Gig';
const BUSINESS = 'Business';

import DropdownAlert from 'react-native-dropdownalert';
import {syncedContacts} from 'theme/apiCalls';
import ListItem from '../../components/MainContact';
function MainAllContacts(props) {
  let dropDownAlertRef = useRef();
  let [contacts, setContacts] = useState([]);
  let [contactType, setContactType] = useState();
  let [searchContacts, setSearchContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = props.navigation.addListener('focus', () => {
      setContacts([]);
      GetContacts();
    });

    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const GetContacts = async type => {
    setIsLoading(true);
    setContactType(type);
    setContacts([]);
    setSearchContacts([]);
    try {
      syncedContacts(res => {
        const data = res.sucess;
        let con = [];
        if (res.sucess.length > 0) {
          data.forEach(obj => {
            for (const [key, value] of Object.entries(obj)) {
              if (value) {
                value.forEach(element => {
                  con.push({...element, profileType: key});
                });
              }
            }
          });
          setContacts(con);
          setSearchContacts(con);
          setIsLoading(false);
        } else {
          setIsLoading(false);
        }
      }, type);
    } catch (error) {
      setIsLoading(false);
      // dropDownAlertRef.alertWithType('error', 'Error', error);
    }
  };

  const search = text => {
    if (text) {
      const con = contacts.filter(item => item.name.includes(text));
      setSearchContacts(con);
    } else {
      setSearchContacts(contacts);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={{}}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.logo}
              source={require('../../../assets/images/logo.png')}
            />
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignSelf: 'center',
          }}>
          <View style={styles.inputView}>
            <Image
              resizeMode="contain"
              style={{width: 18, height: 18, marginLeft: 10}}
              source={require('../../../assets/images/search.png')}
            />
            <TextInput
              style={styles.textInputStyle}
              onChangeText={search}
              placeholder="Search Contacts Here"
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </View>
        </View>
        {isLoading ? (
          <View style={[styles.Loadercontainer, styles.Loaderhorizontal]}>
            <ActivityIndicator size="large" color={'#fff'} />
          </View>
        ) : (
          <>
            <View style={styles.barView}>
              <View style={{flexDirection: 'row'}}>
                <TouchableOpacity onPress={() => GetContacts()}>
                  <Text style={[styles.allContacts]}>All Contacts</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => GetContacts(BUSINESS)}>
                  <Text
                    style={[
                      styles.allContacts,
                      {color: contactType === BUSINESS ? '#FF2D55' : '#fff'},
                    ]}>
                    B
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => GetContacts(PERSONAL)}>
                  <Text
                    style={[
                      styles.allContacts,
                      {color: contactType === PERSONAL ? '#FF2D55' : '#fff'},
                    ]}>
                    P
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => GetContacts(SIDE_GIG)}>
                  <Text
                    style={[
                      styles.allContacts,
                      {color: contactType === SIDE_GIG ? '#FF2D55' : '#fff'},
                    ]}>
                    G
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.flatListView}>
              <FlatList
                data={searchContacts}
                renderItem={item => {
                  return (
                    <View>
                      <ListItem
                        key={item.id}
                        item={item}
                        contactType={contactType}
                      />
                    </View>
                  );
                }}
                keyExtractor={item => item.id}
              />
            </View>
          </>
        )}
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 10,
    marginTop: '10%',
  },
  logo: {
    width: 170,
    height: 90,
  },
  syncedTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    textAlign: 'center',
    alignSelf: 'center',
    marginTop: 10,
  },
  categotyTouch: {
    backgroundColor: ' rgba(255, 255, 255, 0.4)',
    width: '14%',
    borderRadius: 10,
    alignSelf: 'center',
    padding: 18,
  },

  alarm: {
    backgroundColor: 'rgba(255, 255, 255, 0.4)',
    marginLeft: 10,
    width: '13%',
    borderRadius: 10,
    alignSelf: 'center',
    padding: 18,
    marginTop: -10,
  },
  flatListView: {flex: 1, marginTop: '2%'},
  header: {
    backgroundColor: '#4591ed',
    color: 'white',
    paddingHorizontal: 15,
    paddingVertical: 15,
    fontSize: 20,
  },
  searchBar: {
    backgroundColor: '#f0eded',
    // paddingHorizontal: 30,
    paddingVertical: Platform.OS === 'android' ? undefined : 15,
  },
  inputView: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#757374',
    borderRadius: 10,
    width: '95%',
    alignSelf: 'center',

    marginBottom: 10,
    justifyContent: 'center',
  },
  textInputStyle: {
    backgroundColor: '#757374',
    width: '87%',
    textAlign: 'center',
    color: '#fff',
    borderRadius: 10,
    fontSize: 14,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '93%',
    marginTop: '2%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
  viewStyle: {
    borderColor: '#FF2D55',
    borderWidth: 2,
    borderRadius: 30,
    width: '50%',
    alignSelf: 'center',
    right: 5,
  },

  allContacts: {
    color: '#FF2D55',
    fontSize: 13,
    fontWeight: '600',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    marginRight: 10,
  },

  barView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
    marginBottom: 15,
    marginHorizontal: 20,
  },
  groupText: {
    color: 'rgba(255, 255, 255, 0.4)',
    fontSize: 13,
    fontWeight: '500',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    paddingBottom: 4,
  },
});
export default MainAllContacts;
