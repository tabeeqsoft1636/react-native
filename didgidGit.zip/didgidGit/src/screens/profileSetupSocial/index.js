/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState, useRef, useEffect} from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  SafeAreaView,
  Platform,
} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';
import styles from './style';
import {ProgressBar} from 'react-native-paper';
import {businessPatch, personalPtach, sidegigPatch} from 'theme/apiCalls';
import DropdownAlert from 'react-native-dropdownalert';
function userProfileSetup(props) {
  const {
    profileTitle,
    profileData,
    ImageData,
    userData: userInfo = null,
  } = props.route.params;

  const [linksData, setLinksData] = useState({});
  let dropDownAlertRef = useRef();

  useEffect(() => {
    if (profileData?.id) {
      setLinksData({
        facebook_link: profileData?.facebook_link || '',
        instagram_link: profileData?.instagram_link || '',
        linkedin_link: profileData?.linkedin_link || '',
        twitter_link: profileData?.twitter_link || '',
        social_link: profileData?.social_link || '',
      });
    }
  }, [profileData]);

  const next = async () => {
    if (Object.entries(linksData).length < 5) {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Please Enter all Detail',
      );
      // alert('');
    } else {
      apiCall();
    }
  };

  const apiCall = async () => {
    const userData = await AsyncStorage.getItem('@loginInfo');
    const parsedData = await JSON.parse(userData);
    let getId = parsedData.id;

    let profileType = '';
    let patch = () => {};
    if (profileTitle === 'Business') {
      profileType = 'business';
      patch = businessPatch;
    } else if (profileTitle === 'Personal') {
      profileType = 'personal';
      patch = personalPtach;
    } else if (profileTitle === 'Side Gig') {
      profileType = 'sidegig';
      patch = sidegigPatch;
    }

    let formData = new FormData();

    formData.append([profileType + '.name'], profileData.name || null);
    formData.append([profileType + '.title'], profileData.title || null);
    formData.append([profileType + '.street_1'], profileData.street_1 || null);
    formData.append([profileType + '.city'], profileData.city || null);
    formData.append([profileType + '.zip_code'], profileData.zip_code || null);
    formData.append([profileType + '.country'], profileData.country || null);

    if (profileTitle === 'Personal') {
      formData.append('email', profileData.email || null);
      formData.append('phone', profileData.phone || null);
    } else {
      formData.append([profileType + '.email'], profileData.email || null);
      formData.append([profileType + '.phone'], profileData.phone || null);
    }

    formData.append(
      [profileType + '.facebook_link'],
      linksData.facebook_link || null,
    );

    formData.append(
      [profileType + '.instagram_link'],
      linksData.instagram_link || null,
    );

    formData.append(
      [profileType + '.linkedin_link'],
      linksData.linkedin_link || null,
    );

    formData.append(
      [profileType + '.twitter_link'],
      linksData.twitter_link || null,
    );

    formData.append(
      [profileType + '.social_link'],
      linksData.social_link || null,
    );

    if (ImageData) {
      const imgObj = {
        uri: ImageData.path,
        type: ImageData.mime,
        name: `${new Date()}.jpg`,
      };
      const name = `${profileType}.image`;
      formData.append(name, imgObj);
    }

    try {
      patch(formData, getId, async res => {
        if (res.sucess) {
          await AsyncStorage.setItem('@loginInfo', JSON.stringify(res.sucess));
          if (profileData?.id) {
            if (profileData?.email !== userInfo?.email) {
              props.navigation.navigate('profileVerifyOtp', {
                profileTitle,
                email: profileData.email,
                isPhoneChanged: profileData.phone !== userInfo.phone,
              });
            } else if (profileData?.phone !== userInfo?.phone) {
              props.navigation.navigate('numberOtpVerify', {
                name: profileTitle,
                redirectTo: 'MainAllContacts',
              });
            } else {
              dropDownAlertRef.alertWithType(
                'success',
                'Success',
                'Record updated successfully',
              );
              setTimeout(() => {
                props.navigation.navigate('MainAllContacts');
              }, 500);
            }
          } else {
            props.navigation.navigate('profileVerifyOtp', {
              profileTitle,
              email: profileData.email,
              isPhoneChanged: true,
            });
          }
        } else {
          dropDownAlertRef.alertWithType('error', 'Error', res.error);
        }
      });
    } catch (error) {
      dropDownAlertRef.alertWithType('error', 'Error', error);
    }
  };

  const updateLinks = (name, value) => {
    const obj = linksData;
    obj[name] = value;
    setLinksData(obj);
  };
  return (
    <View style={styles.container}>
      <View style={styles.container}>
        <SafeAreaView />
        <View style={styles.mainContainer}>
          <TouchableOpacity
            style={styles.back}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('../../../assets/images/right.png')}
            />
          </TouchableOpacity>
          <Text style={styles.profileText}>{`${profileTitle} Details`}</Text>
          <Text style={styles.profileDesc}>
            You Can Edit & Update The Information Later On From Settings As Well{' '}
          </Text>
        </View>

        <ScrollView>
          <View style={{top: '3%', width: '90%', alignSelf: 'center'}}>
            <ProgressBar progress={0.7} color={'#009360'} />
          </View>

          <View style={styles.mainInput}>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginRight: '4%'}}
                source={require('../../../assets/images/link.png')}
              />
              <TextInput
                placeholder="Facebook Link"
                multiline={true}
                defaultValue={profileData?.facebook_link || ''}
                style={styles.textInputStyle}
                onChangeText={text => updateLinks('facebook_link', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginRight: '4%'}}
                source={require('../../../assets/images/link.png')}
              />
              <TextInput
                placeholder="Instagram Link"
                multiline={true}
                style={styles.textInputStyle}
                defaultValue={profileData?.instagram_link || ''}
                onChangeText={text => updateLinks('instagram_link', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginRight: '4%'}}
                source={require('../../../assets/images/link.png')}
              />
              <TextInput
                placeholder="Linkedin Link"
                multiline={true}
                style={styles.textInputStyle}
                defaultValue={profileData?.linkedin_link || ''}
                onChangeText={text => updateLinks('linkedin_link', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginRight: '4%'}}
                source={require('../../../assets/images/link.png')}
              />
              <TextInput
                placeholder="Twitter Link"
                multiline={true}
                style={styles.textInputStyle}
                defaultValue={profileData?.twitter_link || ''}
                onChangeText={text => updateLinks('twitter_link', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginRight: '4%'}}
                source={require('../../../assets/images/link.png')}
              />
              <TextInput
                placeholder="Social Media Link (if any)"
                multiline={true}
                style={styles.textInputStyle}
                defaultValue={profileData?.social_link || ''}
                onChangeText={text => updateLinks('social_link', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
          </View>
          <View
            style={{
              paddingVertical: 10,
              marginBottom: Platform.OS === 'ios' ? 20 : 0,
            }}>
            <TouchableOpacity
              onPress={() => {
                next();
              }}
              style={styles.btnView}>
              <Text style={styles.btnText}>Continue</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                apiCall();
              }}
              style={styles.btnViewSkip}>
              <Text style={styles.btnTextSkip}>Skip</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </View>
  );
}

//make this component available to the app
export default userProfileSetup;
