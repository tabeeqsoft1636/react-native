import { StyleSheet, Dimensions } from "react-native"
import { color } from "react-native-reanimated"

const { width, height } = Dimensions.get("window")

const guidelineBaseWidth = 350
const guidelineBaseHeight = 680

const scale = size => (width / guidelineBaseWidth) * size
const scaleVertical = size => (height / guidelineBaseHeight) * size

const styles = StyleSheet.create({
  container:{
    flex:1,
    // marginTop:20,
    backgroundColor:"black"
  },
  mainContainer: {
    marginTop:"8%",
    flexDirection:"column",
    marginLeft:15,
    // flex:1
  },
  imageView: {
    marginBottom:17
  },
  profileText: {
    color: "#FFFFFF",
    fontFamily:"Rubik-Regular",
    fontWeight:"600",
    fontStyle:"normal",
    fontSize:22,
  },
  profileDesc: {
    color: "#FFFFFF",
    fontFamily:"Rubik-Regular",
    fontWeight:"400",
    fontStyle:"normal",
    fontSize: 13,
  },
 
  imageBackView: {
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    borderRadius: 12,
  },
  contentList:{
    flex:1,
  },
  cardContent: {
    marginLeft:20,
    marginTop:10,
    width:"60%"
  },
  image:{
    width:120,
    // height:120,
    borderRadius:12,
    marginTop:6
  },

  inputView: {
    flexDirection: "row-reverse",
    alignItems:"center",
    height:55,
    backgroundColor:"#2d2d2d",
    borderRadius: 10,
    width:"93%",
    alignSelf:"center",
    marginTop:"6%"
  },
  textInputStyle: {
    backgroundColor: "#2d2d2d",
    width: "89%",
    textAlign: "center",
    color: "#fff",
    borderRadius: 10,
    fontSize: 14,
  },
  inputView1: {
    flexDirection: "row",
    alignItems:"center",
    height:55,
    backgroundColor:"#2d2d2d",
    borderRadius: 10,
    width:"45%",
    alignSelf:"center",
    marginTop:"6%"
  },
  textInputStyle1: {
    backgroundColor: "#2d2d2d",
    width: "45%",
    textAlign: "center",
    color: "#fff",
    borderRadius: 10,
    fontSize: 14,
  },
  mainInput: {
    marginTop:"10%",
    // height:550
  },
  btnView: {
    backgroundColor: "#009360",
    borderRadius: 12,
    width:"80%",
    marginTop:"10%",
    padding:20,
    alignSelf:"center"
  },
  btnText: {
    color: "#FFFFFF",
    fontFamily:"Rubik-Regular",
    fontWeight:"500",
    fontStyle:"normal",
    fontSize: 14,
    textAlign:"center"
  },
  btnViewSkip: {
   borderWidth:1,
   borderColor: "#FF2D55",
    borderRadius: 12,
    width:"80%",
    marginTop:"4%",
    padding:20,
    alignSelf:"center"
  },
  btnTextSkip: {
    color: "#FF2D55",
    fontFamily:"Rubik-Regular",
    fontWeight:"500",
    fontStyle:"normal",
    fontSize: 14,
    textAlign:"center"
  },
  back:{
    width:"10%"
  }
})
export default styles;