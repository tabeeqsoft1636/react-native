import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {useRef} from 'react';
import {Modal, Text, TouchableOpacity, View} from 'react-native';
import DropdownAlert from 'react-native-dropdownalert';
import {useNavigation} from '@react-navigation/native';

import {DeleteApi} from 'theme/apiCalls';
import {styles} from './style';

function DeleteModal(props) {
  let dropDownAlertRef = useRef();
  const navigation = useNavigation();

  const apiCall = async () => {
    let loginInfo = await AsyncStorage.getItem('@loginInfo');
    loginInfo = JSON.parse(loginInfo);
    try {
      DeleteApi(loginInfo.id, async res => {
        if (res.sucess === '') {
          await AsyncStorage.clear();
          dropDownAlertRef.alertWithType(
            'success',
            'Success',
            'Successfully Delete Account',
          );
          props.toggleModal?.();
          navigation.navigate('WelcomeScreen');
        } else {
          dropDownAlertRef.alertWithType('error', 'Error', res?.error);
        }
      });
    } catch (error) {
      if (error.response) {
        console.log(error.response.data);
        dropDownAlertRef.alertWithType(
          'error',
          'Error',
          error.response.data.detail,
        );
      } else {
        // Something happened in setting up the request that triggered an Error
        console.log('Error', error.message);
      }
    }
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={props.visible}
      onRequestClose={() => {
        props.toggleModal?.();
      }}>
      <TouchableOpacity
        activeOpacity={1}
        style={styles.centeredView}
        onPress={() => props.toggleModal?.()}>
        <View style={styles.modalView}>
          <Text style={[styles.titleText, styles.modalTitle]}>
            Delete Account
          </Text>
          <Text style={[styles.titleText, styles.modalText]}>
            Are You Sure, You Want To Delete The App
          </Text>
          <TouchableOpacity
            style={[styles.button, styles.buttonNo]}
            onPress={() => props.toggleModal?.()}>
            <Text style={styles.titleText}>No</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, styles.buttonYes]}
            onPress={apiCall}>
            <Text style={styles.titleText}>Yes</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </Modal>
  );
}

export default DeleteModal;
