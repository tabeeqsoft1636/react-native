import React from 'react';
import {Modal, Text, TouchableOpacity, View} from 'react-native';
import {useNavigation} from '@react-navigation/native';

import {AsyncStorage} from 'theme/Libraries';
import {styles} from './style';

function DeleteModal(props) {
  const navigation = useNavigation();

  const logout = async () => {
    await AsyncStorage.removeItem('token');
    props.toggleModal?.();
    navigation.navigate('WelcomeScreen');
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={props.visible}
      onRequestClose={() => {
        props.toggleModal?.();
      }}>
      <TouchableOpacity
        activeOpacity={1}
        style={styles.centeredView}
        onPress={() => props.toggleModal?.()}>
        <View style={styles.modalView}>
          <Text style={[styles.titleText, styles.modalTitle]}>Logout</Text>
          <Text style={[styles.titleText, styles.modalText]}>
            Are You Sure, You Wanted To logout from the App
          </Text>
          <TouchableOpacity
            style={[styles.button, styles.buttonNo]}
            onPress={() => props.toggleModal?.()}>
            <Text style={styles.titleText}>No</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, styles.buttonYes]}
            onPress={logout}>
            <Text style={styles.titleText}>Yes</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

export default DeleteModal;
