import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  FlatList,
  Image,
  SafeAreaView,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import DeleteModal from './DeleteModal';
import LogoutModal from './LogoutModal';
import {styles} from './style';

function AppSettings() {
  const navigation = useNavigation();
  const [showModal, setShowModal] = useState(false);
  const [showModalLogout, setShowModalLogout] = useState(false);

  const LIST_DATA = [
    {
      id: 2,
      img: {
        source: require('../../assets/images/greenPage.png'),
        style: {
          height: 20,
        },
      },
      title: 'Terms & Conditions',
      isToggle: false,
      action: () => navigation.navigate('terms'),
    },
    {
      id: 3,
      img: {
        source: require('../../assets/images/greenPage.png'),
        style: {
          height: 20,
        },
      },
      title: 'Privacy Policy',
      isToggle: false,
      action: () => navigation.navigate('privacy'),
    },
    {
      id: 4,
      img: {source: require('../../assets/images/greenQ.png')},
      title: 'Help & Support',
      isToggle: false,
      action: () => navigation.navigate('support'),
    },
    {
      id: 5,
      img: {source: require('../../assets/images/greenBin.png')},
      title: 'Delete Account',
      isToggle: false,
      action: () => setShowModal(true),
    },
  ];

  function Logout() {
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        style={styles.logoutBtn}
        onPress={() => setShowModalLogout(true)}>
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    );
  }

  function Toggle(toggle) {
    return (
      <Switch
        style={{
          transform: [{scaleX: 0.8}, {scaleY: 0.8}],
        }}
        trackColor={{false: '#767577', true: '#FFBC00'}}
        thumbColor={toggle?.check ? '#2D2D2D' : 'rgba(255, 188, 0, 0.5)'}
        ios_backgroundColor={'transparent'}
        onValueChange={val => toggle.onChange?.(val)}
        value={toggle?.check || false}
      />
    );
  }
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={styles.backContainer}
            onPress={() => navigation.goBack()}>
            <Image
              style={styles.backIcon}
              source={require('assets/images/right.png')}
            />
          </TouchableOpacity>
          <View style={styles.profileContainer}>
            <Text style={styles.titleText}>Settings</Text>
          </View>
        </View>

        <FlatList
          style={styles.mainContainer}
          data={LIST_DATA}
          ItemSeparatorComponent={() => <View style={styles.seperator} />}
          keyExtractor={item => item.id.toString()}
          ListFooterComponent={<Logout />}
          renderItem={({item}) => (
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.cardView}
              onPress={() => item.action?.()}>
              <View style={styles.cardIcon}>
                <Image {...item.img} />
              </View>
              <Text style={styles.titleText}>{item.title}</Text>
              {item.isToggle ? (
                <Toggle
                  check={item?.check ?? false}
                  onChange={() => item.action?.()}
                />
              ) : (
                <View style={styles.cardIcon} />
              )}
            </TouchableOpacity>
          )}
        />
      </View>
      <DeleteModal
        visible={showModal}
        toggleModal={() => setShowModal(false)}
      />
      <LogoutModal
        visible={showModalLogout}
        toggleModal={() => setShowModalLogout(false)}
      />
    </SafeAreaView>
  );
}

export default AppSettings;
