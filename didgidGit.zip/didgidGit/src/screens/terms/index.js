/* eslint-disable react/react-in-jsx-scope */
import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {
  Image,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {styles} from './style';

function Terms() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={styles.backContainer}
            onPress={() => navigation.goBack()}>
            <Image
              style={styles.backIcon}
              source={require('assets/images/right.png')}
            />
          </TouchableOpacity>
          <View style={styles.profileContainer}>
            <Text style={styles.titleText}>Terms & Conditions</Text>
          </View>
        </View>

        <ScrollView style={styles.mainContainer} bounces={false}>
          <Text style={styles.titleText}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Orci magna
            cursus dolor aenean. Ut fringilla in amet elit ultrices arcu. Nisl
            purus facilisis cum vitae eget dis placerat eget egestas. Arcu nunc
            hendrerit donec amet, lectus dolor viverra tortor, neque. Lorem
            ipsum dolor sit amet, consectetur adipiscing elit. Orci magna cursus
            dolor aenean. Ut fringilla in amet elit ultrices arcu. Nisl purus
            facilisis cum vitae eget dis placerat eget egestas. Arcu nunc
            hendrerit donec amet, lectus dolor viverra tortor, neque. Lorem
            ipsum dolor sit amet, consectetur adipiscing elit. Orci magna cursus
            dolor aenean. Ut fringilla in amet elit ultrices arcu. Nisl purus
            facilisis cum vitae eget dis placerat eget egestas. Arcu nunc
            hendrerit donec amet, lectus dolor viverra tortor, neque.Lorem ipsum
            dolor sit amet, consectetur adipiscing elit. Orci magna cursus dolor
            aenean. Ut fringilla in amet elit ultrices arcu. Nisl purus
            facilisis cum vitae eget dis placerat eget egestas. Arcu nunc
            hendrerit donec amet, lectus dolor viverra tortor, neque.Lorem ipsum
            dolor sit amet, consectetur adipiscing elit. Orci magna cursus dolor
            aenean. Ut fringilla in amet elit ultrices arcu. Nisl purus
            facilisis cum vitae eget dis placerat eget egestas. Arcu nunc
            hendrerit donec amet, lectus dolor viverra tortor, neque.
          </Text>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

export default Terms;
