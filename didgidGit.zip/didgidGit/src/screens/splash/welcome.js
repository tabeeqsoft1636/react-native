//import liraries
import React, {Component, useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
// import { style } from './styles';
// import { TextInput } from 'react-native-paper';
import axios from 'axios';
import DropdownAlert from 'react-native-dropdownalert';

// create a component
function Welcome(props) {
  let dropDownAlertRef = useRef();

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      <View style={{}}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <Image
            resizeMode="contain"
            style={styles.logoStyle}
            source={require('../../assets/images/Welcome.png')}
          />
        </View>
        <View>
          <Text
            allowFontScaling={false}
            style={{
              textAlign: 'center',
              color: 'white',
              fontSize: 22,
              fontWeight: '600',
            }}>
            Congrats on joining Digidex
          </Text>
          <Text
            allowFontScaling={false}
            style={{
              textAlign: 'center',
              color: 'white',
              fontSize: 14,
              marginVertical: 15,
            }}>
            You’ve taken the first step to always...
          </Text>
          <Text
            allowFontScaling={false}
            style={{
              textAlign: 'center',
              color: 'white',
              fontSize: 14,
              marginBottom: 15,
            }}>
            Stay Connected(sm)
          </Text>
        </View>
        <View style={{paddingVertical: '5%'}}>
          <TouchableOpacity
            onPress={() => props.navigation.navigate('LoginScreen')}
            style={styles.btnStyle}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Sign In
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          onPress={() => props.navigation.navigate('SignUpScreen')}
          style={styles.signBtnStyle}>
          <Text
            allowFontScaling={false}
            style={{color: 'white', fontWeight: '500', fontSize: 14}}>
            Sign Up
          </Text>
        </TouchableOpacity>
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </KeyboardAvoidingView>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 30,
    backgroundColor: 'black',
    justifyContent: 'space-around',
  },
  logoStyle: {
    width: '100%',
    height: '58%',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
  signBtnStyle: {
    backgroundColor: '#FF6584',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
});

//make this component available to the app
export default Welcome;
