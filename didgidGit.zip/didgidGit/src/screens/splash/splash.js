import React, {useEffect} from 'react';
import {Image, SafeAreaView, StyleSheet} from 'react-native';
import {AsyncStorage} from 'theme/Libraries';

function Splash1(props) {
  useEffect(() => {
    setTimeout(async () => {
      // await AsyncStorage.removeItem('token');
      const token = await AsyncStorage.getItem('token');
      if (token) {
        props.navigation.navigate('MainAllContacts', {screen: 'Contacts'});
        // props.navigation.navigate('userProfileSetup', {name: 'Side Gig'});
      } else {
        props.navigation.navigate('Boarding1Screen');
      }
    }, 2000);
  });
  return (
    <SafeAreaView style={styles.body}>
      {/* <View style={styles.body}> */}
      <Image
        resizeMode="contain"
        style={styles.logo2}
        source={require('../../assets/images/logo.png')}
      />
      {/* </View> */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: 'black',
  },

  logo: {
    width: 243,
    height: 60,
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
  },
  logo2: {
    width: '80%',
    height: '30%',
  },
  footer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 0.7,
  },
  bottomText: {
    padding: 10,
    fontSize: 20,
    fontWeight: '500',
    color: '#FFFFFF',
  },
});
export default Splash1;
