//import liraries
import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';

// create a component
const Dashboard = props => {
  return (
    <View style={styles.container}>
      <Text style={{color: 'white'}}>Welcome</Text>

      <TouchableOpacity
        onPress={() => props.navigation.navigate('profileSetup')}
        style={{
          paddingVertical: 10,
          backgroundColor: '#009360',
          width: '40%',
          marginVertical: 20,
        }}>
        <Text style={{alignSelf: 'center', color: 'white'}}>
          Go to Profile Setup
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={async () => {
          await AsyncStorage.removeItem('token');
          props.navigation.navigate('LoginScreen');
        }}
        style={{
          paddingVertical: 10,
          backgroundColor: '#009360',
          width: '25%',
          marginVertical: 20,
          marginTop: '2%',
        }}>
        <Text style={{alignSelf: 'center', color: 'white'}}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50',
  },
});

//make this component available to the app
export default Dashboard;
