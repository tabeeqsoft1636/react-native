//import liraries
import React, {Component, useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import {
  Container,
  CardWrapper,
  DotView,
  ActiveDot,
  DotStyleView,
  LogoImage,
  TextWrapper,
  DescriptionText,
  DescriptionText2,
  NextBtn,
  SkipBtn,
} from './style';
// create a component
function OnBoarding2(props) {
  const [number, setNumber] = useState('');
  let dropDownAlertRef = useRef();

  return (
    <Container>
      <View style={{alignItems: 'center', flex: 0.9, justifyContent: 'center'}}>
        <LogoImage
          resizeMode="contain"
          source={require('../../assets/images/Boarding2.png')}
        />
      </View>
      <CardWrapper>
        <DotView>
          <DotStyleView />
          <ActiveDot />
          <DotStyleView />
        </DotView>
        <TextWrapper>
          <DescriptionText allowFontScaling={false}>
            Setting Up Your Digidex
          </DescriptionText>
          <DescriptionText2 allowFontScaling={false}>
            Digidex allows you to have three profiles, Personal, Business, and
            Side Gig. Your personal email is used to set up your account. After
            setting up your account you can then finish your personal profile as
            well as establish your business and side gig profiles.
          </DescriptionText2>
        </TextWrapper>
        <View style={{paddingVertical: '5%'}}>
          <NextBtn
            onPress={() => props.navigation.navigate('Boarding3Screen')}
            style={styles.btnStyle}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Next
            </Text>
          </NextBtn>
          <SkipBtn
            onPress={() => props.navigation.navigate('WelcomeScreen')}
            style={styles.skipBtnStyle}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 12}}>
              Skip
            </Text>
          </SkipBtn>
        </View>
      </CardWrapper>
    </Container>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    backgroundColor: 'black',
    justifyContent: 'space-around',
  },
  logoStyle: {
    width: '100%',
    height: '75%',
  },
  dotStyle: {
    height: '2%',
    width: '2.5%',
    borderColor: 'rgba(196, 196, 196, 0.54)',
    borderWidth: 2,
    borderRadius: 10,
    marginLeft: '1%',
  },
  activeDot: {
    height: '2%',
    width: '5%',
    borderColor: 'rgba(255, 255, 255, 1)',
    borderWidth: 2,
    borderRadius: 10,
    marginLeft: '1%',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
  skipBtnStyle: {
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
  card: {
    backgroundColor: 'rgba(36, 38, 45, 0.7)',
    borderRadius: 10,
    paddingHorizontal: '10%',
  },
});

//make this component available to the app
export default OnBoarding2;
