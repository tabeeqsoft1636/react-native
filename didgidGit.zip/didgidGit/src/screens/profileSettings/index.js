/* eslint-disable no-alert */
//import liraries
import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import {styles, TextinputView, InputText, ChangePasswordBtn} from './style';
import ImagePicker from 'react-native-image-crop-picker';
import {AsyncStorage} from 'theme/Libraries';
import {business, sideGig, personal} from 'theme/apiCalls';
import Dropdown from 'components/Dropdown';
import CustomModal from 'components/CustomModal';

const PROFILE_TYPES = {
  Business: 'business',
  Personal: 'personal',
  'Side Gig': 'sidegig',
};

const Fields = [
  {
    fieldTitle: 'name',
    placeholder: 'Type Your UserName...',
    imgSrc: require('assets/svgs/user.png'),
    keyboardType: 'email-address',
  },
  {
    fieldTitle: 'email',
    placeholder: 'Type Your Email...',
    imgSrc: require('assets/images/Message.png'),
    keyboardType: 'email-address',
  },
  {
    fieldTitle: 'phone',
    placeholder: 'Phone Number...',
    imgSrc: require('assets/images/Phone.png'),
    keyboardType: 'phone-pad',
  },
];

const dropdownlist = [
  {label: 'Business', value: 'Business'},
  {label: 'Personal', value: 'Personal'},
  {label: 'Side Gig', value: 'Side Gig'},
];

function ProfileSettings(props) {
  const [data, setData] = useState({});
  const [userInfo, setUserInfo] = useState({});
  const [loading, setLoading] = useState(false);
  const [value, setValue] = useState('');
  const [image, setImage] = useState(null);
  const [items, setItems] = useState(dropdownlist);
  const [showModal, setShowModal] = useState(false);

  const pickImage = () => {
    ImagePicker.openPicker({
      cropping: true,
    }).then(img => {
      setImage(img);
    });
  };

  useEffect(() => {
    const unsubscribe = props.navigation.addListener('focus', () => {
      getUserInfo();
    });

    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getUserInfo = async () => {
    const userObj = await AsyncStorage.getItem('@loginInfo');
    const user = JSON.parse(userObj);
    setUserInfo(user);
    if (user.personal) {
      setData(user.personal);
      setValue('Personal');
    } else if (user.business) {
      setData(user.business);
      setValue('Business');
    } else if (user.sidegig) {
      setData(user.sidegig);
      setValue('Side Gig');
    }
  };

  useEffect(() => {
    if (value === 'Business') {
      setData(userInfo.business);
    } else if (value === 'Personal') {
      setData(userInfo.personal);

      setValue('Personal');
    } else if (value === 'Side Gig') {
      setData(userInfo.sidegig);
    }
  }, [userInfo.business, userInfo.personal, userInfo.sidegig, value]);

  const setDataFunc = (name, val) => {
    setData(prev => ({...prev, [name]: val}));
  };

  const editProifle = () => {
    if (userInfo[PROFILE_TYPES[value]]) {
      props.navigation.navigate('userProfileSetup', {
        isEditable: true,
        name: value,
        userData: data,
      });
    } else {
      setShowModal(true);
    }
  };

  const addProfile = async () => {
    let apiType = null;
    if (value === 'Business') {
      apiType = business;
    }
    if (value === 'Personal') {
      apiType = personal;
    }
    if (value === 'Side Gig') {
      apiType = sideGig;
    }
    try {
      apiType(async res => {
        setShowModal(false);
        const userObj = {...userInfo, [PROFILE_TYPES[value]]: res};
        setUserInfo(userObj);
        await AsyncStorage.setItem('@loginInfo', JSON.stringify(userObj));
        if (res.sucess) {
          props.navigation.navigate('userProfileSetup', {
            isEditable: true,
            name: value,
            userData: res,
          });
        } else {
          // eslint-disable-next-line no-alert
          alert(res.error);
        }
      });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={styles.backContainer}
            onPress={() => props.navigation.goBack()}>
            <Image
              style={styles.backIcon}
              source={require('assets/images/right.png')}
            />
          </TouchableOpacity>
          <View style={styles.profileContainer}>
            <Text style={styles.titleText}>Profile</Text>
          </View>
        </View>
        {loading ? (
          <ActivityIndicator size="large" color={'#fff'} />
        ) : (
          <ScrollView>
            <View style={styles.imageContainer}>
              <Image
                resizeMode="cover"
                resizeMethod="scale"
                style={styles.profileImage}
                source={
                  image
                    ? {uri: image.path}
                    : data?.image
                    ? {uri: data?.image}
                    : require('assets/svgs/profile.png')
                }
              />

              <View style={styles.camIconWrapper}>
                <TouchableOpacity onPress={() => pickImage()}>
                  <Image source={require('assets/svgs/cam.png')} />
                </TouchableOpacity>
              </View>

              <View style={styles.profileNameContainer}>
                <Text style={styles.profileText}>{data?.name}</Text>
                <Image
                  style={styles.verifyIcon}
                  source={require('assets/svgs/tick.png')}
                />
              </View>

              {userInfo?.personal?.name && (
                <Text style={styles.profileText}>
                  {userInfo?.personal?.name}
                </Text>
              )}
              <View style={{width: '30%'}}>
                <Dropdown
                  value={value}
                  items={items}
                  setValue={setValue}
                  setItems={setItems}
                  placeholder={'Personal'}
                  showTickIcon={false}
                  zIndex={10}
                />
              </View>
            </View>
            <View style={styles.iconsContainer}>
              <TouchableOpacity
                style={[styles.icon, {backgroundColor: '#03CE87'}]}
                onPress={editProifle}>
                <Image source={require('assets/svgs/edit.png')} />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.icon, {backgroundColor: '#F66A3E'}]}
                onPress={() => props.navigation.navigate('shareScreen')}>
                <Image source={require('assets/svgs/grid.png')} />
              </TouchableOpacity>
            </View>
            {Fields.map((item, index) => {
              return (
                <TextinputView key={index}>
                  <Image style={{width: 20, height: 20}} source={item.imgSrc} />
                  <InputText
                    placeholder={item?.placeholder}
                    editable={false}
                    value={data?.[item?.fieldTitle]}
                    onChangeText={text => setDataFunc(item?.fieldTitle, text)}
                    placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
                    keyboardType={item?.keyboardType}
                  />
                </TextinputView>
              );
            })}
            <ChangePasswordBtn>
              <Text style={styles.passwordBtnText}>Change Password</Text>
            </ChangePasswordBtn>
            <CustomModal
              visible={showModal}
              toggleModal={() => setShowModal(false)}
              modalTitle={'Create Profile'}
              warningMsg={'Do you want to create Profile?'}
              callBackFunction={addProfile}
            />
          </ScrollView>
        )}
      </View>
    </SafeAreaView>
  );
}

export default ProfileSettings;
