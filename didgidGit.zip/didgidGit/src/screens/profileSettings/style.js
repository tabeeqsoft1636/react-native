import styled from 'styled-components/native';
import {StyleSheet} from 'react-native';

export const DescriptionWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  height: 70px;
  background-color: #2d2d2d;
  border-radius: 10px;
  margin-bottom: 5%;
`;

export const DescriptionText = styled.Text`
  font-family: 'Rubik';
  font-style: normal;
  font-weight: 400;
  font-size: 11px;
  letter-spacing: -0.24px;
  background-color: #2d2d2d;
  width: 90%;
  text-align: center;
  border-radius: 10px;
  color: #bbbbbb;
`;

export const TextinputView = styled.View`
  flex-direction: row;
  align-items: center;
  background-color: #2d2d2d;
  border-radius: 10px;
  margin: 7px 20px;
  padding: 0 15px;
  z-index: -1;
`;

export const InputText = styled.TextInput`
  width: 90%;
  text-align: center;
  color: ${props => (props.editable ? '#fff' : '#ffffff50')};
  border-radius: 10px;
  font-size: 11px;
  min-height: 45px;
`;

export const UpdateBtn = styled.TouchableOpacity`
  background-color: #009360;
  border-radius: 10px;
  align-items: center;
  margin: 7px 20px;
  padding: 15px 0;
`;

export const ChangePasswordBtn = styled.TouchableOpacity`
  background-color: transparent;
  border-radius: 10px;
  align-items: center;
  margin: 7px 20px;
  padding: 15px 0;
`;

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },

  iconsContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    alignSelf: 'center',
    zIndex: -1,
  },

  icon: {
    borderRadius: 12,
    margin: 5,
    width: 41,
    height: 41,
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
  },

  backIcon: {
    width: 34,
    height: 34,
  },

  headerView: {
    flexDirection: 'row',
    marginTop: 30,
    width: '100%',
  },

  backContainer: {
    width: '30%',
    paddingLeft: 20,
    justifyContent: 'center',
  },

  profileContainer: {
    width: '40%',
    justifyContent: 'center',
    alignItems: 'center',
  },

  dropDownContainer: {
    width: '30%',
    zIndex: 1,
  },

  titleText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },

  imageContainer: {
    alignItems: 'center',
    paddingTop: 15,
  },

  profileImage: {
    borderRadius: 12,
    width: 150,
    height: 150,
  },

  profileNameContainer: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 15,
    flex: 1,
    flexDirection: 'row',
  },
  camIconWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#E7E7E7BD',
    borderRadius: 5,
    width: 40,
    height: 23,
    bottom: 30,
  },

  verifyIcon: {
    marginLeft: 10,
  },

  profileText: {
    color: '#fff',
    fontFamily: 'Rubik',
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 14,
  },

  accountType: {
    color: '#fff',
    fontSize: 14,
  },

  btnText: {
    color: 'white',
    fontWeight: '500',
    fontSize: 14,
  },
  passwordBtnText: {
    color: '#FF2D55',
    fontWeight: '500',
    fontSize: 14,
  },
});
