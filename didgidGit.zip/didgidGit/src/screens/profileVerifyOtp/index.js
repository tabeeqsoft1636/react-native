/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import {
  CodeField,
  Cursor,
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';

const CELL_COUNT = 4;
import DropdownAlert from 'react-native-dropdownalert';
import {verifyEmail, sendOTP} from 'theme/apiCalls';
import {AsyncStorage} from 'theme/Libraries';
function profileVerifyOtp(props) {
  const {profileTitle, email: userEmail, isPhoneChanged} = props.route.params;

  const [otpEmailSideGig, setValue] = useState('');

  const [otpEmailPersonal, setValuePersonal] = useState('');

  const [propssPersonal, getCellOnLayoutHandlerPersonal] = useClearByFocusCell({
    otpEmailPersonal,
    setValue,
  });

  const [otpCode, setOtpCode] = useState('');
  const refBusiness = useBlurOnFulfill({
    otpCode,
    cellCount: CELL_COUNT,
  });
  const [propssBusiness, getCellOnLayoutHandlerBusiness] = useClearByFocusCell({
    otpCode,
    setValue,
  });
  const renderCellBusiness = ({index, symbol, isFocused}) => {
    let textChild = null;

    if (symbol) {
      textChild = symbol;
    } else if (isFocused) {
      textChild = <Cursor />;
    }

    return (
      <Text
        key={index}
        style={[styles.cell, isFocused && styles.focusCell]}
        onLayout={getCellOnLayoutHandlerPersonal(index)}>
        {textChild}
      </Text>
    );
  };

  let dropDownAlertRef = useRef();

  const next = async () => {
    // props.navigation.navigate('numberOtpVerify', {name: profileTitle});
    // return
    if (otpCode === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Please enter the code');
    } else {
      const obj = {
        otp: otpCode,
        profile: profileTitle,
      };
      try {
        verifyEmail(obj, async res => {
          if (res.sucess) {
            await AsyncStorage.setItem(
              '@loginInfo',
              JSON.stringify(res.sucess),
            );
            if (isPhoneChanged) {
              props.navigation.navigate('numberOtpVerify', {
                name: profileTitle,
                redirectTo: 'MainAllContacts',
              });
            } else {
              props.navigation.navigate('MainAllContacts');
            }
          } else {
            dropDownAlertRef.alertWithType(
              'error',
              'Error',
              JSON.stringify(res),
            );
          }
        });
      } catch (error) {
        dropDownAlertRef.alertWithType('error', 'Error', JSON.stringify(error));
      }
    }
  };

  const reSendOtp = async () => {
    const userDetail = {
      email: userEmail,
    };
    try {
      sendOTP(userDetail, async res => {
        if (res) {
          console.log(res.data);
          if (res.data === 'OTP sent successfully')
            dropDownAlertRef.alertWithType(
              'success',
              'Success',
              'OTP sent successfully',
            );
        } else {
        }
      });
    } catch (error) {
      if (error.res) {
        console.log(error.res.data);
        dropDownAlertRef.alertWithType('error', 'Error', error.res.data.detail);
      } else {
        // Something happened in setting up the request that triggered an Error
        console.log('Error', error.message);
      }
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      <View>
        <SafeAreaView />
        <View style={styles.mainContainer}>
          <TouchableOpacity
            style={styles.back}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('../../../assets/images/right.png')}
            />
          </TouchableOpacity>
          <Text style={styles.profileText}>
            Please Enter The Verification Code We Sent To Your Email
          </Text>
          <Text style={styles.profileDesc}>
            Enter the 4-digit code we sent to the phone number on your Personal
            profile via sms text message.
          </Text>
        </View>
        <View style={{marginTop: 20}}>
          <Text style={styles.profileDesc1}>Verify Email</Text>

          <View style={styles.fieldRow}>
            <CodeField
              ref={refBusiness}
              {...propssBusiness}
              value={otpCode}
              rootStyle={styles.codeFieldRoot}
              onChangeText={setOtpCode}
              cellCount={CELL_COUNT}
              keyboardType="number-pad"
              textContentType="oneTimeCode"
              renderCell={renderCellBusiness}
            />
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            paddingBottom: '5%',
            marginTop: 10,
          }}>
          <TouchableOpacity onPress={() => reSendOtp()}>
            <Text
              allowFontScaling={false}
              style={{color: '#F5365B', fontSize: 10}}>
              Click Here.
            </Text>
          </TouchableOpacity>
          <Text allowFontScaling={false} style={{color: 'white', fontSize: 10}}>
            To Resend
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            next();
          }}
          style={styles.btnView}>
          <Text style={styles.btnText}>Verify Email</Text>
        </TouchableOpacity>
      </View>

      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </KeyboardAvoidingView>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    // alignItems: 'center',
  },
  imageView: {
    marginBottom: 17,
  },
  profileText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '600',
    fontStyle: 'normal',
    fontSize: 22,
  },
  profileDesc: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 13,
    marginTop: 10,
  },
  profileDesc1: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 14,
    marginTop: 10,
    textAlign: 'center',
  },
  mainContainer: {
    marginTop: '8%',
    flexDirection: 'column',
    marginLeft: 15,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '80%',
    marginTop: '10%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
  back: {
    width: '10%',
  },
  root: {padding: 20, minHeight: 300},
  title: {textAlign: 'center', fontSize: 30},
  fieldRow: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'center',
    marginLeft: 8,
  },
  cell: {
    width: 55,
    height: 55,
    lineHeight: 55,
    fontSize: 30,
    fontWeight: '700',
    textAlign: 'center',
    marginLeft: 8,
    color: '#fff',
    // backgroundColor: '#eee',
    borderRadius: 50,
    backgroundColor: '#2D2D2D',
  },
  toggle: {
    width: 55,
    height: 55,
    lineHeight: 55,
    fontSize: 24,
    textAlign: 'center',
  },
  focusCell: {
    borderColor: '#fff',
  },
  codeFieldRoot: {
    // height: 10,
    marginTop: 4,
    paddingHorizontal: 10,
    // justifyContent: 'center',
    borderRadius: 20,
    // backgroundColor:"red"
  },
});

//make this component available to the app
export default profileVerifyOtp;
