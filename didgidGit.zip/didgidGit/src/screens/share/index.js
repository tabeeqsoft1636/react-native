//import liraries
import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import {DropDownView, TextinputView, InputText, ShareBtn} from './style';
import DropdownAlert from 'react-native-dropdownalert';
import DropDownPicker from 'react-native-dropdown-picker';
function shareScreen(props) {
  const [number, setNumber] = useState('');
  const [email, setEmail] = useState('');

  const [open, setOpen] = useState(false);
  const [value, setValue] = useState('');
  const [items, setItems] = useState([
    {label: 'Email', value: 'email'},
    {label: 'Number', value: 'sms'},
  ]);
  let dropDownAlertRef = useRef();
  const [SendRequestShow, setSendRequestShow] = useState(false);

  const validation = () => {
    let valid = true;
    if (email === '') {
      console.log('true');
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Email');
    } else if (!expressions.email.test(email) || number.includes(' ')) {
      dropDownAlertRef.alertWithType('error', 'Error', 'Invalid Email Address');
    } else if (number === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Number');
    } else {
      return valid;
      // dropDownAlertRef.alertWithType('success', 'Success', 'Login Success');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View
          style={[
            styles.headerView,
            SendRequestShow ? styles.headerView : styles.headerView2,
          ]}>
          <TouchableOpacity
            style={{}}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('../../../assets/images/right.png')}
            />
          </TouchableOpacity>
          <View style={styles.requestView}>
            <Text style={styles.syncedTitle}>Share My Profile</Text>
          </View>
        </View>

        <View style={[styles.imageWrapper]}>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/Message.png')}
            />
            <InputText
              placeholder="Type Your Email ID"
              multiline={true}
              onChangeText={text => setEmail(text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </TextinputView>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/Phone.png')}
            />
            <InputText
              placeholder="Phone Number"
              onChangeText={text => setNumber(text)}
              multiline={true}
              keyboardType="number-pad"
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </TextinputView>
          <DropDownView>
            <DropDownPicker
              open={open}
              value={value}
              items={items}
              setOpen={setOpen}
              setValue={setValue}
              setItems={setItems}
              zIndex={50}
              placeholder={'Choose The Type Of Contact'}
              placeholderStyle={{
                color: 'rgba(255, 255, 255, 0.6)',
                fontSize: 12,
                alignSelf: 'center',
                textAlign: 'center',
                width: '100%',
              }}
              dropDownContainerStyle={{
                borderWidth: 3,
                borderColor: '#2d2d2d',
                backgroundColor: '#2d2d2d',
                color: '#fff',
                alignSelf: 'center',
              }}
              textStyle={styles.HeadingText}
              style={{
                backgroundColor: '#2d2d2d',
                borderWidth: 0,
                borderRadius: 10,
                alignSelf: 'center',
                marginTop: '5%',
              }}
              listItemContainerStyle={{
                backgroundColor: '#2d2d2d',
                borderColor: 'rgba(255, 255, 255, 0.6)',
                borderWidth: 1,
                borderRadius: 10,
              }}
            />

            <View>
              <ShareBtn
                style={{marginTop: '15%'}}
                // onPress={() => apiCall()}
              >
                <Text
                  allowFontScaling={false}
                  style={{color: 'white', fontWeight: '500', fontSize: 14}}>
                  Share
                </Text>
              </ShareBtn>
            </View>
          </DropDownView>
        </View>
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 20,
    marginTop: '12%',
    width: '100%',
  },
  headerView2: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginTop: '12%',
    width: '50%',
  },
  viewStyle: {
    borderColor: '#FF2D55',
    borderWidth: 2,
    borderRadius: 30,
    width: '50%',
    alignSelf: 'center',
    right: 5,
  },
  syncedTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
  requestView: {flexDirection: 'row'},
  header: {
    backgroundColor: '#4591ed',
    color: 'white',
    paddingHorizontal: 15,
    paddingVertical: 15,
    fontSize: 20,
  },
  imageWrapper: {
    alignItems: 'center',
    top: 20,
    marginBottom: 20,
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  inputView: {
    width: '35%',
    flexDirection: 'row',
    marginLeft: 10,
  },
});
export default shareScreen;
