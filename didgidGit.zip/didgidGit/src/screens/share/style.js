import styled from 'styled-components/native';

export const TextinputView = styled.View`
  flex-direction: row;
  align-items: center;
  height: 55px;
  background-color: #2d2d2d;
  border-radius: 10px;
  margin-bottom: 5%;
`;
export const InputText = styled.TextInput`
  background-color: #2d2d2d;
  width: 90%;
  text-align: center;
  color: white;
  border-radius: 10px;
  font-size: 14px;
`;

export const DropDownView = styled.View`
  margin-left: 1.2%;
  margin-right: 1.8%;
  margin-top: -5%;
`;

export const ShareBtn = styled.TouchableOpacity`
  background-color: #009360;
  padding-vertical: 20px;
  margin-left: 20px;
  margin-right: 20px;
  border-radius: 10px;
  align-items: center;
`;
