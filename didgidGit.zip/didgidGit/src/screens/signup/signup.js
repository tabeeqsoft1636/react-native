/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';

import DropdownAlert from 'react-native-dropdownalert';
import axios from 'axios';
import {expressions} from '../../utils/functions';
import {
  Container,
  TextWrapper,
  DescriptionText,
  DescriptionText2,
  TextinputWrapper,
  TextinputView,
  InputText,
  LoginBtn,
} from './style';
import {SignupApi} from 'theme/apiCalls';
// create a component
function signUp(props) {
  const [username, setUsername] = useState('');
  const [number, setNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [repassword, setRepassword] = useState('');
  let dropDownAlertRef = useRef();

  const validation = () => {
    let valid = true;
    if (email === '') {
      console.log('true');
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Email');
    } else if (!expressions.email.test(email) || number.includes(' ')) {
      dropDownAlertRef.alertWithType('error', 'Error', 'Invalid Email Address');
    } else if (password === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Password');
    } else if (password.length < 5) {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Ensure password has at least 5 characters',
      );
    } else if (username === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your User Name');
    } else if (number === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Number');
    } else if (repassword === '') {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Enter Your Confirm Password',
      );
    } else if (password !== repassword) {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Password Doesnot Match',
      );
    } else {
      return valid;
      // dropDownAlertRef.alertWithType('success', 'Success', 'Login Success');
    }
  };

  const apiCall = async () => {
    let valid = validation();
    if (valid) {
      axios.defaults.headers = {
        'Content-Type': 'application/json',
      };
      const userDetail = {
        name: username,
        last_name: '',
        email: email,
        phone: number,
        password: password,
      };
      try {
        SignupApi(userDetail, async res => {
          console.log(res);
          if (res.sucess) {
            await AsyncStorage.setItem(
              '@loginInfo',
              JSON.stringify(res.sucess.user),
            );
            await AsyncStorage.setItem(
              'token',
              JSON.stringify(res.sucess.token),
            );
            dropDownAlertRef.alertWithType(
              'error',
              'Error',
              'Successfully Register',
            );
            props.navigation.navigate('profileSetup');
          } else {
            dropDownAlertRef.alertWithType('error', 'Error', res?.error);
          }
        });
      } catch (error) {
        if (error.response) {
          console.log(error.response.data);
          dropDownAlertRef.alertWithType(
            'error',
            'Error',
            error.response.data.detail,
          );
        } else {
          // Something happened in setting up the request that triggered an Error
          console.log('Error', error.message);
        }
      }
    }
  };
  return (
    <Container
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={{flexGrow: 1}}>
      <View style={{alignItems: 'center', justifyContent: 'center'}}>
        <Image
          resizeMode="contain"
          style={styles.logoStyle}
          source={require('../../assets/images/logo.png')}
        />
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <TextWrapper>
          <DescriptionText allowFontScaling={false}>
            Please Create Your New Account.
          </DescriptionText>
          <DescriptionText2 allowFontScaling={false}>
            Use your personal email address and cell phone number (capable of
            receiving sms text messages) to set up your account.
          </DescriptionText2>
        </TextWrapper>
        <TextinputWrapper>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/User.png')}
            />
            <InputText
              textAlign="right"
              multiline={true}
              placeholder="Type Your FullName"
              onChangeText={text => setUsername(text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </TextinputView>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/Message.png')}
            />
            <InputText
              placeholder="Type Your Email"
              multiline={true}
              onChangeText={text => setEmail(text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </TextinputView>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/Phone.png')}
            />
            <InputText
              placeholder="Type Your Phone Number"
              onChangeText={text => setNumber(text)}
              multiline={true}
              keyboardType="number-pad"
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </TextinputView>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/Lock.png')}
            />
            <InputText
              placeholder="Type Your Password"
              onChangeText={text => setPassword(text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              secureTextEntry={true}
            />
          </TextinputView>
          <TextinputView>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20, marginLeft: '2%'}}
              source={require('../../assets/images/Lock.png')}
            />
            <InputText
              placeholder="Type Your Password"
              onChangeText={text => setRepassword(text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              secureTextEntry={true}
            />
          </TextinputView>
        </TextinputWrapper>

        <LoginBtn style={{}} onPress={() => apiCall()}>
          <Text
            allowFontScaling={false}
            style={{color: 'white', fontWeight: '500', fontSize: 14}}>
            Sign Up
          </Text>
        </LoginBtn>

        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            paddingVertical: 10,
          }}>
          <Text allowFontScaling={false} style={{color: 'white', fontSize: 13}}>
            Already Have Account?{' '}
          </Text>
          <TouchableOpacity
            onPress={() => props.navigation.navigate('LoginScreen')}>
            <Text
              allowFontScaling={false}
              style={{color: '#F5365B', fontSize: 13}}>
              Sign In
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </Container>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {},
  logoStyle: {
    width: '100%',
    height: '30%',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
});

//make this component available to the app
export default signUp;
