import styled from 'styled-components/native';



export const Container = styled.KeyboardAvoidingView`
  flex: 1;
  padding-horizontal: 20px;
  background-color: black;
`;
export const TextWrapper = styled.View``;

export const Wrapper = styled.View`
  flex: 0.9;
`;
export const DescriptionText = styled.Text`
  color: white;
  font-size: 22px;
  font-family: 'Rubik-Regular';
  font-weight: 600;
`;
export const DescriptionText2 = styled.Text`
  color: white;
  font-size: 14px;
  margin-vertical: 5%;
  font-family: 'Rubik-Regular';
`;

export const TextinputWrapper = styled.View`
  padding-vertical: 10%;
  justify-content: space-between;
`;
export const TextinputView = styled.View`
  flex-direction: row;
  align-items: center;
  height: 55px;
  background-color: #2d2d2d;
  border-radius: 10px;
  margin-bottom: 5%;
`;
export const InputText = styled.TextInput`
  background-color: #2d2d2d;
  width: 90%;
  text-align: center;
  color: white;
  border-radius: 10px;
  font-size: 14px;
`;

export const LoginBtn = styled.TouchableOpacity`
  background-color: #009360;
  padding-vertical: 20px;
  border-radius: 10px;
  align-items: center;
`;
