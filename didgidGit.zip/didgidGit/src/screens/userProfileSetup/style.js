import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },

  headerContainer: {
    marginVertical: 20,
    marginHorizontal: 10,
  },

  backBtn: {
    width: '10%',
  },

  profileText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '600',
    fontStyle: 'normal',
    fontSize: 22,
  },

  profileDesc: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 13,
  },

  InputWrapper: {
    marginTop: 10,
    padding: 10,
  },

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#2d2d2d',
    borderRadius: 10,
    marginBottom: 10,
    paddingHorizontal: 10,
  },

  textInputStyle: {
    width: '90%',
    textAlign: 'center',
    color: '#fff',
    fontSize: 14,
  },

  submitButton: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '80%',
    padding: 20,
    alignSelf: 'center',
  },

  submitBtnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
});
export default styles;
