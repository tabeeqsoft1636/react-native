/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useEffect, useState} from 'react';

import {
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import styles from './style';
import {CountryPicker} from 'theme/Libraries';
import {ProgressBar} from 'react-native-paper';
import {useNavigation, useRoute} from '@react-navigation/native';
import CountryData from 'react-native-region-country-picker/src/constants/countries.json';
// create a component
const profileSetupSocial = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const profileTitle = route.params.name;
  const isEditable = route.params?.isEditable ?? false;
  const userData = route.params?.userData ?? null;

  const [profileData, setProfileData] = useState({});
  const [country, setCountry] = useState({
    cca2: 'US',
    name: 'United States',
  });

  useEffect(() => {
    if (isEditable) {
      setProfileData({...userData});
      const countryIndex = CountryData.findIndex(
        element =>
          element.name.toLowerCase() === userData?.country?.toLowerCase(),
      );
      if (countryIndex >= 0) {
        setCountry({
          cca2: CountryData[countryIndex].code,
          name: CountryData[countryIndex].name,
        });
      }
    }
  }, [isEditable, userData]);

  const updateProfile = (name, value) => {
    let obj = profileData;
    obj[name] = value;
    setProfileData(obj);
  };

  const next = async () => {
    if (Object.keys(profileData).length < 7) {
      // eslint-disable-next-line no-alert
      alert('complete all the fields');
    } else {
      setProfileData({...profileData, country: country.name});
      navigation.navigate('profileSetupImage', {
        profileTitle,
        profileData,
        userData,
      });
    }
  };

  return (
    <View style={styles.container}>
      <SafeAreaView />
      <View style={styles.headerContainer}>
        <TouchableOpacity
          style={styles.backBtn}
          onPress={() => navigation.goBack()}>
          <Image
            resizeMode="contain"
            source={require('assets/images/right.png')}
          />
        </TouchableOpacity>
        <Text style={styles.profileText}>{`${profileTitle} Details`}</Text>
        <Text style={styles.profileDesc}>
          You Can Edit & Update The Information Later On From Settings As Well
        </Text>
      </View>
      <View style={{marginTop: 10, width: '90%', alignSelf: 'center'}}>
        <ProgressBar progress={0.3} color={'#009360'} />
      </View>

      <ScrollView>
        <View style={styles.InputWrapper}>
          <View style={styles.inputContainer}>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20}}
              source={require('assets/images/bag.png')}
            />
            <TextInput
              placeholder={`${profileTitle} Name`}
              style={styles.textInputStyle}
              defaultValue={profileData?.name || ''}
              onChangeText={text => updateProfile('name', text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </View>
          <View style={styles.inputContainer}>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20}}
              source={require('assets/images/bag.png')}
            />
            <TextInput
              placeholder={`${profileTitle} Title`}
              style={styles.textInputStyle}
              defaultValue={profileData?.title || ''}
              onChangeText={text => updateProfile('title', text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </View>
          <View style={styles.inputContainer}>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20}}
              source={require('assets/images/bag.png')}
            />
            <TextInput
              placeholder="Email"
              style={styles.textInputStyle}
              defaultValue={profileData?.email || ''}
              onChangeText={text => updateProfile('email', text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </View>
          <View style={styles.inputContainer}>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20}}
              source={require('assets/images/Phone.png')}
            />
            <TextInput
              placeholder="Phone Number"
              keyboardType="phone-pad"
              style={styles.textInputStyle}
              defaultValue={profileData?.phone || ''}
              onChangeText={text => updateProfile('phone', text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </View>
          <View style={styles.inputContainer}>
            <Image
              resizeMode="contain"
              style={{width: 20, height: 20}}
              source={require('assets/images/location.png')}
            />
            <TextInput
              placeholder="Full Address"
              style={styles.textInputStyle}
              defaultValue={profileData?.street_1 || ''}
              onChangeText={text => updateProfile('street_1', text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <View style={[styles.inputContainer, {width: '49%'}]}>
              <TextInput
                placeholder="Zip Code"
                keyboardType="number-pad"
                style={[styles.textInputStyle, {textAlign: 'left'}]}
                defaultValue={profileData?.zip_code || ''}
                onChangeText={text => updateProfile('zip_code', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View style={[styles.inputContainer, {width: '49%'}]}>
              <TextInput
                placeholder="City"
                style={[styles.textInputStyle, {textAlign: 'left'}]}
                defaultValue={profileData?.city || ''}
                onChangeText={text => updateProfile('city', text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
          </View>
          <View style={styles.inputContainer}>
            <CountryPicker
              {...{
                withFilter: true,
                countryCode: country.cca2,
                onSelect: e => setCountry(e),
              }}
            />
            <Text style={[styles.textInputStyle, {width: '80%'}]}>
              {country.name}
            </Text>
          </View>
        </View>
        <View style={{marginTop: 5, paddingVertical: 10}}>
          <TouchableOpacity
            onPress={() => {
              next();
            }}
            style={styles.submitButton}>
            <Text style={styles.submitBtnText}>Continue</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

//make this component available to the app
export default profileSetupSocial;
