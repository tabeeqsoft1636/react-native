import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  mainContainer: {
    flex: 1,
    padding: 20,
    marginTop: 20,
  },
  iconsContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    alignSelf: 'center',
  },

  icon: {
    borderRadius: 12,
    margin: 5,
    width: 41,
    height: 41,
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
  },

  backIcon: {
    width: 34,
    height: 34,
  },

  headerView: {
    flexDirection: 'row',
    marginTop: 30,
    width: '100%',
  },

  backContainer: {
    width: '30%',
    paddingLeft: 20,
    justifyContent: 'center',
  },

  titleText: {
    color: '#fff',
    fontSize: 16,
    lineHeight: 25,
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },
});
