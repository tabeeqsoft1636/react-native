/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Platform,
} from 'react-native';
import RequestComponent from '../Requests';
import InviteCommponent from '../Invites';
import SendRequestComp from '../SendRequest';
import Dropdown from 'components/Dropdown';

const TABS = ['Invites', 'Requests', 'Send Request'];
function request(props) {
  const [topTab, setTopTab] = useState(TABS[0]);
  const [value, setValue] = useState('');
  const [items, setItems] = useState([
    {label: 'Business', value: 'Business'},
    {label: 'Personal', value: 'Personal'},
    {label: 'Side Gig', value: 'Side Gig'},
  ]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View
          style={[
            styles.headerView,
            topTab === TABS[2] ? styles.headerView : styles.headerView2,
          ]}>
          <TouchableOpacity
            style={{}}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('../../../assets/images/right.png')}
            />
          </TouchableOpacity>
          {topTab !== TABS[2] && (
            <View style={styles.requestView}>
              <Text style={styles.syncedTitle}>Requests</Text>
            </View>
          )}
          {topTab === TABS[2] && (
            <>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  justifyContent: 'space-evenly',
                }}>
                <View style={[styles.requestView, {left: 30}]}>
                  <Text style={styles.syncedTitle}>Requests</Text>
                </View>
                <View style={styles.inputView}>
                  <Dropdown
                    value={value}
                    items={items}
                    setValue={setValue}
                    setItems={setItems}
                    placeholder={'Side Gig'}
                  />
                </View>
              </View>
            </>
          )}
        </View>
        <View style={styles.allContactsView}>
          <TouchableOpacity onPress={() => setTopTab(TABS[0])}>
            <Text
              style={[
                styles.allContacts,
                {color: topTab === TABS[0] ? '#FF2D55' : '#fff'},
              ]}>
              Invites
            </Text>
            {topTab === TABS[0] && <View style={styles.viewStyle} />}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setTopTab(TABS[1])}>
            <Text
              style={[
                styles.allContacts,
                {color: topTab === TABS[1] ? '#FF2D55' : '#fff'},
              ]}>
              Request
            </Text>
            {topTab === TABS[1] && <View style={styles.viewStyle} />}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setTopTab(TABS[2])}>
            <Text style={[styles.allContacts, {color: '#03CE87'}]}>
              Send Request
            </Text>
          </TouchableOpacity>
        </View>

        <View style={{flex: 1}}>
          {topTab === TABS[0] && (
            <InviteCommponent navigation={props.navigation} />
          )}
          {topTab === TABS[1] && (
            <RequestComponent navigation={props.navigation} />
          )}
          {topTab === TABS[2] && (
            <SendRequestComp valueData={value} navigation={props.navigation} />
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 20,
    marginTop: '12%',
    width: '100%',
  },
  headerView2: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginTop: '12%',
    width: '50%',
  },
  imageView: {
    // marginBottom: 17,
    // alignSelf: "center"
  },
  viewStyle: {
    borderColor: '#FF2D55',
    borderWidth: 2,
    borderRadius: 30,
    width: '50%',
    alignSelf: 'center',
    right: 5,
  },
  syncedTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
  requestView: {flexDirection: 'row'},
  categotyTouch: {
    marginTop: 15,
    backgroundColor: ' rgba(255, 255, 255, 0.4)',
    width: '11%',
    borderRadius: 10,
    alignSelf: 'center',
    padding: 8,
  },
  allContacts: {
    color: '#fff',
    fontSize: 13,
    marginLeft: '5%',
    fontWeight: '600',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    paddingBottom: 4,
  },
  allContactsView: {
    marginTop: '10%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 20,
  },
  flatListView: {flex: 1, marginTop: '6%'},
  header: {
    backgroundColor: '#4591ed',
    color: 'white',
    paddingHorizontal: 15,
    paddingVertical: 15,
    fontSize: 20,
  },
  searchBar: {
    backgroundColor: '#f0eded',
    paddingHorizontal: 30,
    paddingVertical: Platform.OS === 'android' ? undefined : 15,
  },
  inputView: {
    width: '35%',
    flexDirection: 'row',
    marginLeft: 10,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '93%',
    marginTop: '2%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
  groupText: {
    color: '#FF2D55',
    fontSize: 13,
    fontWeight: '400',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
});
export default request;
