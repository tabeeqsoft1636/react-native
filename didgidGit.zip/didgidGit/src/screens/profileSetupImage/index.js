/* eslint-disable react-hooks/rules-of-hooks */
import React, {useState} from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Platform,
  SafeAreaView,
} from 'react-native';
import {ProgressBar} from 'react-native-paper';
import ImagePicker from 'react-native-image-crop-picker';

import styles from './style';

function profileSetupImage(props) {
  const {profileTitle, profileData, userData = null} = props.route.params;

  const [ImageData, setImageData] = useState();

  const pickImage = () => {
    ImagePicker.openPicker({
      cropping: true,
    }).then(img => {
      setImageData(img);
    });
  };

  const next = () => {
    props.navigation.navigate('profileSetupSocial', {
      profileTitle,
      profileData,
      ImageData,
      userData,
    });
  };
  return (
    <View style={styles.container}>
      <View>
        <SafeAreaView />
        <View style={styles.mainContainer}>
          <TouchableOpacity
            style={styles.back}
            onPress={() => props.navigation.goBack()}>
            <Image
              resizeMode="contain"
              style={styles.imageView}
              source={require('assets/images/right.png')}
            />
          </TouchableOpacity>
          <Text style={styles.profileText}>{profileTitle} Details</Text>
          <Text style={styles.profileDesc}>
            Upload a picture, logo or other image. You can update the image
            later from the Settings screen.
          </Text>
        </View>
        <View style={{width: '90%', alignSelf: 'center'}}>
          <ProgressBar progress={0.5} color={'#009360'} />
        </View>
        {(ImageData || profileData.image) && (
          <View style={{width: '100%', alignItems: 'center', top: 20}}>
            <Image
              resizeMode="cover"
              resizeMethod="scale"
              style={styles.profileImage}
              source={{uri: ImageData?.path || profileData?.image || ''}}
            />
          </View>
        )}
        <View style={styles.mainInput}>
          <TouchableOpacity
            onPress={() => pickImage()}
            style={styles.inputView}>
            <Image
              resizeMode="contain"
              style={{
                width: 55,
                height: 55,
                borderRadius: Platform.OS === 'ios' ? 12 : 2,
              }}
              source={require('assets/images/pluss.png')}
            />
            <TextInput
              placeholder="Add Image"
              // multiline={true}
              editable={false}
              selectTextOnFocus={false}
              style={styles.textInputStyle}
              // onChangeText={text => setEmail(text)}
              placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
            />
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          onPress={() => {
            next();
          }}
          style={styles.btnView}>
          <Text style={styles.btnText}>Add & Verify</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

//make this component available to the app
export default profileSetupImage;
