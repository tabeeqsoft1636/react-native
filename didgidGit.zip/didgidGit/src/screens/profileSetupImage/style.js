import {StyleSheet, Dimensions} from 'react-native';
import {color} from 'react-native-reanimated';

const {width, height} = Dimensions.get('window');

const guidelineBaseWidth = 350;
const guidelineBaseHeight = 680;

const scale = size => (width / guidelineBaseWidth) * size;
const scaleVertical = size => (height / guidelineBaseHeight) * size;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // marginTop:20,
    backgroundColor: 'black',
  },
  imageView: {
    marginBottom: 17,
  },
  profileText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '600',
    fontStyle: 'normal',
    fontSize: 22,
  },
  profileDesc: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 13,
  },
  mainContainer: {
    marginTop: '8%',
    flexDirection: 'column',
    marginLeft: 15,
  },
  imageBackView: {
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    borderRadius: 12,
  },
  contentList: {
    flex: 1,
  },
  cardContent: {
    marginLeft: 20,
    marginTop: 10,
    width: '60%',
  },
  image: {
    width: 120,
    // height:120,
    borderRadius: 12,
    marginTop: 6,
  },

  inputView: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#2d2d2d',
    borderRadius: 10,
    width: '93%',
    alignSelf: 'center',
    marginTop: '6%',
  },
  textInputStyle: {
    backgroundColor: '#2d2d2d',
    width: '85%',
    textAlign: 'center',
    color: '#fff',
    borderRadius: 10,
    fontSize: 14,
  },
  inputView1: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#2d2d2d',
    borderRadius: 10,
    width: '45%',
    alignSelf: 'center',
    marginTop: '6%',
  },
  textInputStyle1: {
    backgroundColor: '#2d2d2d',
    width: '45%',
    textAlign: 'center',
    color: '#fff',
    borderRadius: 10,
    fontSize: 14,
  },
  mainInput: {
    marginTop: '15%',
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '80%',
    marginTop: '26%',
    padding: 20,
    alignSelf: 'center',
    // position:"absolute",
    // bottom:"1%"
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
  back: {
    width: '10%',
  },
  profileImage: {
    borderRadius: 12,
    width: 150,
    height: 150,
  },
});
export default styles;
