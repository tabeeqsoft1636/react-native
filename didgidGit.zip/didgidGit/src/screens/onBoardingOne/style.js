import styled from 'styled-components/native';



export const Container = styled.KeyboardAvoidingView`
  flex: 1;
  padding-horizontal: 20px;
  background-color: black;
  justify-content: space-around;
`;
export const CardWrapper = styled.View`
  background-color: 'rgba(36, 38, 45, 0.7)';
  border-radius: 10px;
  padding-horizontal: 10%;
`;
export const DotView = styled.View`
  align-self: center;
  flex-direction: row;
  padding-vertical: 8%;
`;
export const ActiveDot = styled.View`
  height: 2%;
  width: 5%;
  border-color: rgba(255, 255, 255, 1);
  border-width: 2px;
  border-radius: 10px;
  margin-left: 1%;
`;
export const DotStyleView = styled.View`
  height: 2%;
  width: 2.5%;
  border-color: rgba(196, 196, 196, 0.54);
  border-width: 2px;
  border-radius: 10px;
  margin-left: 1%;
`;
export const LogoImage = styled.Image`
  width: 100%;
  height: 85%;
`;

export const TextWrapper = styled.View`
  align-items: center;
`;
export const DescriptionText = styled.Text`
  color: white;
  font-size: 22px;
  font-weight: 600;
  text-align: center;
`;
export const DescriptionText2 = styled.Text`
  color: white;
  font-size: 14px;
  margin-vertical: 15px;
  text-align: center;
`;
export const NextBtn = styled.TouchableOpacity`
  background-color: #009360;
  padding-vertical: 5%;
  border-radius: 10px;
  align-items: center;
`;
export const SkipBtn = styled.TouchableOpacity`
  padding-vertical: 20px;
  border-radius: 10px;
  align-items: center;
`;
