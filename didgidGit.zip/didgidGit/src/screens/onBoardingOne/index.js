//import liraries
import React, {useState, useRef} from 'react';
import {View, Text, StyleSheet} from 'react-native';
// import { style } from './styles';
// import { TextInput } from 'react-native-paper';
import {
  Container,
  CardWrapper,
  DotView,
  ActiveDot,
  DotStyleView,
  LogoImage,
  TextWrapper,
  DescriptionText,
  DescriptionText2,
  NextBtn,
  SkipBtn,
} from './style';

// create a component
function OnBoarding1(props) {
  const [number, setNumber] = useState('');
  let dropDownAlertRef = useRef();

  return (
    <Container>
      <View style={{alignItems: 'center', flex: 0.9, justifyContent: 'center'}}>
        <LogoImage
          resizeMode="contain"
          source={require('../../assets/images/Boarding3.png')}
        />
      </View>
      <CardWrapper>
        <DotView>
          <ActiveDot />
          <DotStyleView />
          <DotStyleView />
        </DotView>
        <TextWrapper>
          <DescriptionText allowFontScaling={false}>
            Welcome to Digidex
          </DescriptionText>
          <DescriptionText2 allowFontScaling={false}>
            Digidex serves as your personal digital RolodexTM. Never lose
            contact with the people in your Digidex. Digidex automatically
            updates the contacts in your “Digidex” whenever they change their
            phone or email address.
          </DescriptionText2>
        </TextWrapper>
        <View style={{paddingVertical: '5%'}}>
          <NextBtn onPress={() => props.navigation.navigate('Boarding2Screen')}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Next
            </Text>
          </NextBtn>
          <SkipBtn onPress={() => props.navigation.navigate('WelcomeScreen')}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 12}}>
              Skip
            </Text>
          </SkipBtn>
        </View>
      </CardWrapper>
    </Container>
  );
}

// define your styles
const styles = StyleSheet.create({
  dotStyle: {},
  activeDot: {},
  card: {},
});

//make this component available to the app
export default OnBoarding1;
