import {StyleSheet} from 'react-native';
import styled from 'styled-components';

export const InputText = styled.TextInput`
  background-color: #2d2d2d;
  width: 100%;
  height: 55px;
  color: white;
  border-radius: 10px;
  font-size: 14px;
  align-items: center;
  text-align: center;
  margin-top: 30px;
  margin-bottom: 10px;
`;
export const MultiInputText = styled.TextInput`
  background-color: #2d2d2d;
  width: 100%;
  height: 180px;
  color: white;
  border-radius: 10px;
  font-size: 14px;
  text-align: center;
  text-align-vertical: center;
  margin-top: 30px;
  margin-bottom: 10px;
`;

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  mainContainer: {
    flex: 1,
    padding: 20,
    marginTop: 20,
  },
  iconsContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    alignSelf: 'center',
  },

  icon: {
    borderRadius: 12,
    margin: 5,
    width: 41,
    height: 41,
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
  },

  backIcon: {
    width: 34,
    height: 34,
  },

  headerView: {
    flexDirection: 'row',
    marginTop: 30,
    width: '100%',
  },

  backContainer: {
    width: '30%',
    paddingLeft: 20,
    justifyContent: 'center',
  },

  titleText: {
    color: '#fff',
    fontSize: 16,
    lineHeight: 25,
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },
  cardView: {
    backgroundColor: '#2D2D2D',
    padding: 15,
    borderRadius: 12,
    minHeight: 55,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
  cardIcon: {
    width: 30,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtn: {
    backgroundColor: '#009360',
    padding: 15,
    borderRadius: 12,
    minHeight: 55,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 25,
  },
});
