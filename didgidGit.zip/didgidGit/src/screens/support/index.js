/* eslint-disable react/react-in-jsx-scope */
import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {
  Image,
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {InputText, MultiInputText, styles} from './style';

function Support() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={styles.backContainer}
            onPress={() => navigation.goBack()}>
            <Image
              style={styles.backIcon}
              source={require('assets/images/right.png')}
            />
          </TouchableOpacity>
          <View style={styles.profileContainer}>
            <Text style={styles.titleText}>Help & Support</Text>
          </View>
        </View>

        <ScrollView style={styles.mainContainer} bounces={false}>
          <TouchableOpacity activeOpacity={0.7} style={styles.cardView}>
            <View style={styles.cardIcon}>
              <Ionicons name="help-circle" color="#03CE87" size={30} />
            </View>
            <Text style={styles.titleText}>FAQ's</Text>
            <View style={styles.cardIcon}>
              <Ionicons name="chevron-forward" color="white" size={25} />
            </View>
          </TouchableOpacity>
          <InputText
            // onChangeText={text => setEmail(text)}
            placeholder="Title Here"
            placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
          />
          <MultiInputText
            // onChangeText={text => setEmail(text)}
            multiline={true}
            placeholder="Description Here"
            placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
          />
          <TouchableOpacity activeOpacity={0.7} style={styles.sendBtn}>
            <Text style={styles.titleText}>Send</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

export default Support;
