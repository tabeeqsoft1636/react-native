//import liraries
import React, {useRef} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import DropdownAlert from 'react-native-dropdownalert';
import {DeleteContact} from '../../Theme/apiCalls';

import {styles, TextinputView, InputText} from './style';

function ContactInfo(props) {
  let dropDownAlertRef = useRef();
  const conatctDetail = props?.route?.params?.item_selected?.item;

  const Fields = [
    {
      fieldTitle: 'email',
      placeholder: 'Type Your Email...',
      imgSrc: require('assets/images/Message.png'),
      keyboardType: 'email-address',
      selectedValue: `${conatctDetail?.email}`,
    },
    {
      fieldTitle: 'phone',
      placeholder: 'Phone Number...',
      imgSrc: require('assets/images/Phone.png'),
      keyboardType: 'phone-pad',
      selectedValue: `${conatctDetail?.phone}`,
    },
  ];

  const Types = {
    business: 'Business',
    sidegig: 'Side Gig',
    personal: 'Personal',
  };

  const unfollowContact = async () => {
    const {id: profile_id, profileType: profile_type} = conatctDetail;
    if (profile_id && profile_type) {
      const payload = {profile_id, profile_type: Types[profile_type]};
      try {
        DeleteContact(payload, async res => {
          if (res.sucess) {
            dropDownAlertRef.alertWithType(
              'success',
              'Success',
              'Successfully Delete Account',
            );
            props.navigation.goBack();
          } else {
            dropDownAlertRef.alertWithType('error', 'Error', res?.error);
          }
        });
      } catch (error) {
        if (error.response) {
          dropDownAlertRef.alertWithType(
            'error',
            'Error',
            error.response.data.detail,
          );
        } else {
          // Something happened in setting up the request that triggered an Error
          console.log('Error', error.message);
        }
      }
    } else {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Contact info is missing',
      );
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.headerView}>
          <TouchableOpacity
            style={styles.backContainer}
            onPress={() => props.navigation.goBack()}>
            <Image
              style={styles.backIcon}
              source={require('assets/images/right.png')}
            />
          </TouchableOpacity>
          <View style={styles.profileContainer}>
            <Text style={styles.titleText}>Profile</Text>
          </View>
        </View>

        <ScrollView>
          <View style={styles.imageContainer}>
            <Image
              style={styles.profileImage}
              source={require('assets/svgs/profile.png')}
            />
            <View style={styles.profileNameContainer}>
              <Text style={styles.profileText}>
                {conatctDetail?.name === '' ? 'User' : conatctDetail?.name}
              </Text>
              <Image
                style={styles.verifyIcon}
                source={require('assets/svgs/tick.png')}
              />
            </View>
          </View>

          <View style={styles.iconsContainer}>
            <TouchableOpacity
              style={[styles.icon, {backgroundColor: '#F66A3E'}]}
              onPress={() => props.navigation.navigate('shareScreen')}>
              <Image source={require('assets/svgs/share.png')} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.icon, {backgroundColor: '#FF2D55'}]}
              onPress={unfollowContact}>
              <Image source={require('assets/svgs/delete.png')} />
            </TouchableOpacity>
          </View>

          {Fields.map((item, index) => {
            return (
              <TextinputView key={index}>
                <Image style={{width: 20, height: 20}} source={item?.imgSrc} />
                <InputText
                  placeholder={item?.placeholder}
                  editable={false}
                  value={
                    item?.selectedValue === ''
                      ? item?.placeholder
                      : item?.selectedValue
                  }
                  placeholderTextColor={'red'}
                  keyboardType={item?.keyboardType}
                />
              </TextinputView>
            );
          })}
        </ScrollView>
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </SafeAreaView>
  );
}

export default ContactInfo;
