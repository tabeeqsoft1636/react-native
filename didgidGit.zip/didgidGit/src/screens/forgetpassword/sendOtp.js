/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
  ScrollView,
  Platform,
} from 'react-native';
import DropdownAlert from 'react-native-dropdownalert';
import {expressions} from '../../utils/functions';
import {sendOTP} from 'theme/apiCalls';
// create a component
function sendOtp(props) {
  const [number, setNumber] = useState('');
  let dropDownAlertRef = useRef();

  const validation = () => {
    let valid = true;
    if (number === '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Email');
    } else if (!expressions.email.test(number) || number.includes(' ')) {
      dropDownAlertRef.alertWithType('error', 'Error', 'Invalid Email Address');
    } else {
      return valid;
      // props.navigation.navigate('VerifyOtp')
    }
  };
  const apiCall = async () => {
    let valid = validation();
    if (valid) {
      const userDetail = {
        email: number,
      };
      try {
        sendOTP(userDetail, async res => {
          console.log('res', res);
          if (res.sucess) {
            props.navigation.navigate('VerifyOtp', {email: number});
          } else {
            dropDownAlertRef.alertWithType('error', 'Error', res.error);
          }
        });
      } catch (error) {
        if (error.res) {
          console.log(error.res.data);
          dropDownAlertRef.alertWithType(
            'error',
            'Error',
            error.res.data.detail,
          );
        } else {
          // Something happened in setting up the request that triggered an Error
          console.log('Error', error.message);
        }
      }
    }
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      <View style={{flex: 1}}>
        <ScrollView
          contentContainerStyle={{flexGrow: 1, paddingBottom: 60}}
          showsVerticalScrollIndicator={false}>
          <View style={{alignItems: 'center', justifyContent: 'center'}}>
            <Image
              resizeMode="contain"
              style={styles.logoStyle}
              source={require('../../assets/images/logo.png')}
            />
          </View>

          <View>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontSize: 22, fontWeight: '600'}}>
              Please Enter Your Email To Recover Your Account
            </Text>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontSize: 14, marginVertical: 15}}>
              Use the email address in your Personal profile to receive an text
              verification code.
            </Text>
          </View>
          <View style={{paddingVertical: '10%'}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#2D2D2D',
                borderRadius: 10,
                height: 55,
              }}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginLeft: '2%'}}
                source={require('../../assets/images/Message.png')}
              />
              <TextInput
                onChangeText={text => setNumber(text)}
                style={{
                  backgroundColor: '#2D2D2D',
                  width: '90%',
                  textAlign: 'center',
                  color: 'white',
                  borderRadius: 10,
                  fontSize: 14,
                  // paddingVertical: 15,
                }}
                placeholder="Type Your Email"
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
          </View>

          <TouchableOpacity onPress={() => apiCall()} style={styles.btnStyle}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Send OTP
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </KeyboardAvoidingView>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 30,
    backgroundColor: 'black',
    justifyContent: 'space-around',
  },
  logoStyle: {
    width: '100%',
    height: '34%',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
});

//make this component available to the app
export default sendOtp;
