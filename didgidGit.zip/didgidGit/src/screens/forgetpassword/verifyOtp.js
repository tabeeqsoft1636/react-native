//import liraries
import React, {Component, useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import DropdownAlert from 'react-native-dropdownalert';
import axios from 'axios';
import {verifyOtp} from 'theme/apiCalls';
function VerifyOtp(props) {
  const {email} = props.route.params;
  const [otp, setotp] = useState('');
  let dropDownAlertRef = useRef();

  const validation = () => {
    if (otp == '') {
      console.log('true');
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter The OTP');
    } else {
      return true;
    }
  };
  const reSendOtp = async () => {
    const userDetail = {
      email: email,
      otp: otp,
    };
    try {
      verifyOtp(userDetail, async res => {
        console.log('aa', res);
        if (res.data) {
          console.log(res.data);
          // if (res.data === 'OTP sent successfully')
          dropDownAlertRef.alertWithType(
            'success',
            'Success',
            'OTP verified successfully',
          );
          props.navigation.navigate('SetPassword');
        } else {
        }
      });
    } catch (error) {
      if (error.res) {
        console.log(error.res.data);
        dropDownAlertRef.alertWithType('error', 'Error', error.res.data.detail);
      } else {
        // Something happened in setting up the request that triggered an Error
        console.log('Error', error.message);
      }
    }
  };
  const apiCall = async () => {
    let valid = validation();
    if (valid) {
      const userDetail = {
        email: email,
        otp: otp,
      };
      try {
        verifyOtp(userDetail, async res => {
          if (res.sucess) {
            dropDownAlertRef.alertWithType(
              'success',
              'Success',
              'OTP verified successfully',
            );
            await AsyncStorage.setItem(
              'token',
              JSON.stringify(res.sucess.token),
            );
            props.navigation.navigate('SetPassword', {response: res.sucess});
          } else {
            dropDownAlertRef.alertWithType(
              'error',
              'Error',
              res?.error?.detail,
            );
          }
        });
      } catch (error) {
        if (error.res) {
          console.log(error.res.data);
          dropDownAlertRef.alertWithType(
            'error',
            'Error',
            error.res.data.detail,
          );
        } else {
          // Something happened in setting up the request that triggered an Error
          console.log('Error', error.message);
        }
      }
    }
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      <View style={{}}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <Image
            resizeMode="contain"
            style={styles.logoStyle}
            source={require('../../assets/images/logo.png')}
          />
        </View>
        <View>
          <Text
            allowFontScaling={false}
            style={{color: 'white', fontSize: 22, fontWeight: '600'}}>
            Please Enter The Verification Code We Sent To Your Email
          </Text>
          <Text
            allowFontScaling={false}
            style={{color: 'white', fontSize: 14, marginVertical: 15}}>
            Enter the 4-digit code we sent to the email address on your Personal
            profile via email.
          </Text>
        </View>
        <View style={{paddingVertical: '5%', alignItems: 'center'}}>
          <OTPInputView
            style={{width: '80%', height: 50, borderRadius: 10}}
            codeInputFieldStyle={{
              borderRadius: 10,
              borderColor: null,
              backgroundColor: '#2D2D2D',
            }}
            codeInputHighlightStyle={{borderColor: '#03CE87'}}
            onCodeFilled={code => {
              setotp(code);
            }}
            pinCount={4}
          />
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            paddingBottom: '5%',
          }}>
          <TouchableOpacity onPress={() => reSendOtp()}>
            <Text
              allowFontScaling={false}
              style={{color: '#F5365B', fontSize: 10}}>
              Click Here.
            </Text>
          </TouchableOpacity>
          <Text allowFontScaling={false} style={{color: 'white', fontSize: 10}}>
            To Resend{' '}
          </Text>
        </View>
        <TouchableOpacity onPress={() => apiCall()} style={styles.btnStyle}>
          <Text
            allowFontScaling={false}
            style={{color: 'white', fontWeight: '500', fontSize: 14}}>
            Verify OTP
          </Text>
        </TouchableOpacity>
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </KeyboardAvoidingView>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 30,
    backgroundColor: 'black',
    justifyContent: 'space-around',
  },
  logoStyle: {
    width: '100%',
    height: '34%',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
});

//make this component available to the app
export default VerifyOtp;
