/* eslint-disable react-hooks/rules-of-hooks */
//import liraries
import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
// import { style } from './styles';
// import { TextInput } from 'react-native-paper';
import DropdownAlert from 'react-native-dropdownalert';
import axios from 'axios';
import {passwordSet} from 'theme/apiCalls';
// create a component
function setPassword(props) {
  const [password, setPassword] = useState('');
  const [repassword, setRepassword] = useState('');
  let dropDownAlertRef = useRef();
  const {response} = props.route.params;
  const token = response.token;
  const validation = () => {
    if (password == '') {
      dropDownAlertRef.alertWithType('error', 'Error', 'Enter Your Password');
    } else if (repassword == '') {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Enter Your Confirm Password',
      );
    } else if (password.length < 5) {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Ensure password has at least 5 characters',
      );
    } else if (password !== repassword) {
      dropDownAlertRef.alertWithType('error', 'Error', 'Password Do not Match');
    } else {
      return true;
      // props.navigation.navigate('LoginScreen');
    }
  };
  const apiCall = async () => {
    let valid = validation();
    if (valid) {
      const userDetail = {
        password_1: password,
        password_2: repassword,
      };
      try {
        passwordSet(userDetail, async res => {
          if (res.sucess) {
            console.log(res);
            props.navigation.navigate('LoginScreen');
          } else {
          }
        });
      } catch (error) {
        if (error.res) {
          console.log(error.res.data);
          dropDownAlertRef.alertWithType(
            'error',
            'Error',
            error.res.data.detail,
          );
        } else {
          console.log('Error', error.message);
        }
      }
    }
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      <View style={{flex: 1}}>
        {/* <ScrollView showsVerticalScrollIndicator={false}> */}
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          <Image
            resizeMode="contain"
            style={styles.logoStyle}
            source={require('../../assets/images/logo.png')}
          />
        </View>

        <ScrollView
          contentContainerStyle={{paddingBottom: 60}}
          showsVerticalScrollIndicator={false}>
          <View style={{display: 'flex'}}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontSize: 22, fontWeight: '600'}}>
              Please Set New Password
            </Text>
            <Text style={{color: 'white', fontSize: 14, marginVertical: 15}}>
              Enter a password that meets the following criteria:
            </Text>
            <Text style={{color: 'white', fontSize: 14}}>
              - Minimum of 8 characters
            </Text>
            <Text style={{color: 'white', fontSize: 14}}>
              - Minimum one Capital letter
            </Text>
            <Text style={{color: 'white', fontSize: 14}}>
              - Minimum one numeric (0-9)
            </Text>
            <Text style={{color: 'white', fontSize: 14}}>
              - At least one special character (ex. *&%@...)
            </Text>
          </View>

          <View style={{paddingVertical: '10%'}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#2D2D2D',
                borderRadius: 10,
                marginBottom: '8%',
                height: 55,
                // padding: 10,
              }}>
              <Image
                style={{width: 17, height: 19, marginLeft: '3%'}}
                source={require('../../assets/images/Lock.png')}
              />
              <TextInput
                style={{
                  backgroundColor: '#2D2D2D',
                  width: '90%',
                  textAlign: 'center',
                  color: 'white',
                  borderRadius: 10,
                  fontSize: 14,
                }}
                placeholder="Type Your Password"
                onChangeText={text => setPassword(text)}
                secureTextEntry={true}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#2D2D2D',
                borderRadius: 10,
                height: 55,
                // padding: 10,
              }}>
              <Image
                style={{width: 17, height: 19, marginLeft: '3%'}}
                source={require('../../assets/images/Lock.png')}
              />
              <TextInput
                style={{
                  backgroundColor: '#2D2D2D',
                  width: '90%',
                  textAlign: 'center',
                  color: 'white',
                  borderRadius: 10,
                  fontSize: 14,
                }}
                placeholder="Type Your Password"
                onChangeText={text => setRepassword(text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
                secureTextEntry={true}
              />
            </View>
          </View>

          <TouchableOpacity onPress={() => apiCall()} style={styles.btnStyle}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Update
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
      <DropdownAlert
        ref={ref => {
          dropDownAlertRef = ref;
        }}
      />
    </KeyboardAvoidingView>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 30,
    backgroundColor: 'black',
    justifyContent: 'space-around',
  },
  logoStyle: {
    width: '100%',
    height: '34%',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    alignItems: 'center',
  },
});

//make this component available to the app
export default setPassword;
