//import liraries
import React, {Component, useState, useRef, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import {AsyncStorage} from 'theme/Libraries';

import DropDownPicker from 'react-native-dropdown-picker';
import {inviteFriends} from 'theme/apiCalls';
import DropdownAlert from 'react-native-dropdownalert';
function SendRequest(props) {
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [profile, setProfile] = useState('');
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState('');
  const [items, setItems] = useState([
    {label: 'Email', value: 'email'},
    {label: 'Number', value: 'sms'},
  ]);
  let dropDownAlertRef = useRef();
  useEffect(() => {
    setProfile(props.valueData);
  }, [props.valueData]);
  const next = async () => {
    if (!phone && !email && !profile && !value) {
      dropDownAlertRef.alertWithType(
        'error',
        'Error',
        'Please Enter all Detail',
      );
    } else {
      apiCall();
    }
  };

  const apiCall = async () => {
    try {
      const dataobj = {
        email: email,
        phone: phone,
        method: 'sms',
        profile: profile,
      };
      inviteFriends(dataobj, res => {
        if (res.sucess) {
          dropDownAlertRef.alertWithType(
            'sucess',
            'Invited Successfully',
            res.sucess,
          );
          props.navigation.navigate('Contacts');
        } else {
          dropDownAlertRef.alertWithType('error', 'Error', res.error);
        }
      });
    } catch (error) {
      dropDownAlertRef.alertWithType('error', 'Error', error);
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.container}>
          <View style={styles.flatListView}>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginLeft: '5%'}}
                source={require('assets/images/bag.png')}
              />
              <TextInput
                placeholder="Email"
                style={styles.textInputStyle}
                onChangeText={text => setEmail(text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            <View style={styles.inputView}>
              <Image
                resizeMode="contain"
                style={{width: 20, height: 20, marginLeft: '5%'}}
                source={require('assets/images/Phone.png')}
              />
              <TextInput
                placeholder="Phone Number"
                keyboardType="phone-pad"
                style={styles.textInputStyle}
                onChangeText={text => setPhone(text)}
                placeholderTextColor={'rgba(255, 255, 255, 0.6)'}
              />
            </View>
            {/* <View style={styles.inputView}> */}

            <DropDownPicker
              open={open}
              value={value}
              items={items}
              setOpen={setOpen}
              setValue={setValue}
              setItems={setItems}
              zIndex={50}
              placeholder={'Choose The Type Of Contact'}
              placeholderStyle={{
                color: 'rgba(255, 255, 255, 0.6)',
                fontSize: 12,
                alignSelf: 'center',
                textAlign: 'center',
                width: '100%',
              }}
              dropDownContainerStyle={{
                borderWidth: 3,
                borderColor: '#2d2d2d',
                backgroundColor: '#2d2d2d',
                color: '#fff',
                width: '93%',
                alignSelf: 'center',
                marginTop: '5%',
              }}
              textStyle={styles.HeadingText}
              style={{
                backgroundColor: '#2d2d2d',
                borderWidth: 0,
                borderRadius: 10,
                width: '93%',
                alignSelf: 'center',
                marginTop: '5%',
              }}
              listItemContainerStyle={{
                backgroundColor: '#2d2d2d',
                borderColor: 'rgba(255, 255, 255, 0.6)',
                borderWidth: 1,
                borderRadius: 10,
                marginTop: 5,
              }}
            />
            {/* </View> */}
            <View
              style={{
                flex: 1,
                marginTop: '50%',
                backgroundColor: '#000',
                // position:"absolute",
                width: '100%',
              }}>
              <TouchableOpacity
                onPress={() => {
                  next();
                  // props.navigation.navigate('MainAllContacts')
                }}
                style={styles.btnView}>
                <Text style={styles.btnText}>Request</Text>
              </TouchableOpacity>
            </View>
          </View>
          <DropdownAlert
            ref={ref => {
              dropDownAlertRef = ref;
            }}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  flatListView: {
    flex: 1,
    // marginTop: "6%"
  },
  inputView: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 55,
    backgroundColor: '#2d2d2d',
    borderRadius: 10,
    width: '93%',
    alignSelf: 'center',
    marginTop: '6%',
  },
  textInputStyle: {
    backgroundColor: '#2d2d2d',
    width: '90%',
    textAlign: 'center',
    color: '#fff',
    borderRadius: 10,
    fontSize: 14,
    alignSelf: 'center',
  },
  HeadingText: {
    backgroundColor: '#2d2d2d',
    width: '100%',
    textAlign: 'center',
    color: 'rgba(255, 255, 255, 0.6)',
    borderRadius: 10,
    fontSize: 14,
    alignSelf: 'center',
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '93%',
    marginTop: '2%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
});
export default SendRequest;
