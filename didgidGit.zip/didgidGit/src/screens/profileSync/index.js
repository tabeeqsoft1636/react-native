//import liraries
import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  KeyboardAvoidingView,
  TouchableOpacity,
  SafeAreaView,
  PermissionsAndroid,
  Platform,
  ActivityIndicator,
} from 'react-native';
import Contacts from 'react-native-contacts';
function profileSync(props) {
  const [isLoading, setIsLoading] = useState(false);
  const _onContinueBusiness = async () => {
    setIsLoading(true);
    if (Platform.OS === 'android') {
      PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
        title: 'Contacts',
        message: 'This app would like to view your contacts.',
      }).then(() => {
        loadContacts();
      });
    } else {
      loadContacts();
    }
  };

  const loadContacts = async () => {
    Contacts.getAll()
      .then(async contacts => {
        setIsLoading(false);
        props.navigation.navigate('contactList', {
          contacts: contacts.filter(item => item.phoneNumbers.length > 0),
        });
      })
      .catch(e => {
        setIsLoading(false);
        alert('Permission to access contacts was denied');
        console.warn('Permission to access contacts was denied', e);
      });
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      {/* {getName == 'Business' && ( */}
      {isLoading ? (
        <View style={[styles.Loadercontainer, styles.Loaderhorizontal]}>
          <ActivityIndicator size="large" color={'#fff'} />
        </View>
      ) : (
        <View style={{}}>
          <SafeAreaView />
          <View style={styles.mainContainer}>
            <TouchableOpacity
              style={styles.back}
              onPress={() => props.navigation.goBack()}>
              <Image
                resizeMode="contain"
                style={styles.imageView}
                source={require('../../../assets/images/right.png')}
              />
            </TouchableOpacity>
            <Text style={styles.profileText}>
              Please Allow The Digidex To Sync Your Contacts
            </Text>
            <Text style={styles.profileDesc}>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.{' '}
            </Text>
          </View>
          <View style={{marginTop: 30}}>
            <Image
              resizeMode="contain"
              style={styles.syncImage}
              source={require('../../../assets/images/sync.png')}
            />
          </View>
          <TouchableOpacity
            onPress={() => {
              _onContinueBusiness();
            }}
            style={styles.btnView}>
            <Text style={styles.btnText}>Sync Now</Text>
          </TouchableOpacity>
        </View>
      )}
      {/* )} */}
    </KeyboardAvoidingView>
  );
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  btnStyle: {
    backgroundColor: '#009360',
    paddingVertical: '5%',
    borderRadius: 10,
    // alignItems: 'center',
  },
  imageView: {
    marginBottom: 17,
  },
  syncImage: {
    marginBottom: 17,
    alignSelf: 'center',
  },
  profileText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '600',
    fontStyle: 'normal',
    fontSize: 22,
  },
  profileDesc: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 13,
    marginTop: 10,
  },
  profileDesc1: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '400',
    fontStyle: 'normal',
    fontSize: 14,
    marginTop: 10,
    textAlign: 'center',
  },
  mainContainer: {
    marginTop: '8%',
    flexDirection: 'column',
    marginLeft: 15,
  },
  btnView: {
    backgroundColor: '#009360',
    borderRadius: 12,
    width: '80%',
    marginTop: '10%',
    padding: 20,
    alignSelf: 'center',
  },
  btnText: {
    color: '#FFFFFF',
    fontFamily: 'Rubik-Regular',
    fontWeight: '500',
    fontStyle: 'normal',
    fontSize: 14,
    textAlign: 'center',
  },
  back: {
    width: '10%',
  },
  Loadercontainer: {
    flex: 1,
    justifyContent: 'center',
  },
  Loadehorizontal: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
  },

  Loaderbackground: {
    position: 'absolute',
    marginTop: 20,
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    opacity: 0.5,
  },
});

//make this component available to the app
export default profileSync;
