//import liraries
import React, {Component, useState, useRef} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {
  Container,
  CardWrapper,
  DotView,
  ActiveDot,
  DotStyleView,
  LogoImage,
  TextWrapper,
  DescriptionText,
  DescriptionText2,
  NextBtn,
} from './style';
// create a component
function OnBoarding3(props) {
  return (
    <Container>
      <View style={{alignItems: 'center', flex: 0.9, justifyContent: 'center'}}>
        <LogoImage
          resizeMode="contain"
          style={styles.logoStyle}
          source={require('../../assets/images/Boarding1.png')}
        />
      </View>
      <CardWrapper>
        <DotView>
          <DotStyleView />
          <DotStyleView />
          <ActiveDot />
        </DotView>
        <TextWrapper>
          <DescriptionText>Begin Using Digidex</DescriptionText>
          <DescriptionText2 allowFontScaling={false}>
            Once you have a profile established you can import contacts from
            your phone as well as invite those contacts to also join Digidex.
            Once you are connected with Digidex you will never lose contact...
          </DescriptionText2>
        </TextWrapper>
        <View style={{paddingVertical: '5%'}}>
          <NextBtn onPress={() => props.navigation.navigate('WelcomeScreen')}>
            <Text
              allowFontScaling={false}
              style={{color: 'white', fontWeight: '500', fontSize: 14}}>
              Get Started
            </Text>
          </NextBtn>
        </View>
      </CardWrapper>
    </Container>
  );
}

// define your styles
const styles = StyleSheet.create({});

//make this component available to the app
export default OnBoarding3;
