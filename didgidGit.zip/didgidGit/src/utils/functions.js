import {Dimensions, Platform, PixelRatio, StatusBar} from 'react-native';
import {isIphoneX} from 'react-native-iphone-x-helper';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

// based on iphone 5s's scale
// const scale = SCREEN_WIDTH / 320;

// export function normalize(size) {
//   const newSize = size * scale
//   if (Platform.OS === 'ios') {
//     return Math.round(PixelRatio.roundToNearestPixel(newSize))
//   } else {
//     return Math.round(PixelRatio.roundToNearestPixel(newSize)) - 2
//   }
// }
const {width, height} = Dimensions.get('window');
const guidelineBaseWidth = 350;
const guidelineBaseHeight = 680;
const [shortDimension, longDimension] =
  width < height ? [width, height] : [height, width];
export const normalize = size => (shortDimension / guidelineBaseWidth) * size;
// export function normalize(size, uncontrolled = false) {
//     const fontSize = (SCREEN_HEIGHT / 680) * size;
//     if (uncontrolled) {
//       return fontSize;
//     } else {
//       return fontSize > 20 ? 20 : fontSize;
//     }
//   }

export const wp = p => width * (p / 100);
export const hp = p => height * (p / 100);
export const expressions = {
  email: /^\w+([+.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
};
