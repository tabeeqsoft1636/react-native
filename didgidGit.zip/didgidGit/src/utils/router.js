import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';
import {Image, View} from 'react-native';
import Splash1 from 'src/screens/splash/splash';
import loginScreen from 'src/screens/login';
import sendOtp from 'src/screens/forgetpassword/sendOtp';
import VerifyOtp from 'src/screens/forgetpassword/verifyOtp';
import setPassword from 'src/screens/forgetpassword/setPassword';
import signUp from 'src/screens/signup/signup';
import profileSetup from 'src/screens/profileSetup';
import userProfileSetup from 'src/screens/userProfileSetup';
import profileSetupImage from 'src/screens/profileSetupImage';
import profileSetupSocial from 'src/screens/profileSetupSocial';
import profileVerifyOtp from 'src/screens/profileVerifyOtp';
import numberOtpVerify from 'src/screens/numberOtpVerify';
import contactList from 'src/screens/ContactList';
import MainAllContacts from 'src/screens/MainAllContacts';
import MainRequest from 'src/screens/MainRequest';
import profileSync from 'src/screens/profileSync';
// import SendRequest from 'src/screens/SendRequest';
// import Dashboard from 'src/screens/dashboard';
import Welcome from 'src/screens/splash/welcome';
import OnBoarding1 from 'src/screens/onBoardingOne';
import OnBoarding2 from 'src/screens/onBoardingTwo';
import OnBoarding3 from 'src/screens/onBoardingThree';
import profileSettings from 'src/screens/profileSettings';
import shareScreen from 'src/screens/share';
import AppSettings from '../screens/appSettings';
import contactInfo from '../screens/contactInfo';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Privacy from '../screens/privacy';
import Terms from '../screens/terms';
import Support from '../screens/support';
const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function MyBottomTabs() {
  return (
    <View style={{backgroundColor: 'black', flexGrow: 1}}>
      <Tab.Navigator
        initialRouteName="MainAllContacts"
        backBehavior="initialRoute"
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#03CE87',
          tabBarStyle: {
            backgroundColor: '#2D2D2D',
            width: '100%',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            //android//
            // height: 60,
            // paddingTop: 5,
            // paddingBottom: 10,
            //android//

            //ios//
            height: 80,
            paddingTop: 5,
            paddingBottom: 30,
            //ios//
            borderTopWidth: 0,
          },
        }}>
        <Tab.Screen
          name="Contacts"
          component={MainAllContacts}
          options={{
            tabBarIcon: ({color, focused}) => (
              <View style={{}}>
                {focused && (
                  <View
                    style={{
                      borderColor: '#03CE87',
                      borderWidth: 2,
                      borderRadius: 10,
                      top: -7,
                      width: 50,
                    }}
                  />
                )}
                <Image
                  source={require('../../assets/images/home.png')}
                  style={{tintColor: color, alignSelf: 'center'}}
                />
              </View>
            ),
          }}
        />
        <Tab.Screen
          name="Requests"
          component={MainRequest}
          options={{
            tabBarIcon: ({color, focused}) => (
              <View style={{}}>
                {focused && (
                  <View
                    style={{
                      borderColor: '#03CE87',
                      borderWidth: 2,
                      borderRadius: 10,
                      top: -7,
                      width: 50,
                    }}
                  />
                )}
                <Image
                  source={require('../../assets/images/Add-User.png')}
                  style={{tintColor: color, alignSelf: 'center'}}
                />
              </View>
            ),
          }}
        />
        <Tab.Screen
          name="Account"
          component={profileSettings}
          options={{
            tabBarIcon: ({color, focused}) => (
              <View style={{}}>
                {focused && (
                  <View
                    style={{
                      borderColor: '#03CE87',
                      borderWidth: 2,
                      borderRadius: 10,
                      top: -7,
                      width: 50,
                    }}
                  />
                )}
                <Image
                  source={require('../../assets/images/user12.png')}
                  style={{tintColor: color, alignSelf: 'center'}}
                />
              </View>
            ),
          }}
        />
        <Tab.Screen
          name="Settings"
          component={AppSettings}
          options={{
            tabBarIcon: ({color, focused}) => (
              <View style={{}}>
                {focused && (
                  <View
                    style={{
                      borderColor: '#03CE87',
                      borderWidth: 2,
                      borderRadius: 10,
                      top: -7,
                      width: 50,
                    }}
                  />
                )}
                <Image
                  source={require('../../assets/images/settings.png')}
                  style={{tintColor: color, alignSelf: 'center'}}
                />
              </View>
            ),
          }}
        />
      </Tab.Navigator>
    </View>
  );
}

const AppContainer = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
          gestureEnabled: false,
        }}>
        <Stack.Screen name="SplashScreen" component={Splash1} />
        <Stack.Screen name="MainAllContacts" component={MyBottomTabs} />
        <Stack.Screen name="LoginScreen" component={loginScreen} />
        <Stack.Screen name="otpScreen" component={sendOtp} />
        <Stack.Screen name="VerifyOtp" component={VerifyOtp} />
        <Stack.Screen name="SetPassword" component={setPassword} />
        <Stack.Screen name="SignUpScreen" component={signUp} />
        <Stack.Screen name="contactList" component={contactList} />
        <Stack.Screen name="WelcomeScreen" component={Welcome} />
        <Stack.Screen name="Boarding1Screen" component={OnBoarding1} />
        <Stack.Screen name="Boarding2Screen" component={OnBoarding2} />
        <Stack.Screen name="Boarding3Screen" component={OnBoarding3} />
        <Stack.Screen name="userProfileSetup" component={userProfileSetup} />
        <Stack.Screen name="profileSetupImage" component={profileSetupImage} />
        <Stack.Screen name="contactInfo" component={contactInfo} />
        <Stack.Screen
          name="profileSetupSocial"
          component={profileSetupSocial}
        />

        <Stack.Screen name="numberOtpVerify" component={numberOtpVerify} />
        <Stack.Screen name="profileVerifyOtp" component={profileVerifyOtp} />
        <Stack.Screen name="profileSync" component={profileSync} />
        <Stack.Screen name="profileSetup" component={profileSetup} />
        <Stack.Screen name="shareScreen" component={shareScreen} />
        <Stack.Screen name="privacy" component={Privacy} />
        <Stack.Screen name="terms" component={Terms} />
        <Stack.Screen name="support" component={Support} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

//make this component available to the app
export default AppContainer;
