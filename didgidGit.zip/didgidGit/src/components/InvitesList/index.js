import React, {memo, useState} from 'react';
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Platform,
  ActivityIndicator,
} from 'react-native';

import PropTypes from 'prop-types';
import Avatar from '../Avatar';
import {AcceptorDecline} from 'theme/apiCalls';
const getAvatarInitials = textString => {
  if (!textString) {
    return '';
  }
  const text = textString.trim();
  const textSplit = text.split(' ');
  if (textSplit.length <= 1) {
    return text.charAt(0);
  }
  const initials =
    textSplit[0].charAt(0) + textSplit[textSplit.length - 1].charAt(0);
  return initials;
};

const ListItem = props => {
  const [isLoading, setIsLoading] = useState(false);

  const {item, InvitesList} = props;
  const select = async status => {
    try {
      setIsLoading(true);
      const objData = {
        contact_request: item.item.id,
        status: status,
      };
      AcceptorDecline(objData, res => {
        setIsLoading(false);
        if (res.sucess) {
          InvitesList();
        } else {
          // eslint-disable-next-line no-alert
          alert(JSON.stringify(res.error));
        }
      });
    } catch (error) {
      setIsLoading(false);
    }
  };
  return (
    <>
      {isLoading ? (
        <View style={[styles.Loadercontainer, styles.Loaderhorizontal]}>
          <ActivityIndicator size="large" color={'#fff'} />
        </View>
      ) : (
        <View>
          <TouchableOpacity>
            <View style={styles.itemContainer}>
              <View style={styles.leftElementContainer}>
                <Avatar
                  img={
                    item.hasThumbnail ? {uri: item.thumbnailPath} : undefined
                  }
                  placeholder={getAvatarInitials(
                    `${item.givenName} ${item.familyName}`,
                  )}
                  width={55}
                  height={55}
                  roundedPlaceholder={false}
                />
              </View>
              <View style={styles.rightSectionContainer}>
                <View style={styles.mainTitleContainer}>
                  <Text style={styles.titleStyle}>
                    {Platform.OS === 'android'
                      ? item.item.profile.length < 13
                        ? `${item.item.profile}`
                        : `${item.item.profile.substring(0, 13)}...`
                      : `${item.item.profile}`}
                  </Text>
                  <Text style={styles.titleStyle}>
                    {Platform.OS === 'android'
                      ? item.item.phone.length < 13
                        ? `${item.item.phone}`
                        : `${item.item.phone.substring(0, 13)}...`
                      : `${item.item.phone}`}
                  </Text>
                </View>
              </View>

              <View style={styles.btnView}>
                <TouchableOpacity
                  onPress={() => select('Accept')}
                  style={styles.accetView}>
                  <Text style={styles.acceptTitle}>Accept</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => select('Decline')}
                  style={styles.rejectView}>
                  <Text style={styles.rejectTitle}>Reject</Text>
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    minHeight: 44,
    height: 63,
    backgroundColor: '#2D2D2D',
    marginHorizontal: '4%',
    borderRadius: 12,
    marginBottom: 10,
  },
  leftElementContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 2,
    paddingLeft: 13,
  },
  rightSectionContainer: {
    marginLeft: 18,
    flexDirection: 'row',
    flex: 20,
    // borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: '#515151',
  },
  mainTitleContainer: {
    justifyContent: 'center',
    flexDirection: 'column',
    flex: 1,
  },
  titleStyle: {
    fontSize: 16,
    color: '#fff',
    marginLeft: 9,
  },
  btnView: {
    position: 'absolute',
    right: 10,
    alignSelf: 'center',
    flexDirection: 'row',
  },
  accetView: {backgroundColor: '#03CE87', borderRadius: 12, padding: 12},
  acceptTitle: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '400',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
  rejectView: {
    backgroundColor: '#FF2D55',
    borderRadius: 12,
    padding: 12,
    marginLeft: 10,
  },
  rejectTitle: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '400',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
  Loadercontainer: {
    flex: 1,
    justifyContent: 'center',
  },
  Loadehorizontal: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
  },

  Loaderbackground: {
    position: 'absolute',
    marginTop: 20,
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    opacity: 0.5,
  },
});

export default memo(ListItem);

ListItem.propTypes = {
  item: PropTypes.object,
  onPress: PropTypes.func,
};
