// Access Device’s Contact List in React Native App
// https://aboutreact.com/access-contact-list-react-native/

import React, {useState} from 'react';
import {StyleSheet, Image} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';

const Dropdown = ({placeholder = 'Select Value...', ...props}) => {
  const [open, setOpen] = useState(false);
  return (
    <DropDownPicker
      open={open}
      setOpen={setOpen}
      placeholder={placeholder}
      placeholderStyle={styles.placeholderStyle}
      dropDownContainerStyle={styles.dropDownContainerStyle}
      textStyle={styles.textStyle}
      style={styles.mainStyle}
      listItemContainerStyle={styles.listItemContainerStyle}
      ArrowDownIconComponent={() => (
        <Image source={require('../../../assets/images/downarrow.png')} />
      )}
      {...props}
    />
  );
};

const styles = StyleSheet.create({
  placeholderStyle: {
    color: 'red',
    fontSize: 12,
    alignSelf: 'center',
    textAlign: 'center',
    width: '100%',
  },
  dropDownContainerStyle: {
    borderRadius: 15,
    backgroundColor: 'pink',
  },
  textStyle: {
    color: '#FF2D55',
    fontSize: 13,
    fontWeight: '400',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
  mainStyle: {
    color: '#FF2D55',
    borderWidth: 0,
    backgroundColor: '#000',
  },
  listItemContainerStyle: {
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#000',
  },
});

export default Dropdown;
