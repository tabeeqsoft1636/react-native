// Access Device’s Contact List in React Native App
// https://aboutreact.com/access-contact-list-react-native/

import React, {memo} from 'react';
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Image,
  Platform,
  Linking,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import PropTypes from 'prop-types';
import Avatar from '../Avatar';

const getAvatarInitials = textString => {
  if (!textString) return '';
  const text = textString.trim();
  const textSplit = text.split(' ');
  if (textSplit.length <= 1) return text.charAt(0);
  const initials =
    textSplit[0].charAt(0) + textSplit[textSplit.length - 1].charAt(0);
  return initials;
};

const ListItem = props => {
  const {item, contactType} = props;
  const navigation = useNavigation();

  const getProfileInfo = () => {
    navigation.navigate('contactInfo', {
      item_selected: item,
      contactType: contactType,
    });
  };

  return (
    <TouchableOpacity onPress={getProfileInfo}>
      <View style={styles.itemContainer}>
        <View style={styles.leftElementContainer}>
          <Avatar
            img={item.hasThumbnail ? {uri: item.thumbnailPath} : undefined}
            placeholder={getAvatarInitials(
              `${item.givenName} ${item.familyName}`,
            )}
            width={55}
            height={55}
            roundedPlaceholder={false}
          />
        </View>

        <View style={styles.rightSectionContainer}>
          <View style={styles.mainTitleContainer}>
            <Text style={styles.titleStyle}>
              {Platform.OS === 'android'
                ? item.item.name.length < 12
                  ? `${item.item.name}`
                  : `${item.item.name.substring(0, 13)}...`
                : `${item.item.name}`}
            </Text>
            <Text style={styles.titleStyle}>
              {Platform.OS === 'android'
                ? item.item.phone.length < 12
                  ? `${item.item.phone}`
                  : `${item.item.phone.substring(0, 13)}...`
                : `${item.item.phone}`}
            </Text>
          </View>
        </View>
        <View style={styles.btnView}>
          <TouchableOpacity
            style={styles.mailView}
            onPress={async () =>
              item.item.email
                ? await Linking.openURL(`mailto:${item.item.email}`)
                : alert('Invalid Email')
            }>
            <Image
              resizeMode="contain"
              style={{width: 25, height: 25}}
              source={require('../../../assets/images/Message.png')}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.accetView}
            onPress={() =>
              item.item.phone
                ? Linking.openURL(`tel:${item.item.phone}`)
                : alert('Invalid Phone Number')
            }>
            <Image
              resizeMode="contain"
              style={{width: 18, height: 18}}
              source={require('../../../assets/images/call.png')}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.rejectView}
            onPress={() =>
              item.item.phone
                ? Linking.openURL(`sms:${item.item.phone}`)
                : alert('Invalid Phone Number')
            }>
            <Image
              resizeMode="contain"
              style={{width: 18, height: 18}}
              source={require('../../../assets/images/chat.png')}
            />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    minHeight: 44,
    height: 63,
    backgroundColor: '#2D2D2D',
    marginHorizontal: '4%',
    borderRadius: 12,
    marginBottom: 10,
  },
  leftElementContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 2,
    paddingLeft: 13,
  },
  rightSectionContainer: {
    marginLeft: 18,
    flexDirection: 'row',
    flex: 20,
    // borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: '#515151',
  },
  mainTitleContainer: {
    justifyContent: 'center',
    flexDirection: 'column',
    flex: 1,
  },
  titleStyle: {
    fontSize: 16,
    color: '#fff',
    marginLeft: 9,
  },
  btnView: {
    position: 'absolute',
    right: 10,
    alignSelf: 'center',
    flexDirection: 'row',
  },
  mailView: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 8,
  },
  accetView: {
    backgroundColor: '#03CE87',
    borderRadius: 12,
    padding: 12,
    marginHorizontal: 10,
  },
  acceptTitle: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '400',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
  rejectView: {
    backgroundColor: '#F66A3E',
    borderRadius: 12,
    padding: 12,
  },
  rejectTitle: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '400',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
    alignSelf: 'center',
    textAlign: 'center',
  },
});

export default memo(ListItem);

ListItem.propTypes = {
  item: PropTypes.object,
  onPress: PropTypes.func,
};
