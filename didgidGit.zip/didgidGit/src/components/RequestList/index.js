// Access Device’s Contact List in React Native App
// https://aboutreact.com/access-contact-list-react-native/

import React, { memo, useEffect, useState } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Image, AsyncStorage } from 'react-native';

import PropTypes from 'prop-types';
import Avatar from '../Avatar';
import { getTotalDiskCapacityOld } from 'react-native-device-info';

const getAvatarInitials = (textString) => {
  if (!textString) return '';
  const text = textString.trim();
  const textSplit = text.split(' ');
  if (textSplit.length <= 1) return text.charAt(0);
  const initials =
    textSplit[0].charAt(0) + textSplit[textSplit.length - 1].charAt(0);
  return initials;
};

const ListItem = (props) => {
  const [phoneData, setPhoneData] = useState([]);
  const shouldComponentUpdate = () => {
    return false;
  };
  const { item, onPress, selected } = props;
  return (
    <View>
      <TouchableOpacity >

        <View style={styles.itemContainer}>
          <View style={styles.leftElementContainer}>
            <Avatar
              img={
                item.hasThumbnail ?
                  { uri: item.thumbnailPath } : undefined
              }
              placeholder={getAvatarInitials(
                `${item.givenName} ${item.familyName}`,
              )}
              width={55}
              height={55}
              roundedPlaceholder={false}
            />
          </View>
          <View style={styles.rightSectionContainer}>
            <View style={styles.mainTitleContainer}>
              {/* <Text
                style={
                  styles.titleStyle
                }>{item.item.profile}</Text> */}
              <Text style={
                styles.titleStyle
              }>
                {Platform.OS === 'android' ? item.item.profile.length < 12
                  ? `${item.item.profile}`
                  : `${item.item.profile.substring(0, 13)}...` : `${item.item.profile}`}
              </Text>
              <Text
                style={
                  styles.titleStyle
                }>{Platform.OS === 'android' ? item.item.phone.length < 12
                ? `${item.item.phone}`
                : `${item.item.phone.substring(0, 13)}...` : `${item.item.phone}`}</Text>
            </View>
          </View>

          <View style={styles.btnView}>

            <TouchableOpacity style={styles.rejectView}>
              <Text style={styles.rejectTitle}>
                {item?.item?.status}
              </Text>
            </TouchableOpacity>
          </View>

        </View>
      </TouchableOpacity >
    </View >
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    minHeight: 44,
    height: 63,
    backgroundColor: "#2D2D2D",
    marginHorizontal: "4%",
    borderRadius: 12,
    marginBottom: 10
  },
  leftElementContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 2,
    paddingLeft: 13,
  },
  rightSectionContainer: {
    marginLeft: 18,
    flexDirection: 'row',
    flex: 20,
    // borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: '#515151',
  },
  mainTitleContainer: {
    justifyContent: 'center',
    flexDirection: 'column',
    flex: 1,
  },
  titleStyle: {
    fontSize: 16,
    color: "#fff",
    marginLeft: 9
  },
  btnView: { position: "absolute", right: 10, alignSelf: "center", flexDirection: "row", width: "100%", justifyContent: "flex-end" },
  rejectView: { backgroundColor: "#FF2D55", borderRadius: 12, padding: 12, width: "30%", },
  rejectTitle: {
    color: "#fff", fontSize: 12, fontWeight: "400", fontFamily: "Rubik-Regular",
    fontStyle: "normal", alignSelf: "center", textAlign: "center"
  }
});

export default memo(ListItem);

ListItem.propTypes = {
  item: PropTypes.object,
  onPress: PropTypes.func,
};
