import {Color} from '@modules/login/screens/styles';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  mainContainer: {
    flex: 1,
    padding: 20,
    marginTop: 20,
  },
  iconsContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    alignSelf: 'center',
  },

  icon: {
    borderRadius: 12,
    margin: 5,
    width: 41,
    height: 41,
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 10,
  },

  backIcon: {
    width: 34,
    height: 34,
  },

  headerView: {
    flexDirection: 'row',
    marginTop: 30,
    width: '100%',
  },

  backContainer: {
    width: '30%',
    paddingLeft: 20,
    justifyContent: 'center',
  },

  titleText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },
  logoutText: {
    color: '#FF2D55',
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'Rubik-Regular',
    fontStyle: 'normal',
  },
  logoutBtn: {
    paddingVertical: 10,
    marginTop: 10,
    alignItems: 'center',
  },
  cardView: {
    backgroundColor: '#2D2D2D',
    padding: 15,
    borderRadius: 12,
    minHeight: 55,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
  cardIcon: {
    width: 30,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  seperator: {
    paddingVertical: 10,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.6)',
  },
  modalView: {
    backgroundColor: '#2D2D2D',
    borderRadius: 20,
    padding: 35,
    paddingTop: 20,
    alignItems: 'center',
  },
  modalTitle: {
    marginBottom: 25,
    color: '#FF2D55',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 25,
    textAlign: 'center',
    fontWeight: '400',
  },
  button: {
    width: '100%',
    borderRadius: 15,
    padding: 10,
    height: 55,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonNo: {
    backgroundColor: '#FF2D55',
  },
  buttonYes: {
    marginTop: 15,
    backgroundColor: '#03CE87',
  },
  error: {
    color: Color.red,
    marginLeft: 12,
    marginBottom: 20,
    fontSize: 12,
  },
});
