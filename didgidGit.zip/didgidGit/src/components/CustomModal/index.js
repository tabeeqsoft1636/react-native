import React from 'react';
import {Modal, Text, TouchableOpacity, View} from 'react-native';
import {styles} from './style';

function CustomModal(props) {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={props.visible}
      onRequestClose={() => {
        props.toggleModal?.();
      }}>
      <TouchableOpacity
        activeOpacity={1}
        style={styles.centeredView}
        onPress={() => props.toggleModal?.()}>
        <View style={styles.modalView}>
          <Text style={[styles.titleText, styles.modalTitle]}>
            {props.modalTitle}
          </Text>
          <Text style={[styles.titleText, styles.modalText]}>
            {props.warningMsg}
          </Text>
          <TouchableOpacity
            style={[styles.button, styles.buttonNo]}
            onPress={() => props.toggleModal?.()}>
            <Text style={styles.titleText}>No</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, styles.buttonYes]}
            onPress={props.callBackFunction}>
            <Text style={styles.titleText}>Yes</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

export default CustomModal;
