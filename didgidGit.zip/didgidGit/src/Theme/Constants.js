import { View, Text, Dimensions } from 'react-native';

const domain = 'https://ideapros-llc-digide-31969.botics.co/api/v1';
const Constants = {
  ApiPrefix: `${domain}`,
  windowWidth: Dimensions.get('window').width,
  windowHeight: Dimensions.get('window').height,
};

export default Constants;
