import {Constants} from 'theme';
import {AsyncStorage} from 'theme/Libraries';

const axios = require('axios');

const getHeader = async (auth, formData) => {
  const token = await AsyncStorage.getItem('token');
  console.log(token);

  let options = {};

  if (auth) {
    options = {
      Accept: 'application/json',
      'Content-Type': formData ? 'multipart/form-data' : 'application/json',
      Authorization: `Token ${JSON.parse(token)}`,
    };
  } else {
    options = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
  }
  return options;
};

const errorHandling = (error, myCallback) => {
  const res = error?.response?.data;
  let message = '';
  if (res) {
    if (res.non_field_errors) {
      message = res.non_field_errors[0];
    } else if (typeof res === 'string') {
      message = res;
    } else {
      for (const [key, value] of Object.entries(res)) {
        message = message + `${key} : ${JSON.stringify(value)} `;
      }
    }
  } else {
    if (typeof error === 'string') {
      message = error;
    } else {
      message = JSON.stringify(error);
    }
  }
  myCallback({error: message});
};

const postRequest = async (api, paylaod, myCallback, auth) => {
  const constApiLink = `${Constants.ApiPrefix}/${api}`;
  const headers = await getHeader(auth);
  console.log(headers);
  axios({
    url: constApiLink,
    method: 'POST',
    data: paylaod,
    headers,
  })
    .then(response => {
      console.log('sucess ======> ', response.data);
      myCallback({sucess: response.data});
    })
    .catch(error => {
      console.log('Error ======> ', error);
      errorHandling(error, myCallback);
    });
};

const patchRequest = async (api, paylaod, myCallback, auth) => {
  const constApiLink = `${Constants.ApiPrefix}/${api}`;
  console.log('PATCH API', constApiLink);
  const headers = await getHeader(auth);
  axios({
    url: constApiLink,
    method: 'PATCH',
    data: paylaod,
    headers,
  })
    .then(response => {
      myCallback({sucess: response.data});
    })
    .catch(error => {
      errorHandling(error, myCallback);
    });
};

const deleteRequest = async (api, paylaod, myCallback, auth) => {
  const constApiLink = `${Constants.ApiPrefix}/${api}`;
  const headers = await getHeader(auth);
  axios({
    url: constApiLink,
    method: 'DELETE',
    data: paylaod,
    headers,
  })
    .then(response => {
      myCallback({sucess: response.data});
    })
    .catch(error => {
      errorHandling(error, myCallback);
    });
};

const postRequestFormData = async (api, paylaod, myCallback, auth) => {
  const constApiLink = `${Constants.ApiPrefix}/${api}`;
  const headers = await getHeader(auth, true);
  axios({
    url: constApiLink,
    method: 'POST',
    data: paylaod,
    headers,
  })
    .then(response => {
      myCallback({sucess: response.data});
    })
    .catch(error => {
      errorHandling(error, myCallback);
    });
};

const postWithoutDataRequest = async (api, myCallback, auth) => {
  const constApiLink = `${Constants.ApiPrefix}/${api}`;
  console.log('API Call', constApiLink);
  const headers = await getHeader(auth);
  axios({
    url: constApiLink,
    method: 'POST',
    headers,
  })
    .then(response => {
      console.log('success ==> ', response.data);
      myCallback({sucess: response.data});
    })
    .catch(error => {
      errorHandling(error, myCallback);
    });
};

const getRequest = async (api, myCallback, auth) => {
  const constApiLink = `${Constants.ApiPrefix}/${api}`;
  console.log('getReq', constApiLink);

  const headers = await getHeader(auth);
  console.log(headers);

  axios({
    url: constApiLink,
    method: 'GET',
    headers,
  })
    .then(response => {
      myCallback({sucess: response.data});
    })
    .catch(error => {
      errorHandling(error, myCallback);
    });
};

export const SignupApi = (payload, myCallback) => {
  postRequest('users/', payload, myCallback);
};

export const LoginApi = (payload, myCallback) => {
  postRequest('users/login/', payload, myCallback);
};
export const DeleteApi = (User_id, myCallback) => {
  deleteRequest(`users/${User_id}/`, null, myCallback, true);
};

export const sendOTP = (payload, myCallback) => {
  postRequest('users/otp/', payload, myCallback);
};

export const verifyOtp = (payload, myCallback) => {
  postRequest('users/verify/', payload, myCallback);
};

export const passwordSet = (payload, myCallback) => {
  postRequest('users/password/', payload, myCallback, true);
};

export const verifyEmail = (payload, myCallback) => {
  postRequest('users/verify_email/', payload, myCallback, true);
};

export const verifyNumber = (payload, myCallback) => {
  postRequest('users/verify_sms/', payload, myCallback, true);
};

export const personal = myCallback => {
  postWithoutDataRequest('personal/', myCallback, true);
};

export const business = myCallback => {
  postWithoutDataRequest('business/', myCallback, true);
};

export const sideGig = myCallback => {
  postWithoutDataRequest('sidegig/', myCallback, true);
};

export const syncContact = (payload, myCallback) => {
  postRequest('contacts/', payload, myCallback);
};

export const businessPatch = (payload, id, myCallback) => {
  patchRequest(`users/${id}/`, payload, myCallback, true);
};
export const personalPtach = (payload, id, myCallback) => {
  patchRequest(`users/${id}/`, payload, myCallback, true);
};
export const sidegigPatch = (payload, id, myCallback) => {
  patchRequest(`users/${id}/`, payload, myCallback, true);
};

export const inviteFriends = (payload, myCallback) => {
  postRequest('sent-requests/invite/', payload, myCallback, true);
};

export const syncContactData = (payload, myCallback) => {
  postRequestFormData('sent-requests/sync/', payload, myCallback, true);
};

export const receivedInvitesAPI = myCallback => {
  getRequest('received-requests/?status=Pending', myCallback, true);
};

export const sendInvitesAPI = (myCallback, profileType) => {
  getRequest(
    `sent-requests/?status=Pending&profile=${profileType}`,
    myCallback,
    true,
  );
};
export const syncedContacts = (myCallback, profileType) => {
  if (profileType) {
    getRequest(`users/contacts/?profile=${profileType}`, myCallback, true);
  } else {
    getRequest('users/contacts/', myCallback, true);
  }
};
export const AcceptorDecline = (payload, myCallback) => {
  postRequest('received-requests/status/', payload, myCallback, true);
};

export const DeleteContact = (payload, myCallback) => {
  deleteRequest('sent-requests/unfollow/', payload, myCallback, true);
};

// export const getSyncContact = (paylaod, myCallback, token) => {
//   getRequest(`contact?userId=${paylaod}`, paylaod, myCallback, token);
// };
