import React from 'react';
import AppContainer from './utils/router';

const MyComponent = () => {
  return <AppContainer />;
};

export default MyComponent;
