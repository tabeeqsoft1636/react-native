import {useEffect, useCallback} from 'react';
import {useDispatch, useSelector} from 'react-redux';

const useRequests = () => {
  //   const navigation = useNavigation();
  const dispatch = useDispatch();
  const reduxData = useSelector(state => state);
  const {userSelections, apiData} = reduxData;

  const selectionUpdate = async (item, value) => {
    try {
      dispatch({
        type: 'SELECTIONS',
        data: {...userSelections, [item]: value},
      });
    } catch (err) {
      alert(JSON.stringify(err));
    }
  };

  const apiResponse = useCallback(
    (item, value) => {
      try {
        dispatch({
          type: 'API_DATA',
          data: {...apiData, [item]: value},
        });
      } catch (err) {
        alert(JSON.stringify(err));
      }
    },
    [apiData, dispatch],
  );

  const setSelectedContact = useCallback(
    (item, value) => {
      try {
        dispatch({
          type: 'Selected_Contact',
          data: {...SelectedContact, [item]: value},
        });
      } catch (err) {
        alert(JSON.stringify(err));
      }
    },
    [SelectedContact, dispatch],
  );

  return {
    userSelections,
    selectionUpdate,
    apiResponse,
    setSelectedContact,
  };
};
export default useRequests;
