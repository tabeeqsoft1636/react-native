import Home from './Home.svg';
import Paws from './Paws.svg';
import Notification from './Notification.svg';

import EyeshowSVG from './eyeopen.svg';
import EyehideSVG from './eyeclosed.svg';
import NextarrowSVG from './nextarrow.svg';
import AddSVG from './add.svg';
import SearchSVG from './search.svg';
import SaveSVG from './filesave.svg';
import IdSVG from './id.svg';
import SelfieSVG from './selfie.svg';
import ComplainSVG from './complain.svg';
import CancelSVG from './cancel.svg';
import BeneficiarySVG from './beneficiary.svg';
import ConfirmSVG from './confirm.svg';
import UserdetailSVG from './userdetail.svg';
import CrossSVG from './cross.svg';
import UsernameSVG from './username.svg';
import LockSVG from './lock.svg';
import AddressVG from './address.svg';
import WebsiteSVG from './website.svg';
import LeftarrowSVG from './leftarrow.svg';
import NewTicketSVG from './newticket.svg';
import ReportSVG from './report.svg';
import FileSVG from './file.svg';
import NewSVG from './new.svg';
import CashWidthDrawel from './cashWidthDrawel.svg';
import CashDeposit from './cashDeposit.svg';
import UploadSVG from './upload.svg';
import WPSSVG from './w_p_s.svg';
import OnlineTracSVG from './fingerprint.svg';
import LoginSVG from './loginSVG.svg';
import DocVerificationSVG from './docVerification.svg';
import HistorySVG from './history.svg';
import InvestmentSVG from './investment.svg';
import OthersSVG from './others.svg';
import DatePickerSVG from './datepicker.svg';
import AccountSVG from './accounting.svg';
import BillSVG from './bill.svg';
import CardReceiptSVG from './card-receipt.svg';
import CloseSVG from './close.svg';
import LogoutSVG from './logout.svg';
import PhoneSVG from './phone.svg';
import EmailSVG from './email.svg';
import UserSVG from './user.svg';
import DownloadSVG from './downloadSVG.svg';
import WalletSVG from './wallet.svg';

export {
  Home,
  Paws,
  EyehideSVG,
  EyeshowSVG,
  NextarrowSVG,
  AddSVG,
  UploadSVG,
  LeftarrowSVG,
  NewTicketSVG,
  FileSVG,
  NewSVG,
  ReportSVG,
  SearchSVG,
  AddressVG,
  DatePickerSVG,
  WebsiteSVG,
  ConfirmSVG,
  UserdetailSVG,
  CrossSVG,
  UsernameSVG,
  LockSVG,
  SaveSVG,
  SelfieSVG,
  ComplainSVG,
  IdSVG,
  CancelSVG,
  BeneficiarySVG,
  Notification,
  CashWidthDrawel,
  LoginSVG,
  CashDeposit,
  WPSSVG,
  OnlineTracSVG,
  DocVerificationSVG,
  HistorySVG,
  OthersSVG,
  AccountSVG,
  BillSVG,
  CardReceiptSVG,
  InvestmentSVG,
  CloseSVG,
  LogoutSVG,
  PhoneSVG,
  EmailSVG,
  UserSVG,
  DownloadSVG,
  WalletSVG,
};
