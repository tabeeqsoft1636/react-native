const images = {
  SPLASH_LOGO: require('./Images/SplashLogo.png'),
  Logo: require('./Images/Logo.png'),

  PASSWORD: require('./Images/Icons/Password.png'),
  USERNAME: require('./Images/Icons/UserName.png'),
  pictures: require('./Images/Icons/pictures.png'),

  welcomLogo: require('./Images/welcomLogo.png'),
  WelcomeImage1: require('./Images/WelcomeImage1.png'),
  WelcomeImage2: require('./Images/WelcomeImage2.png'),
  WelcomeImage3: require('./Images/WelcomeImage3.png'),
  WelcomeIcon1: require('./Images/WelcomeIcon1.png'),
  WelcomeIcon2: require('./Images/welcomeIcon2.png'),
  EclipseIcon1: require('./Images/EclipseIcon1.png'),
  EclipseIcon2: require('./Images/EclipseIcon2.png'),
  EclipseIcon3: require('./Images/EclipseIcon3.png'),
  NurseIcon: require('./Images/nurseIcon.png'),
  Welcome3: require('./Images/welcome3.png'),
  TermsIcon: require('./Images/termsIcon.png'),
  UserProfile: require('./Images/userprofile.png'),
  RightArrow: require('./Images/rightarrow.png'),
  LefttArrow: require('./Images/leftarrow.png'),
  VisaPic: require('./Images/visa.png'),
  Email: require('./Images/Email.png'),
  PawtaiPaws: require('./Images/PawtaiPaws.png'),
  DrawerIcon: require('./Images/drawer_icon.png'),
  ProfileImage: require('./Images/profile_image.png'),
  LocationIcon: require('./Images/Pin.png'),
};

export default images;
