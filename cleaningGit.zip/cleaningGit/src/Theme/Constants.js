import {Dimensions} from 'react-native';

const domain = 'https://wandering-term-34267.botics.co';
const Constants = {
  BASE_URL: `${domain}/api/v1/`,
  windowWidth: Dimensions.get('window').width,
  windowHeight: Dimensions.get('window').height,
  GOOGLE_PLACES_API_KEY: 'AIzaSyAGyMgnRN-ZRhXjozAmIHWoYBf9VXHmbrw',
  STRIPE_KEY: {
    publishableKey: 'pk_test_qblFNYngBkEdjEZ16jxxoWSM',
    merchantIdentifier: 'merchant.com.wandering_term_34267',
  },
};

export default Constants;
