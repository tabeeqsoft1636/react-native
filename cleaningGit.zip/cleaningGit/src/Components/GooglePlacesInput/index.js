import React from 'react';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';

import {Constants} from 'theme';

const GooglePlacesInput = props => {
  return (
    <GooglePlacesAutocomplete
      listViewDisplayed={false}
      keepResultsAfterBlur={true}
      textInputProps={{placeholderTextColor: '#5d5d5d'}}
      placeholder="Search"
      query={{
        key: Constants.GOOGLE_PLACES_API_KEY,
        language: 'en',
      }}
      onPress={(data, details = null) => props.setLocation(data, details)}
      onFail={error => console.error(error)}
      fetchDetails={true}
      styles={{
        textInput: {
          height: 38,
          color: '#5d5d5d',
          fontSize: 16,
        },
        predefinedPlacesDescription: {
          color: '#1faadb',
        },
      }}
    />
  );
};

export default GooglePlacesInput;
