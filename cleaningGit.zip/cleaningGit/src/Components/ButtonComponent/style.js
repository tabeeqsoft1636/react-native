import styled from 'styled-components/native';
import {Colors} from '../../Theme';

export const Input = styled.TextInput`
  flex: 1;
  margin-left: 5px;
`;

export const Icon = styled.Image`
  width: 15px;
  height: 15px;
`;

export const ButtonWrapper = styled.TouchableOpacity`
  background-color: ${props => (props.color ? props.color : '#FFFFFF47')};
  align-self: center;
  justify-content: center;
  flex-direction: row;
  align-items: center;
  margin-top: 10px;
  padding: 15px;
  width: 100%;
`;

export const ButtonText = styled.Text`
  font-size: 17px;
  color: ${Colors.white};
  font-weight: 700;
  text-align: center;
`;
export const ButtonIcon = styled.Image`
  height: 15px;
  width: 15px;
`;
