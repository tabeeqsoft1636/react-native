import {Spinner} from 'native-base';
import React from 'react';
import {ButtonWrapper, ButtonIcon, ButtonText} from './style';
const ImageButton = ({...props}) => (
  <ButtonWrapper {...props}>
    {props.loading ? (
      <Spinner size="small" color={'white'} />
    ) : (
      <>
        <ButtonText style={props.textStyle}>{props.buttonText}</ButtonText>
        {props.Image && <ButtonIcon source={props.Image} />}
      </>
    )}
  </ButtonWrapper>
);

export default ImageButton;
