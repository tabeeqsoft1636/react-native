import React from 'react';
import {Wrapper, Input, Icon, RightIcon} from './styles';
import {Colors} from '../../Theme';

const InputField = ({
  placeholder,
  icon,
  rightIcon,
  iconStyle,
  rightIconStyle,
  onChangeText,
  bgColorCode,
  ...props
}) => {
  return (
    <Wrapper bgColorCode={bgColorCode}>
      {icon && <Icon source={icon} iconStyle={iconStyle} />}
      <Input
        placeholder={placeholder}
        placeholderTextColor={Colors.themeGreyText}
        onChangeText={onChangeText}
        {...props}
      />
      {rightIcon && (
        <RightIcon source={rightIcon} rightIconStyle={rightIconStyle} />
      )}
    </Wrapper>
  );
};

export default InputField;
