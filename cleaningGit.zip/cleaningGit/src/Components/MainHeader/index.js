import React from 'react';
import {View, SafeAreaView} from 'react-native';

import styles from './styles';

const MainHeader = ({children, isLight = true}) => {
  return (
    <View
      style={{width: '100%', backgroundColor: isLight ? '#fff' : '#4f45a8'}}>
      <SafeAreaView>
        <View style={styles.mainContainer}>{children}</View>
      </SafeAreaView>
    </View>
  );
};

export default MainHeader;
