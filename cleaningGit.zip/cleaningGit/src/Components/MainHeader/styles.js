import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    justifyContent: 'flex-end',
    paddingVertical: 10,
    flexDirection: 'row',
  },
});

export default styles;
