import {StyleSheet} from 'react-native';
import {colors} from 'react-native-elements';

export const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  flexGrow: {
    flexGrow: 1,
  },
  drawerItem: {
    // backgroundColor: 'transparent',
  },
  textView: {
    backgroundColor: 'red',
  },
  headerView: {
    paddingVertical: 30,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  headerText: {
    fontSize: 28,
    color: colors.white,
    fontWeight: 'bold',
  },
  label: {
    fontSize: 17,
  },
});
