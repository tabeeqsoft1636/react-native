import {DrawerContentScrollView, DrawerItem} from '@react-navigation/drawer';
import React from 'react';
import {Image, Text, View} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import colors from '../../Theme/Colors';
import {styles} from './styles';
import bin from '../../Assets/Images/bin.png';
import feed from '../../Assets/Images/feed.png';
import key from '../../Assets/Images/key.png';
import logout from '../../Assets/Images/logout.png';
import message from '../../Assets/Images/message.png';
import shield from '../../Assets/Images/shield.png';
import {DrawerActions} from '@react-navigation/native';
import {useNavigation} from '@react-navigation/native';
import {AsyncStorage} from 'theme/Libraries';

function Sidebar(props) {
  const inset = useSafeAreaInsets();
  const navigation = useNavigation();

  const SIDE_MENU = [
    {
      id: 0,
      title: 'Privacy Policy',
      icon: pro => <Image source={shield} {...pro} />,
      navigateTo: 'PrivacyScreen',
    },
    {
      id: 1,
      title: 'Terms & Condition',
      icon: pro => <Image source={feed} {...pro} />,
      navigateTo: 'TermsandConditions',
    },
    {
      id: 2,
      title: 'Change Password',
      icon: pro => <Image source={key} {...pro} />,
      navigateTo: 'ChangePassword',
    },
    {
      id: 3,
      title: 'Feedback',
      icon: pro => <Image source={message} {...pro} />,
      navigateTo: 'Feedback',
    },
    {
      id: 4,
      title: 'Delete Profile',
      icon: pro => <Image source={bin} {...pro} />,
      navigateTo: 'DeleteProfile',
    },
    {
      id: 5,
      title: 'Logout',
      icon: pro => <Image source={logout} {...pro} />,
      function: () => {
        AsyncStorage.clear();
        navigation.navigate('SignupScreen');
      },
    },
  ];
  return (
    <React.Fragment>
      <View style={[styles.headerView, {marginTop: inset.top}]}>
        <Text style={styles.headerText}>Lauras</Text>
      </View>

      <DrawerContentScrollView
        {...props}
        contentContainerStyle={[styles.flexGrow]}
        bounces={false}>
        <View style={[styles.flex]}>
          {SIDE_MENU.map(({icon: Icon, ...item}) => (
            <DrawerItem
              pressColor={'rgba(0,0,0,0.2)'}
              key={`DRAWER_ITEM_LIST_${item.id}`}
              style={styles.drawerItem}
              activeBackgroundColor={'rgba(0,0,0,0.2)'}
              activeTintColor={colors.white}
              inactiveTintColor={colors.white}
              label={labelProps => (
                <Text
                  style={[
                    {color: labelProps.color},
                    styles.label,
                    styles.flex,
                  ]}>
                  {item.title}
                </Text>
              )}
              icon={iconProp => Icon()}
              onPress={() => {
                if (item.navigateTo) {
                  props.navigation.navigate(item.navigateTo);
                  // props.navigation.dispatch(DrawerActions.toggleDrawer());
                } else {
                  item.function();
                }
              }}
            />
          ))}
        </View>
      </DrawerContentScrollView>
    </React.Fragment>
  );
}

export default React.memo(Sidebar);
