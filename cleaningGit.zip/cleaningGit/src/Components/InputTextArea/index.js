import React from 'react';
import {Wrapper, Icon, RightIcon} from './styles';
import {Colors} from '../../Theme';
import {TextArea} from 'react-native-ui-lib';

const InputTextArea = ({
  placeholder,
  icon,
  rightIcon,
  iconStyle,
  rightIconStyle,
  onChangeText,
  bgColorCode,
  ...props
}) => {
  return (
    <Wrapper bgColorCode={bgColorCode}>
      {icon && <Icon source={icon} iconStyle={iconStyle} />}
      <TextArea
        placeholder={placeholder}
        placeholderTextColor={Colors.themeGreyText}
        onChangeText={onChangeText}
        {...props}
      />
      {rightIcon && (
        <RightIcon source={rightIcon} rightIconStyle={rightIconStyle} />
      )}
    </Wrapper>
  );
};

export default InputTextArea;
