import styled, {css} from 'styled-components/native';
import {Colors} from '../../Theme';

export const Input = styled.TextInput`
  flex: 1;
  margin-left: 5px;
  color: #000;
`;

export const Icon = styled.Image`
  ${props =>
    props.iconStyle
      ? css`
          width: ${props.iconStyle.width}px;
          height: ${props.iconStyle.height}px;
        `
      : css`
          width: 15px;
          height: 15px;
        `}
`;

export const RightIcon = styled.Image`
  ${props =>
    props.rightIconStyle
      ? css`
          width: ${props.rightIconStyle.width}px;
          height: ${props.rightIconStyle.height}px;
        `
      : css`
          width: 30px;
          height: 30px;
          resize-mode: contain;
        `}
`;

export const Wrapper = styled.View`
  background-color: ${props =>
    props.bgColorCode ? props.bgColorCode : '#efefef'};
  flex-direction: row;
  align-self: center;
  justify-content: center;
  align-items: center;
  border-color: grey;
  padding-horizontal: 10px;
  width: 100%;
  height: 100px;
`;

export const Loginlabel = styled.Text`
  margin-top: 10px;
  align-self: center;
  font-size: 34px;
  color: ${Colors.white};
  font-weight: 700;
`;
