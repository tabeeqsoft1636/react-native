import * as RNLocalize from "react-native-localize"

export { RNLocalize }
