import axios from 'axios';
import {AsyncStorage} from 'theme/Libraries';
export const BASE_URL = 'https://wandering-term-34267.botics.co';

const POST_CALL = (api, payload, myCallback) => {
  axios
    .post(api, payload)
    .then(res => {
      myCallback({sucess: res});
    })
    .catch(error => {
      errorHandler(error, myCallback);
    });
};

const AUTH_POST_CALL = async (api, payload, myCallback) => {
  let token = await AsyncStorage.getItem('@token');
  token = JSON.parse(token);
  axios
    .post(api, payload, {
      headers: {
        Authorization: `Token ${token}`,
      },
    })
    .then(res => {
      myCallback({sucess: res});
    })
    .catch(error => {
      errorHandler(error, myCallback);
    });
};

const AUTH_GET_CALL = async (api, myCallback) => {
  let token = await AsyncStorage.getItem('@token');
  token = JSON.parse(token);
  axios
    .get(api, {
      headers: {
        Authorization: `Token ${token}`,
      },
    })
    .then(res => {
      myCallback({sucess: res.data});
    })
    .catch(error => {
      errorHandler(error, myCallback);
    });
};

const AUTH_PUT_CALL = async (api, payload, myCallback) => {
  let token = await AsyncStorage.getItem('@token');
  token = JSON.parse(token);
  axios
    .put(api, payload, {
      headers: {
        Authorization: `Token ${token}`,
      },
    })
    .then(res => {
      myCallback({sucess: res.data});
    })
    .catch(error => {
      errorHandler(error, myCallback);
    });
};

const GET_CALL = (api, myCallback) => {
  axios
    .get(api)
    .then(res => {
      myCallback({sucess: res.data});
    })
    .catch(error => {
      errorHandler(error, myCallback);
    });
};

const PUT_CALL_FORMDATA = async (api, payload, myCallback) => {
  axios({
    method: 'put',
    url: api,
    data: payload,
    headers: {'Content-Type': 'multipart/form-data'},
  })
    .then(res => {
      myCallback({sucess: res});
    })
    .catch(error => {
      errorHandler(error, myCallback);
    });
};

const errorHandler = (error, myCallback) => {
  console.log('error ======> ');
  console.log();
  console.log(JSON.stringify(error));
  console.log();
  console.log('<=========');
  if (error.message === 'Network Error') {
    // eslint-disable-next-line no-alert
    alert('Network Error Please check you internet connection');
    myCallback({error: error});
  } else {
    if (error.response) {
      let message = error.response.data;
      if (error.response.status === 500) {
        message = {Network: [error.response.statusText]};
      }
      myCallback({error: message});
    } else {
      myCallback({error: error});
    }
  }
};

function apiLoginRequest(payload, myCallback) {
  const api = `${BASE_URL}/api/v1/login/`;
  POST_CALL(api, payload, myCallback);
}

const apiSignupRequest = (payload, myCallback) => {
  const api = `${BASE_URL}/api/v1/signup/`;
  POST_CALL(api, payload, myCallback);
};

const apiServiceRequest = myCallback => {
  const api = `${BASE_URL}/api/v1/service/?limit=100&offset=0`;
  GET_CALL(api, myCallback);
};

const apiBedroomList = myCallback => {
  const api = `${BASE_URL}/api/v1/room/?limit=100&offset=0`;
  GET_CALL(api, myCallback);
};

const apiBathroomList = myCallback => {
  const api = `${BASE_URL}/api/v1/bathroom/?limit=100&offset=0`;
  GET_CALL(api, myCallback);
};

const apiExtrasList = myCallback => {
  const api = `${BASE_URL}/api/v1/extra/?limit=100&offset=0`;
  GET_CALL(api, myCallback);
};

const apiGetInList = myCallback => {
  const api = `${BASE_URL}/api/v1/howdoweget/?limit=100&offset=0`;
  GET_CALL(api, myCallback);
};

const apiProfileUpdate = (payload, myCallback) => {
  const api = `${BASE_URL}/api/v1/profile/`;
  PUT_CALL_FORMDATA(api, payload, myCallback);
};

const apiHistoryRequest = (payload, myCallback) => {
  const api = `${BASE_URL}/api/v1/history/`;
  AUTH_POST_CALL(api, payload, myCallback);
};

const apiHistoryDetailsRequest = myCallback => {
  const api = `${BASE_URL}/api/v1/historydetails/?limit=100&offset=0`;
  AUTH_GET_CALL(api, myCallback);
};

const apiCleanerHistoryRequest = myCallback => {
  const api = `${BASE_URL}/api/v1/cleaner-history/?limit=100&offset=0`;
  AUTH_GET_CALL(api, myCallback);
};

const apiCleanerHistoryDeatilsRequest = (myCallback, id) => {
  const api = `${BASE_URL}/api/v1/cleaner_history_details/${id}/`;
  AUTH_GET_CALL(api, myCallback);
};

const apiAcceptRequest = (payload, myCallback) => {
  const api = `${BASE_URL}/api/v1/accept_request/`;
  AUTH_PUT_CALL(api, payload, myCallback);
};

const apiCleanerAllHistoryRequest = myCallback => {
  const api = `${BASE_URL}/api/v1/cleaner_all_history/?limit=100&offset=0`;
  AUTH_GET_CALL(api, myCallback);
};

const apiCleanerTotalEarning = myCallback => {
  const api = `${BASE_URL}/api/v1/cleaner_wallet/`;
  AUTH_GET_CALL(api, myCallback);
};

export const api = {
  apiLoginRequest,
  apiSignupRequest,
  apiServiceRequest,
  apiBedroomList,
  apiBathroomList,
  apiExtrasList,
  apiProfileUpdate,
  apiHistoryRequest,
  apiGetInList,
  apiHistoryDetailsRequest,
  apiCleanerHistoryRequest,
  apiCleanerHistoryDeatilsRequest,
  apiAcceptRequest,
  apiCleanerAllHistoryRequest,
  apiCleanerTotalEarning,
};
