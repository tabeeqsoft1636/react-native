import {createStore} from 'redux';

const initialState = {
  USER_DETAIL: {},
  TOKEN: '',
  price: '',
  rooms: [],
  bathrooms: [],
  selectedBedroom: '',
  selectedBathroom: '',
  userSelections: {},
  apiData: {},
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case 'USER_DETAIL': {
      return {...state, USER_DETAIL: action.data};
    }
    case 'TOKEN': {
      return {...state, TOKEN: action.data};
    }
    case 'PRICE_UPDATE': {
      return {...state, price: action.data};
    }

    case 'UPDATE_ROOM_SELECTION': {
      return {...state, selectedBedroom: action.data};
    }
    case 'UPDATE_BATHROOM_SELECTION': {
      return {...state, selectedBathroom: action.data};
    }
    case 'ROOMS_LIST': {
      return {...state, rooms: action.data};
    }
    case 'BATHROOMS_LIST': {
      return {...state, bathrooms: action.data};
    }

    case 'SELECTIONS': {
      return {...state, userSelections: action.data};
    }
  }
  return state;
};

export const Store = createStore(reducer);
