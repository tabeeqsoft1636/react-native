import React from 'react';
import {DrawerContentScrollView, DrawerItem} from '@react-navigation/drawer';
import {Image, Text, View} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {AsyncStorage} from 'theme/Libraries';
import colors from 'theme/Colors';
import bin from 'assets/Images/bin.png';
import feed from 'assets/Images/feed.png';
import key from 'assets/Images/key.png';
import logout from 'assets/Images/logout.png';
import message from 'assets/Images/message.png';
import shield from 'assets/Images/shield.png';
import {useNavigation} from '@react-navigation/native';

import {styles} from './styles';

function Sidebar(props) {
  const inset = useSafeAreaInsets();
  const navigation = useNavigation();

  const SIDE_MENU = [
    {
      id: 0,
      title: 'Privacy Policy',
      icon: prop => <Image source={shield} {...prop} />,
      navigateTo: 'PrivacyScreen',
    },
    {
      id: 1,
      title: 'Terms & Condition',
      icon: prop => <Image source={feed} {...prop} />,
      navigateTo: 'TermsandConditions',
    },
    {
      id: 2,
      title: 'Change Password',
      icon: prop => <Image source={key} {...prop} />,
      navigateTo: 'ChangePassword',
    },
    {
      id: 3,
      title: 'Feedback',
      icon: prop => <Image source={message} {...prop} />,
      navigateTo: 'Feedback',
    },
    {
      id: 4,
      title: 'Delete Profile',
      icon: prop => <Image source={bin} {...prop} />,
      navigateTo: 'DeleteProfile',
    },
    {
      id: 5,
      title: 'Logout',
      icon: props => <Image source={logout} {...props} />,
      function: () => {
        AsyncStorage.clear();
        navigation.navigate('LoginScreen');
      },
    },
  ];
  return (
    <React.Fragment>
      <View style={[styles.headerView, {marginTop: inset.top}]}>
        <Text style={styles.headerText}>Lauras</Text>
      </View>

      <DrawerContentScrollView
        {...props}
        contentContainerStyle={[styles.flexGrow]}
        bounces={false}>
        <View style={[styles.flex]}>
          {SIDE_MENU.map(({icon: Icon, ...item}) => (
            <DrawerItem
              pressColor={'rgba(0,0,0,0.2)'}
              key={`DRAWER_ITEM_LIST_${item.id}`}
              style={styles.drawerItem}
              activeBackgroundColor={'rgba(0,0,0,0.2)'}
              activeTintColor={colors.white}
              inactiveTintColor={colors.white}
              label={labelProps => (
                <Text
                  style={[
                    {color: labelProps.color},
                    styles.label,
                    styles.flex,
                  ]}>
                  {item.title}
                </Text>
              )}
              icon={iconProp => Icon()}
              onPress={() => {
                if (item.navigateTo) {
                  navigation.navigate(item.navigateTo);
                } else {
                  item.function();
                }
              }}
            />
          ))}
        </View>
      </DrawerContentScrollView>
    </React.Fragment>
  );
}

export default React.memo(Sidebar);
