import React from 'react';
import {createDrawerNavigator} from '@react-navigation/drawer';
import Sidebar from './Sidebar';
import MyBottomTabs from './bottomtab';

import colors from 'theme/Colors';

const Drawer = createDrawerNavigator();

const MyDrawer = () => {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
        drawerType: 'slide',
      }}
      drawerStyle={{
        flex: 1,
        backgroundColor: colors.themeColor,
        borderRightWidth: 0,
        borderWidth: 0,
        shadowOpacity: 0,
        elevation: 0,
      }}
      sceneContainerStyle={{backgroundColor: colors.themeColor}}
      drawerContent={props => <Sidebar {...props} />}>
      <Drawer.Screen name="CleanerHome" component={MyBottomTabs} />
    </Drawer.Navigator>
  );
};

export default MyDrawer;
