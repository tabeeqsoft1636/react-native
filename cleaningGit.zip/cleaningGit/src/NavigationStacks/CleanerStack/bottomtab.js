import React from 'react';
import {createMaterialBottomTabNavigator} from '@react-navigation/material-bottom-tabs';
import {HistorySVG, Home, UserSVG, WalletSVG} from 'theme/SVG';

import {
  CleanerHistory,
  CleanerAllHistory,
  CleanerProfileScreen,
  WalletScreen,
} from 'cleaner';

const Tab = createMaterialBottomTabNavigator();

const TABS = [
  {
    name: 'Home',
    component: CleanerHistory,
    Icon: Home,
    tabBarLabel: 'Home',
  },
  {
    name: 'History',
    component: CleanerAllHistory,
    Icon: HistorySVG,

    tabBarLabel: 'History',
  },
  {
    name: 'WalletScreen',
    component: WalletScreen,
    tabBarLabel: 'Wallet',
    Icon: WalletSVG,
  },
  {
    name: 'Profile',
    component: CleanerProfileScreen,
    tabBarLabel: 'Profile',
    Icon: UserSVG,
  },
];

const MyBottomTabs = () => {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      activeColor="#4F45A8"
      inactiveColor="#919191"
      barStyle={{
        backgroundColor: '#EFEFEF',
        height: 60,
        justifyContent: 'center',
      }}
      labeled={true}>
      {TABS.map((item, index) => {
        const Icon = item.Icon;
        return (
          <Tab.Screen
            key={index}
            name={item.name}
            component={item.component}
            options={{
              tabBarLabel: item.tabBarLabel,
              tabBarIcon: ({color}) => (
                <Icon color={color} width={16} height={18} />
              ),
            }}
          />
        );
      })}
    </Tab.Navigator>
  );
};

export default MyBottomTabs;
