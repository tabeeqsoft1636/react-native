import React from 'react';
import {ButtonWrapper, ButtonText} from './style';

const ImageButton = ({...props}) => (
  <ButtonWrapper {...props}>
    <ButtonText>{props.buttonText}</ButtonText>
  </ButtonWrapper>
);

export default ImageButton;
