import React from 'react';

import {connect} from 'react-redux';

import {Images, Colors} from '../../Theme';
import {ButtonComponent} from '../../Components';
import {
  Wrapper,
  MainContainer,
  Welcomelabel,
  Loginlabel,
  Image,
  WelcomLogo,
  EclipseIconWrapper,
  IconView,
  SkipContainer,
  SkipText,
} from './style';

const WelcomeScreen = props => {
  return (
    <Wrapper>
      <WelcomLogo source={Images.welcomLogo} />
      <MainContainer>
        <IconView>
          <Image source={Images.NurseIcon} />
        </IconView>
      </MainContainer>
      <Welcomelabel>Professionally Trained maids at your service </Welcomelabel>
      <Loginlabel>Easily find cleaners,chat and get service</Loginlabel>

      <EclipseIconWrapper source={Images.EclipseIcon2} />
      <SkipContainer onPress={() => props.navigation.navigate('StartScreen')}>
        <SkipText>Book a Cleaner</SkipText>
      </SkipContainer>
      <ButtonComponent
        buttonText={'Next'}
        onPress={() => props.navigation.navigate('Welcome3')}
        color={Colors.themeColor}
        Image={Images.RightArrow}
      />
    </Wrapper>
  );
};

export default connect()(WelcomeScreen);
