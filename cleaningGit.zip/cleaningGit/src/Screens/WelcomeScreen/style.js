import styled from 'styled-components/native';
import {Colors} from '../../Theme';

export const Wrapper = styled.View`
  background-color: ${Colors.white};
  flex: 1;
  padding-horizontal: 40px;
  padding-vertical: 10px;
  align-items: center;
`;

export const WelcomLogo = styled.Image`
  margin-top: 10%;
  width: 90px;
  height: 80px;
`;

export const MainContainer = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`;

export const IconView = styled.View`
  justify-content: center;
  align-items: center;
  height: 170px;
  width: 170px;
  border-radius: 185px;
  background: #f5f4fa;
`;

export const TextContainer = styled.View`
  align-items: center;
`;

export const Welcomelabel = styled.Text`
  align-self: center;
  font-size: 20px;
  line-height: 28px;
  color: black;
  text-align: center;
  font-style: normal;
  font-weight: 600;
`;

export const Loginlabel = styled.Text`
  align-self: center;
  font-size: 14px;
  color: black;
  line-height: 20px;
  font-weight: 400;
  text-align: center;
  width: 80%;
`;

export const EclipseIconWrapper = styled.Image`
  width: 42px;
  height: 8px;
  margin-top: 10px;
  align-self: center;
`;

export const SkipContainer = styled.TouchableOpacity`
  margin-top: 40px;
  align-items: center;
`;

export const SkipText = styled.Text`
  color: #4f45a8;
  font-weight: bold;
  font-family: Inter;
  font-size: 17px;
  font-weight: bold;
`;

export const Image = styled.Image`
  width: 90px;
  height: 100px;
  align-self: center;
`;
