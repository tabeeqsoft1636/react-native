import React, {useEffect, useState} from 'react';
import {Alert, ScrollView, View} from 'react-native';
import {connect} from 'react-redux';
import {MyHeader} from '../../Screens/_shared';

import {CardField, initStripe} from '@stripe/stripe-react-native';
import {
  BtnText,
  CancelBtnText,
  CancelButton,
  CardInfoWrapper,
  ConfirmButton,
  MainWrapper,
  Wrapper,
} from './style';

import {Constants} from 'theme';

const PaymentScreen = props => {
  const [cardDetails, setCardDetails] = useState();

  useEffect(() => {
    initStripe(Constants.STRIPE_KEY);
  }, []);

  const submit = () => {
    if (cardDetails) {
      props.navigation.navigate('HomeScreen');
    } else {
      Alert.alert('Missing Information!', 'Incomplete card information');
    }
  };
  return (
    <Wrapper>
      <MyHeader
        HeaderText="Payment"
        onPress={() => props.navigation.goBack()}
      />
      <MainWrapper>
        <ScrollView>
          <CardInfoWrapper>
            <CardField
              postalCodeEnabled={false}
              placeholder={{
                number: '4242 4242 4242 4242',
              }}
              cardStyle={{
                backgroundColor: '##EFEFEF',
                textColor: '#686868',
              }}
              style={{
                width: '100%',
                height: 50,
                marginVertical: 30,
              }}
              onCardChange={details => {
                if (details.complete) {
                  setCardDetails(details);
                }
              }}
            />
          </CardInfoWrapper>
        </ScrollView>
      </MainWrapper>
      <View style={{marginBottom: 20, width: '90%'}}>
        <ConfirmButton title="Open" onPress={submit}>
          <BtnText>Confirm</BtnText>
        </ConfirmButton>
        <CancelButton>
          <CancelBtnText>Cancel</CancelBtnText>
        </CancelButton>
      </View>
    </Wrapper>
  );
};

const mapStateToProps = state => {
  return {state};
};

export default connect(mapStateToProps)(PaymentScreen);
