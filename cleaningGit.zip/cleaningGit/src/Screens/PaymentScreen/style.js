import styled from 'styled-components/native';
import {Colors} from '../../Theme';
import {StyleSheet} from 'react-native';

export const Wrapper = styled.View`
  background-color: ${Colors.BACKGROUND};
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const HeaderText = styled.Text`
  font-size: 15px;
  font-weight: 700;
  margin-left: 15px;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 85%;
  background-color: #f0f5ff;
`;
export const CardInfoWrapper = styled.View`
  margin-top: 16px;
`;
export const InputLabel = styled.Text`
  width: 100%;
  margin-top: 10px;
  align-self: center;

  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 40px;
  color: #383838;
`;
export const InputWrapper = styled.View`
  width: 100%;
`;

export const DateLabel = styled.Text`
  width: 50%;
  margin-top: 10px;

  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 40px;
  color: #383838;
  flex-direction: row;
`;
export const DateInput = styled.View`
  width: 49%;
  margin-top: 10px;
  font-family: 'Inter';
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 40px;
  color: #383838;
  flex-direction: row;
`;

export const Seperator = styled.View`
  width: 2%;
  flex-direction: row;
`;
export const DateWrapper = styled.View`
  width: 100%;
  flex-direction: row;
`;

export const TotalView = styled.View`
  margin-top: 16px;
  border-top-width: 0.5px;
  border-bottom-width: 0.5px;
`;

export const TotalText = styled.Text`
  font-size: 18px;
  font-weight: bold;
  color: #4f45a8;
`;

export const RoomLabelText = styled.Text`
  align-self: center;
  font-size: 12px;
  margin-left: 8px;
`;

export const NumberText = styled.Text`
  align-self: center;
  font-size: 14px;
  font-weight: bold;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 20px;
  color: black;
`;

export const Title = styled.Text`
  font-size: 24px;
  margin-top: 15px;
  margin-bottom: 5px;
  color: #4f45a8;
  font-weight: 700;
`;
export const BtnText = styled.Text`
  font-size: 17px;
  color: #fff;
`;
export const CancelBtnText = styled.Text`
  font-size: 17px;
  color: #000;
`;

export const ConfirmButton = styled.TouchableOpacity`
  padding: 15px;
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-self: center;
  align-items: center;
  background-color: #4f45a8;
`;
export const CancelButton = styled.TouchableOpacity`
  padding: 15px;
  width: 100%;
  margin-top: 12px;
  flex-direction: row;
  justify-content: center;
  align-self: center;
  align-items: center;
  border-width: 1px;
`;
export const LabelView = styled.View`
  margin-top: 16px;
  flex-direction: row;
  justify-content: space-between;
`;
export const PriceLabel = styled.Text`
  font-weight: bold;
  font-size: 18px;
`;

export const styles = StyleSheet.create({
  arrow_image: {width: 16, height: 16, top: 2},
});
