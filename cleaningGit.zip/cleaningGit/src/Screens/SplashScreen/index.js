import React from 'react';
import {View, Image} from 'react-native';
import {connect} from 'react-redux';

import {Images} from '../../Theme';
import {api} from '../../Store/apiCalls';
import {AsyncStorage} from '../../Theme/Libraries';
import styles from './style';

const SplashScreen = props => {
  const responseFunction = async resp => {
    if (resp.sucess?.data) {
      const data = resp.sucess.data;
      const {token, user} = data;

      props.dispatch({type: 'USER_DETAIL', data});
      props.dispatch({type: 'TOKEN', data: token});
      await AsyncStorage.setItem('@token', JSON.stringify(token));
      await AsyncStorage.setItem('@userType', JSON.stringify(user?.user_type));

      if (user.user_type === 'cleaner') {
        props.navigation.navigate('CleanerStack');
      } else {
        props.navigation.navigate('HomeScreen');
      }
    } else {
      props.navigation.navigate('LoginScreen');
    }
  };

  React.useEffect(() => {
    const timeout = setTimeout(async () => {
      // AsyncStorage.clear();
      const userDetail = await AsyncStorage.getItem('@credientials');
      if (userDetail) {
        api.apiLoginRequest(JSON.parse(userDetail), responseFunction);
      } else {
        props.navigation.navigate('StartScreen');
      }

      return () => {
        timeout.clear();
      };
    }, 1000);
  });

  return (
    <View style={styles.container}>
      <Image source={Images.SPLASH_LOGO} style={styles.LogoImage} />
    </View>
  );
};

export default connect()(SplashScreen);
