/* eslint-disable no-alert */
import React, {useState} from 'react';
import {
  View,
  PermissionsAndroid,
  Platform,
  ActivityIndicator,
} from 'react-native';
import {
  BtnsWrapper,
  BtnShowMap,
  BtnShowMapText,
  BtnExitMap,
  BtnExitMapText,
  styles,
} from './style';
import MapView from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import MapViewDirections from 'react-native-maps-directions';
import {connect} from 'react-redux';
import {MyHeader} from '_shared';
import {Constants} from 'theme';

const MapScreen = props => {
  const [loading, setLoading] = useState(false);
  const [GOOGLE_API_KEY] = useState(Constants.GOOGLE_PLACES_API_KEY);
  const {latitude, longitude} = props.route.params;
  const [coordinates, setCoordinates] = useState([
    {latitude: parseFloat(latitude), longitude: parseFloat(longitude)},
  ]);

  const getOneTimeLocation = () => {
    Geolocation.getCurrentPosition(
      //Will give you the current location
      position => {
        const long = position.coords.longitude;
        const lat = position.coords.latitude;
        const cords = [
          {latitude: lat, longitude: long},
          {latitude: parseFloat(latitude), longitude: parseFloat(longitude)},
        ];

        setCoordinates(cords);
        if (position.coords) {
          setLoading(false);
        }
      },
      error => {
        alert(error.message);
      },
      {
        enableHighAccuracy: false,
        timeout: 30000,
        maximumAge: 1000,
      },
    );
  };
  const showMap = () => {
    setLoading(true);
    const requestLocationPermission = async () => {
      if (Platform.OS === 'ios') {
        getOneTimeLocation();
      } else {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            {
              title: 'Location Access Required',
              message: 'This App needs to Access your location',
            },
          );
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            getOneTimeLocation();
          } else {
            alert('Permission Denied');
          }
        } catch (err) {
          console.warn(err);
        }
      }
    };
    requestLocationPermission();
  };

  return (
    <View style={styles.container}>
      <MyHeader
        HeaderText="Map View"
        onPress={() => props.navigation.goBack()}
      />
      {loading ? (
        <ActivityIndicator size="large" color={'#4f45a8'} />
      ) : (
        <>
          <MapView
            style={styles.maps}
            initialRegion={{
              latitude: coordinates[0].latitude,
              longitude: coordinates[0].longitude,
              latitudeDelta: 0.3,
              longitudeDelta: 0.3,
            }}>
            <MapViewDirections
              origin={coordinates[0]}
              destination={coordinates[1]}
              apikey={GOOGLE_API_KEY}
              strokeWidth={4}
              strokeColor="#111111"
            />
            <MapView.Marker coordinate={coordinates[0]} />
            {coordinates[1] && <MapView.Marker coordinate={coordinates[1]} />}
          </MapView>

          <BtnsWrapper>
            <BtnShowMap onPress={() => showMap()}>
              <BtnShowMapText>Show Direction</BtnShowMapText>
            </BtnShowMap>

            <BtnExitMap onPress={() => props.navigation.goBack()}>
              <BtnExitMapText>Exit Map</BtnExitMapText>
            </BtnExitMap>
          </BtnsWrapper>
        </>
      )}
    </View>
  );
};

export default connect()(MapScreen);
