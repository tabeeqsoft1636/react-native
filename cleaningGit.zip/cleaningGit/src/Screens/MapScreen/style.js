import styled from 'styled-components/native';
import {StyleSheet, Dimensions} from 'react-native';
export const BtnsWrapper = styled.View`
  flex-direction: row;
  margin-bottom: 100px;
  z-index: 2;
  position: absolute;
  top: 80%;
  padding: 10px;
`;
export const BtnShowMap = styled.TouchableOpacity`
  height: 56px;
  width: 48%;
  background: #ffffff;
  border: 1px solid #c9ced1;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
  margin-right: 4%;
`;
export const BtnShowMapText = styled.Text`
  font-size: 15px;
  color: #383838;
`;

export const BtnExitMap = styled.TouchableOpacity`
  height: 56px;
  width: 48%;
  background: #ffffff;
  border: 1px solid #df2d21;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
`;
export const BtnExitMapText = styled.Text`
  font-size: 15px;
  color: #df2d21;
`;

export const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  maps: {
    width: Dimensions.get('screen').width,
    height: Dimensions.get('screen').height,
  },
});
