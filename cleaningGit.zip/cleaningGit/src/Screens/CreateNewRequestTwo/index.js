import React, {useState, useEffect, useCallback} from 'react';
import {View, Text, TouchableOpacity, ScrollView} from 'react-native';
import {useDispatch, useSelector, connect} from 'react-redux';

import useRequests from 'store/request';
import {Dropdown, MyHeader, MyHeaderBalance} from '_shared';
import {api} from '../../Store/apiCalls';
import {Wrapper, MainWrapper, Title} from './style';
import styles from './style';

const CreateNewRequestTwo = props => {
  const dispatch = useDispatch();
  const reduxData = useSelector(state => state);
  const {selectionUpdate} = useRequests();

  const [bedRoomListOpen, setBedRoomListOpen] = useState(false);
  const [bathRoomListOpen, setBathRoomListOpen] = useState(false);
  const [bathRoomList, setBathRoomList] = useState([]);
  const [bedRoomList, setBedRoomList] = useState([]);
  const [extrasList, setExtrasList] = useState([]);
  const [data, setData] = useState({});

  useEffect(() => {
    api.apiExtrasList(ExtraListResponse);

    if (reduxData?.rooms) {
      setBedRoomList(reduxData.rooms);
    }
    if (reduxData?.bathrooms) {
      setBathRoomList(reduxData.bathrooms);
    }
  }, [reduxData?.bathrooms, reduxData?.rooms]);

  useEffect(() => {
    const bedromItem = reduxData?.rooms.find(
      e => e.id === reduxData?.selectedBedroom,
    );
    const bathroomItem = reduxData?.bathrooms?.find(
      e => e.id === reduxData?.selectedBathroom,
    );

    let priceSum = 0.0;
    if (bedromItem) {
      priceSum += parseFloat(bedromItem.price);
    }
    if (bathroomItem) {
      priceSum += parseFloat(bathroomItem.price);
    }
    extrasList.forEach(element => {
      if (element.selected) {
        priceSum += parseFloat(element.price);
      }
    });

    dispatch({type: 'PRICE_UPDATE', data: priceSum});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduxData?.selectedBathroom, reduxData?.selectedBedroom, extrasList]);

  const ExtraListResponse = resp => {
    const res = resp.sucess?.results;
    setData(prev => ({...prev, extras: res}));
    setExtrasList(res);
  };

  const next = () => {
    selectionUpdate('extras', extrasList);
    props.navigation.navigate('CreateNewRequestThree');
  };

  const extrasSelectFunc = index => {
    let obj = extrasList;
    obj[index].selected = obj[index].selected ? !obj[index].selected : true;
    setExtrasList([...obj]);
  };

  const setSelection = useCallback(
    (e, name) => {
      if (name) {
        dispatch({type: name, data: e});
      }
    },
    [dispatch],
  );

  return (
    <Wrapper>
      <MyHeader
        HeaderText="Create A New Request"
        onPress={() => props.navigation.goBack()}
        RightComponent={() => <MyHeaderBalance />}
      />

      <MainWrapper>
        <ScrollView>
          <Title>{'Number of Rooms'}</Title>
          <Dropdown
            open={bedRoomListOpen}
            setOpen={setBedRoomListOpen}
            value={reduxData?.selectedBedroom}
            setValue={e => setSelection(e(), 'UPDATE_ROOM_SELECTION')}
            items={bedRoomList}
            setItems={setBedRoomList}
            placeholder="Select Room..."
            zIndex={2}
          />

          <Title>{'Number of Bathrooms'}</Title>
          <Dropdown
            open={bathRoomListOpen}
            setOpen={setBathRoomListOpen}
            value={reduxData?.selectedBathroom}
            setValue={e => setSelection(e(), 'UPDATE_BATHROOM_SELECTION')}
            items={bathRoomList}
            setItems={setBathRoomList}
            placeholder="Select Bathroom..."
            zIndex={1}
          />

          <Title>{'Extras'}</Title>

          {extrasList?.map((item, index) => {
            return (
              <TouchableOpacity
                style={[
                  styles.box,
                  {backgroundColor: item.selected ? '#4F45A8' : '#fff'},
                ]}
                onPress={() => extrasSelectFunc(index)}
                key={index}>
                <Text style={{color: item.selected ? '#fff' : '#000'}}>
                  {item.service_name}
                </Text>
              </TouchableOpacity>
            );
          })}

          <View
            style={{
              marginTop: 20,
              backgroundColor: '#efefef',
            }}>
            <View style={{padding: 20}}>
              <Text style={{}}>
                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean
                commodo ligula eget dolor. Aenean massa. Cum sociis natoque
                penatibus et magnis dis parturient montes, nascetur ridiculus
                mus. Donec qu
              </Text>
            </View>
          </View>
        </ScrollView>
      </MainWrapper>
      <TouchableOpacity style={styles.ButtonWrapper} onPress={next}>
        <Text style={{fontSize: 17, color: 'white'}}>Next</Text>
      </TouchableOpacity>
    </Wrapper>
  );
};

export default connect()(CreateNewRequestTwo);
