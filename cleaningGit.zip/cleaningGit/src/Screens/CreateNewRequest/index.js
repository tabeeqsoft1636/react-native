import React, {useEffect, useState, useCallback} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import {api} from 'store/apiCalls';
import useRequests from 'store/request';

import {styles, Wrapper, MainWrapper, Title, BulletPoint} from './style';
import {Dropdown, MyHeader, MyHeaderBalance} from '_shared';
const NewRequest = props => {
  const {userSelections, selectionUpdate, apiResponse} = useRequests();
  const [cleaningType, setCleaningType] = useState([]);

  // for dropdown
  const [cleaningOpen, setCleaningOpen] = useState(false);
  const [selected, setSelected] = useState(userSelections?.cleaningType?.id);

  useEffect(() => {
    api.apiServiceRequest(resp => {
      const data = resp.sucess.results;
      let drop = [];
      data.forEach(element => {
        drop.push({
          label: element.cleaning_type_name,
          value: element.id,
          ...element,
        });
      });
      apiResponse('cleaningType', drop);
      setCleaningType(drop);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setSelection = useCallback(
    (e, name) => {
      setSelected(e);
      const selection = cleaningType.find(res => res.id === e);
      selectionUpdate(name, selection);
    },
    [cleaningType, selectionUpdate],
  );

  const next = () => {
    props.navigation.navigate('CreateNewRequestTwo');
  };

  return (
    <Wrapper>
      <MyHeader
        HeaderText="Create A New Request"
        onPress={() => props.navigation.goBack()}
        RightComponent={() => <MyHeaderBalance />}
      />
      <MainWrapper>
        <Title>{'Select Cleaning Type'}</Title>
        <Dropdown
          open={cleaningOpen}
          setOpen={setCleaningOpen}
          value={selected}
          setValue={e => setSelection(e(), 'cleaningType')}
          items={cleaningType}
          setItems={setCleaningType}
          placeholder="Select Cleaning Type..."
        />
        <Title>{'Service Type'}</Title>
        <View style={styles.services}>
          {userSelections?.cleaningType?.service_types?.map(
            (element, index) => {
              return (
                <View style={styles.box} key={index}>
                  <BulletPoint />
                  <Text>{element}</Text>
                </View>
              );
            },
          )}
        </View>
      </MainWrapper>
      <TouchableOpacity style={styles.buttonWrapper} onPress={next}>
        <Text style={{fontSize: 17, color: 'white'}}>Next</Text>
      </TouchableOpacity>
    </Wrapper>
  );
};

export default connect()(NewRequest);
