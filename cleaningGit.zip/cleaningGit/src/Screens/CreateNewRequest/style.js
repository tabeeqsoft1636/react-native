import styled from 'styled-components/native';
import {Colors} from '../../Theme';
import {StyleSheet} from 'react-native';
export const Wrapper = styled.View`
  background-color: ${Colors.BACKGROUND};
  flex: 1;
  align-items: center;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 90%;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 20px;
  color: black;
`;

export const Title = styled.Text`
  font-size: 15px;
  margin-top: 15px;
  margin-bottom: 5px;
  color: #383838;
  font-weight: 400;
`;

export const BulletPoint = styled.View`
  width: 5px;
  height: 5px;
  background-color: ${Colors.themeGrey};
  border-radius: 5px;
  margin-right: 5px;
`;

export const styles = StyleSheet.create({
  box: {
    height: 56,
    margin: 10,
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: 17,
    flexDirection: 'row',
  },
  services: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  floorView: {
    marginTop: 20,
    padding: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  buttonWrapper: {
    padding: 15,
    width: '50%',
    marginBottom: 20,
    flexDirection: 'row',
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    // borderWidth: 1,
    backgroundColor: '#4F45A8',
  },
});
