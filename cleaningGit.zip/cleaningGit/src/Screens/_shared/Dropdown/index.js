import React from 'react';

import DropDownPicker from 'react-native-dropdown-picker';

const Dropdown = ({placeholder = 'Select... ', ...props}) => (
  <DropDownPicker
    placeholder={placeholder}
    placeholderStyle={{
      color: '#00000050',
      width: '100%',
    }}
    dropDownContainerStyle={{
      borderWidth: 0,
      borderColor: '#C9CED1',
      width: '100%',
      backgroundColor: '#fff',
      color: '#fff',
      borderRadius: 5,
    }}
    // textStyle={styles.HeadingText}
    style={{
      backgroundColor: '#fff',
      borderWidth: 1,
      borderColor: '#C9CED1',
      borderRadius: 2,
      width: '100%',
    }}
    listItemContainerStyle={{
      backgroundColor: '#C9CED1',
      borderColor: '#fff',
      borderWidth: 1,
      borderTopWidth: 0,
    }}
    {...props}
  />
);

export default Dropdown;
