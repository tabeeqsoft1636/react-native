import styled from 'styled-components/native';

export const Wrapper = styled.View`
  flex: 1;
`;

export const HeaderText = styled.Text`
  text-align: right;
  margin-right: 20px;
  font-weight: bold;
  font-size: 17px;
  color: #4f45a8;
`;

export const SubTotal = styled.Text`
  text-align: right;
  margin-right: 20px;
  font-weight: 500;
  font-size: 10px;
  color: #c9ced1;
`;
