import React from 'react';
import {useSelector} from 'react-redux';

import {Wrapper, HeaderText, SubTotal} from './styles';

const HeaderRightComponent = () => {
  const data = useSelector(state => state);

  return (
    <Wrapper>
      <HeaderText>${data.price}</HeaderText>
      <SubTotal>Sub Total</SubTotal>
    </Wrapper>
  );
};

export default HeaderRightComponent;
