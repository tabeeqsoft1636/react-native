import styled from 'styled-components/native';
import {StyleSheet} from 'react-native';

export const Wrapper = styled.View`
  width: 100%;
  height: 40px;
  background-color: #fff;
  flex-direction: row;
  align-items: center;
`;

export const HeaderText = styled.Text`
  font-weight: bold;
  font-size: 16px;
`;

export const BackWrapper = styled.TouchableOpacity`
  padding: 20px;
`;

export const BackArrow = styled.Image`
  width: 16px;
  height: 16px;
`;

export const styles = StyleSheet.create({
  arrow_image: {width: 16, height: 16, top: 2},
});
