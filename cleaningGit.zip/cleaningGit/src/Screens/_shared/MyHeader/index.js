import React from 'react';

import {Images} from '../../../Theme';
import {MainHeader} from 'components';
import {Wrapper, HeaderText, BackWrapper, BackArrow} from './styles';

const MyHeader = ({RightComponent, ...props}) => (
  <MainHeader>
    <Wrapper>
      <BackWrapper {...props}>
        <BackArrow source={Images.LefttArrow} />
      </BackWrapper>
      <HeaderText>{props.HeaderText}</HeaderText>
      {RightComponent && <RightComponent />}
    </Wrapper>
  </MainHeader>
);

export default MyHeader;
