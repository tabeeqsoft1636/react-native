import React from 'react';

import {Images} from '../../../Theme';
import {MainHeader} from 'components';
import {DrawerActions, useNavigation} from '@react-navigation/native';
import {
  Wrapper,
  HeaderText,
  DrawerWrapper,
  DrawerIcon,
  ProfileImage,
} from './styles';

const ProfileHeader = ({theme = 'light', ...props}) => {
  const navigation = useNavigation();

  const isLight = theme === 'light';

  return (
    <MainHeader isLight={isLight}>
      <Wrapper isLight={isLight}>
        <DrawerWrapper
          onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())}
          {...props.drawerProps}>
          <DrawerIcon source={Images.DrawerIcon} />
        </DrawerWrapper>
        <HeaderText isLight={isLight}>Lauras</HeaderText>
        <DrawerWrapper {...props.imageProps}>
          <ProfileImage source={Images.ProfileImage} />
        </DrawerWrapper>
      </Wrapper>
    </MainHeader>
  );
};

export default ProfileHeader;
