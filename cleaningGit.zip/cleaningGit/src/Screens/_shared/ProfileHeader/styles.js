import styled from 'styled-components/native';
import {StyleSheet} from 'react-native';

export const Wrapper = styled.View`
  width: 100%;
  height: 40px;
  background-color: ${props => (props.isLight ? '#fff' : '#4f45a8')};
  flex-direction: row;
  align-items: center;
  padding: 0 15px;
  justify-content: space-between;
`;

export const HeaderText = styled.Text`
  font-weight: bold;
  font-size: 23px;
  color: ${props => (props.isLight ? '#4f45a8' : '#fff')};
`;

export const DrawerWrapper = styled.TouchableOpacity``;

export const DrawerIcon = styled.Image`
  width: 24px;
  height: 24px;
`;

export const ProfileImage = styled.Image`
  width: 24px;
  height: 24px;
  align-self: center;
`;

export const styles = StyleSheet.create({
  arrow_image: {width: 16, height: 16, top: 2},
});
