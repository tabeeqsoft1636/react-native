import React, {useEffect, useState} from 'react';
import {Text, TouchableOpacity, FlatList} from 'react-native';
import {connect} from 'react-redux';
import moment from 'moment';

import {api} from 'store/apiCalls';
import {ProfileHeader} from '_shared';

import {
  Wrapper,
  NameLabelView,
  NameLabel,
  ThreeDottsImage,
  TimeLabel,
  TextLabel,
  StatusLabel,
  LocationLabel,
  PinLocationIcon,
  StatusLabelView,
  StatusWrapper,
  LocationView,
  Card,
} from './style';
const History = props => {
  const [historyList, setHistoryList] = useState([]);
  useEffect(() => {
    api.apiHistoryDetailsRequest(resFunc);
  }, []);

  const resFunc = res => {
    // console.log('My Result', res.sucess.results);
    if (res?.sucess) {
      setHistoryList(res?.sucess?.results);
    } else {
      alert(JSON.stringify(res));
    }
  };

  const CardRendrer = ({item, index}) => {
    return (
      <Card key={index}>
        <NameLabelView>
          <NameLabel>{item.user}</NameLabel>
          <TouchableOpacity>
            <ThreeDottsImage
              source={require('../../Theme/Images/threedotts.png')}
            />
          </TouchableOpacity>
        </NameLabelView>
        <TimeLabel>{moment(item.created_at).format('MM/YY HH:MM')}</TimeLabel>
        <StatusWrapper>
          <StatusLabelView>
            <TextLabel>{item.total_price}</TextLabel>
            <TextLabel>{item.cleaning_type}</TextLabel>
            <StatusLabel>Pending</StatusLabel>
          </StatusLabelView>
          <StatusLabelView>
            <Text>Price</Text>
            <Text>Type</Text>
            <Text>Status</Text>
          </StatusLabelView>
        </StatusWrapper>
        {/* <StatusWrapper>
          <StatusLabelView>
            <TextLabel>{item.bed_room}</TextLabel>
            <TextLabel>{item.bath_room}</TextLabel>
            <TextLabel>{item.others_note}</TextLabel>
          </StatusLabelView>
          <StatusLabelView>
            <Text>Bedroom</Text>
            <Text>Bathroom</Text>
            <Text>Note</Text>
          </StatusLabelView>
        </StatusWrapper> */}
        <LocationView>
          <PinLocationIcon source={require('../../Theme/Images/Pin.png')} />
          <LocationLabel>{item.address}</LocationLabel>
        </LocationView>
      </Card>
    );
  };

  return (
    <>
      <ProfileHeader />
      <Wrapper>
        <FlatList
          data={historyList}
          keyExtractor={item => item.id}
          renderItem={CardRendrer}
        />
      </Wrapper>
    </>
  );
};

export default connect()(History);
