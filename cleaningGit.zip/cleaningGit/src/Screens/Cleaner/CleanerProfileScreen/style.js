import styled from 'styled-components/native';

import {Colors} from 'theme';

export const Wrapper = styled.View`
  background-color: ${Colors.white};
  flex: 1;
  width: 100%;
  padding: 5%;
`;
export const ProfileButton = styled.TouchableOpacity`
  justify-content: center;
  align-self: center;
  align-items: center;
  display: flex;
  margin-top: 50px;
  width: 80px;
  height: 80px;
  border-radius: 40px;
  background: #e9e7ff;
`;
export const TextInputWrapper = styled.View``;
export const LabelText = styled.Text`
  margin-top: 16px;
`;
export const TextInputView = styled.View`
  height: 48px;
  background: red;
  border-color: #4f45a8;
  background-color: #efefef;
`;
export const ButtonWrapper = styled.View`
  width: 100%;
`;
export const InputText = styled.TextInput`
  padding-horizontal: 20px;
`;
export const EditButtonView = styled.View`
  width: 100%;
  margin-top: 26px;
`;

export const StyledText = styled.Text`
  color: palevioletred;
`;
