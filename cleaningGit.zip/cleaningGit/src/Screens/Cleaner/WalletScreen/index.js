import React from 'react';
import {connect} from 'react-redux';
import LinearGradient from 'react-native-linear-gradient';

import {api} from 'store/apiCalls';

import {ProfileHeader} from '_shared';

import {
  Wrapper,
  CardWrapper,
  PriceWrapper,
  PriceLabel,
  TotalPriceLabel,
  CurrencyLabel,
  BottomWrapper,
  BtnWithdraw,
  BtnText,
  BtnsWrapper,
  BtnAddCard,
  BtnAddCardText,
  BtnRemove,
  BtnRemoveText,
  styles,
} from './style';
const WalletScreen = () => {
  const [welletAmount, setWalletAmount] = React.useState(0);

  React.useEffect(() => {
    api.apiCleanerTotalEarning(responseFunction);
  }, []);

  const responseFunction = res => {
    if (res.sucess) {
      const data = res.sucess;
      setWalletAmount(data.total_amount);
    }
  };

  return (
    <>
      <ProfileHeader theme="dark" />
      <Wrapper>
        <CardWrapper>
          <PriceWrapper>
            <CurrencyLabel>$</CurrencyLabel>
            <PriceLabel>{welletAmount}</PriceLabel>
          </PriceWrapper>
          <TotalPriceLabel>Total Earning</TotalPriceLabel>
          <LinearGradient
            style={styles.CreditCard}
            colors={['#614ad3', '#e42c64']}
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
          />
        </CardWrapper>

        <BottomWrapper>
          <BtnsWrapper>
            <BtnAddCard>
              <BtnAddCardText>Add Card</BtnAddCardText>
            </BtnAddCard>

            <BtnRemove>
              <BtnRemoveText>Remove Card</BtnRemoveText>
            </BtnRemove>
          </BtnsWrapper>
          <BtnWithdraw>
            <BtnText>Withdraw</BtnText>
          </BtnWithdraw>
        </BottomWrapper>
      </Wrapper>
    </>
  );
};

export default connect()(WalletScreen);
