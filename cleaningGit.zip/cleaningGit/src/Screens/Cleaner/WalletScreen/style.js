import styled from 'styled-components/native';
import {StyleSheet} from 'react-native';
export const Wrapper = styled.View`
  background-color: #ffffff;
  flex: 1;
  width: 100%;
`;

export const CardWrapper = styled.View`
  display: flex;
  height: 312px;
  background: #4f45a8;
  justify-content: center;
  align-items: center;
`;

export const PriceWrapper = styled.View`
  flex-direction: row;
`;
export const CurrencyLabel = styled.Text`
  font-weight: bold;
  font-size: 23px;
  color: #ffffff;
`;
export const PriceLabel = styled.Text`
  font-weight: bold;
  font-size: 40px;
  color: #ffffff;
`;

export const TotalPriceLabel = styled.Text`
  font-size: 16px;
  text-align: center;
  color: #bbb4ff;
`;

export const BottomWrapper = styled.View`
  flex: 1;
  width: 100%;
  padding: 10px;
  margin-top: 20%;
`;

export const BtnWithdraw = styled.TouchableOpacity`
  height: 56px;
  background: #4f45a8;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
`;
export const BtnText = styled.Text`
  font-size: 15px;
  color: #ffffff;
`;

export const BtnsWrapper = styled.View`
  flex-direction: row;
`;
export const BtnAddCard = styled.TouchableOpacity`
  height: 56px;
  width: 48%;
  background: #ffffff;
  border: 1px solid #c9ced1;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
  margin-right: 4%;
`;
export const BtnAddCardText = styled.Text`
  font-size: 15px;
  color: #383838;
`;

export const BtnRemove = styled.TouchableOpacity`
  height: 56px;
  width: 48%;
  background: #ffffff;
  border: 1px solid #df2d21;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
`;
export const BtnRemoveText = styled.Text`
  font-size: 15px;
  color: #df2d21;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 100%;
  padding: 10px;
`;

export const styles = StyleSheet.create({
  CreditCard: {
    width: '75%',
    height: 170,
    borderRadius: 10,
    position: 'absolute',
    bottom: -85,
  },
});
