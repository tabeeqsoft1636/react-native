import styled from 'styled-components/native';
import {Colors} from 'theme';
import {StyleSheet} from 'react-native';
export const Wrapper = styled.View`
  background-color: ${Colors.BACKGROUND};
  flex: 1;
  width: 100%;
  padding: 10px;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 100%;
  padding: 10px;
`;

export const Card = styled.View`
  background-color: #fff;
  padding: 10px;
  margin: 10px;
  shadow-color: #000;
  shadow-opacity: 0.1;
  shadow-radius: 8px;
  elevation: 2;
`;

export const NameLabelView = styled.View`
  padding: 10px;
  flex-direction: row;
  justify-content: space-between;
`;

export const NameLabel = styled.Text`
  color: #4f45a8;
  font-size: 16px;
`;

export const ThreeDottsImage = styled.Image`
  width: 5px;
  height: 20px;
`;
export const TimeLabel = styled.Text`
  font-size: 12px;
  border-bottom-color: #e6e6e6;
  border-bottom-width: 0.2px;
  padding-bottom: 10px;
  margin-left: 10px;
`;
export const TextLabel = styled.Text`
  font-weight: bold;
`;
export const StatusLabel = styled.Text`
  font-weight: bold;
  color: #df9f21;
`;
export const LocationLabel = styled.Text`
  color: #545454;
  margin-left: 15px;
  font-size: 12px;
`;
export const PinLocationIcon = styled.Image`
  width: 13.5px;
  height: 20px;
`;
export const StatusLabelView = styled.View`
  padding: 5px;
  flex-direction: row;
  justify-content: space-between;
`;
export const StatusWrapper = styled.View`
  padding: 5px;
  width: 80%;
`;
export const LocationView = styled.View`
  padding: 15px;
  width: 90%;
  flex-direction: row;
`;
const styles = StyleSheet.create({
  box: {
    padding: 15,
    width: '100%',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#C9CED1',
    backgroundColor: 'white',
  },
  services: {
    flexDirection: 'row',
    marginTop: 8,
    justifyContent: 'space-between',
  },
  floorView: {
    marginTop: 20,
    padding: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});

export default styles;
