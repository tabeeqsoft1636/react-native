import React, {useEffect, useState} from 'react';
import {
  Text,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import {connect} from 'react-redux';
import moment from 'moment';

import {api} from 'store/apiCalls';
import {ProfileHeader} from '_shared';

import {
  Wrapper,
  NameLabelView,
  NameLabel,
  ThreeDottsImage,
  TimeLabel,
  TextLabel,
  StatusLabel,
  LocationLabel,
  PinLocationIcon,
  StatusLabelView,
  StatusWrapper,
  LocationView,
  Card,
} from './style';
const CleanerAllHistory = props => {
  const [historyList, setHistoryList] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const unsubscribe = props.navigation.addListener('focus', () => {
      setLoading(true);
      api.apiCleanerAllHistoryRequest(resFunc);
    });

    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resFunc = res => {
    setLoading(false);
    if (res?.sucess) {
      setHistoryList(res?.sucess.results);
    } else {
      alert(JSON.stringify(res));
      console.log(res);
    }
  };

  const getDetails = cleanerId => {
    props.navigation.navigate('HistoryDetails', {
      cleanerId: cleanerId,
    });
  };

  const CardRendrer = ({item, index}) => {
    return (
      <TouchableOpacity onPress={() => getDetails(item.id)}>
        <Card key={index}>
          <NameLabelView>
            <NameLabel>{item.user}</NameLabel>
            <TouchableOpacity>
              <ThreeDottsImage
                source={require('theme/Images/threedotts.png')}
              />
            </TouchableOpacity>
          </NameLabelView>
          <TimeLabel>{moment(item.created_at).format('MM/YY HH:MM')}</TimeLabel>
          <StatusWrapper>
            <StatusLabelView>
              <TextLabel>{item.total_price}</TextLabel>
              <TextLabel>{item.cleaning_type}</TextLabel>
              <StatusLabel>
                {item.status === 'Accepted' ? (
                  <Text style={{color: '#00A510'}}>Accepted</Text>
                ) : (
                  <Text style={{color: '##DF9F21'}}>Pending</Text>
                )}
              </StatusLabel>
            </StatusLabelView>
            <StatusLabelView>
              <Text>Price</Text>
              <Text>Type</Text>
              <Text>Status</Text>
            </StatusLabelView>
          </StatusWrapper>
          <LocationView>
            <PinLocationIcon source={require('theme/Images/Pin.png')} />
            <LocationLabel>{item.address}</LocationLabel>
          </LocationView>
        </Card>
      </TouchableOpacity>
    );
  };

  return (
    <>
      <ProfileHeader />
      <Wrapper>
        {loading ? (
          <ActivityIndicator size="large" color={'#4f45a8'} />
        ) : (
          <FlatList
            data={historyList}
            keyExtractor={item => item.id}
            renderItem={CardRendrer}
          />
        )}
      </Wrapper>
    </>
  );
};

export default connect()(CleanerAllHistory);
