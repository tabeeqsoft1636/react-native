import styled from 'styled-components/native';
import {Colors} from '../../Theme';
import {StyleSheet} from 'react-native';
export const Wrapper = styled.View`
  background-color: ${Colors.BACKGROUND};
  flex: 1;
  width: 100%;
  padding: 10px;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 100%;
  padding: 10px;
`;
export const Card = styled.View`
  background-color: #fff;
  padding: 10px;
  margin: 10px;
  shadow-color: #000;
  shadow-opacity: 0.1;
  shadow-radius: 8px;
  elevation: 2;
`;
export const NameLabelView = styled.View`
  padding: 10px;
  flex-direction: row;
  justify-content: space-between;
`;
export const NameLabel = styled.Text`
  color: #4f45a8;
  font-size: 16px;
  font-weight: bold;
`;

export const ThreeDottsImage = styled.Image`
  width: 5px;
  height: 20px;
`;
export const TimeLabel = styled.Text`
  font-size: 12px;
  border-bottom-color: #e6e6e6;
  border-bottom-width: 0.2px;
  padding-bottom: 10px;
  margin-left: 10px;
`;
export const TextLabel = styled.Text`
  font-weight: bold;
`;
export const StatusLabel = styled.Text`
  font-weight: bold;
  color: #df9f21;
`;
export const LocationLabel = styled.Text`
  color: #545454;
  margin-left: 15px;
  font-size: 12px;
`;
export const PinLocationIcon = styled.Image`
  width: 13.5px;
  height: 20px;
`;
export const StatusLabelView = styled.View`
  padding: 5px;
  flex-direction: row;
  justify-content: space-between;
`;
export const StatusWrapper = styled.View`
  padding: 5px;
  width: 80%;
`;
export const LocationView = styled.View`
  padding: 15px;
  width: 90%;
  flex-direction: row;
`;

export const ServicesWrapper = styled.View`
  margin-top: 16px;
`;
export const BedroomView = styled.View`
  flex-direction: row;
`;
export const ViewLabel = styled.View`
  flex-direction: row;
  margin-top: 10px;
  flex-wrap: wrap;
`;
export const TotalView = styled.View`
  margin-top: 16px;
  border-top-width: 0.5px;
  border-bottom-width: 0.5px;
`;

export const ExtraText = styled.Text`
  align-self: center;
  font-size: 14px;
  font-weight: 700;
`;
export const TotalText = styled.Text`
  font-size: 18px;
  font-weight: bold;
  color: #4f45a8;
`;

export const RoomLabelText = styled.Text`
  align-self: center;
  font-size: 12px;
  margin-left: 8px;
`;

export const NumberText = styled.Text`
  align-self: center;
  font-size: 14px;
  font-weight: bold;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 20px;
  color: black;
`;

export const LabelView = styled.View`
  margin-top: 16px;
  flex-direction: row;
  justify-content: space-between;
`;
export const PriceLabel = styled.Text`
  font-weight: bold;
  font-size: 18px;
`;
export const SeparatorView = styled.View`
  margin-top: 16px;
  border-bottom-width: 0.5px;
`;

export const ServiceView = styled.View`
  flex-direction: row;
  padding-bottom: 10px;
`;
export const ServiceText = styled.Text`
  color: #4f45a8;
  font-weight: 700;
  font-size: 24px;
`;

export const BottomWrapper = styled.View`
  flex: 1;
  width: 100%;
  padding: 10px;
`;
export const NoteView = styled.View`
  height: 144px;
  background: #ffffff;
`;

export const NoteText = styled.Text`
  font-size: 15px;
  color: #686868;
  padding: 20px;
`;

export const BtnAccept = styled.View`
  height: 56px;
  background: #4f45a8;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
`;
export const BtnText = styled.Text`
  font-size: 15px;
  color: #ffffff;
`;

export const BtnsWrapper = styled.View`
  flex-direction: row;
`;
export const BtnCall = styled.TouchableOpacity`
  height: 56px;
  width: 48%;
  background: #ffffff;
  border: 1px solid #c9ced1;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
  margin-right: 4%;
`;
export const BtnCallText = styled.Text`
  font-size: 15px;
  color: #383838;
`;

export const BtnMsg = styled.TouchableOpacity`
  height: 56px;
  width: 48%;
  background: #ffffff;
  border: 1px solid #c9ced1;
  align-items: center;
  justify-content: center;
  margin-top: 20px;
`;
export const BtnMsgText = styled.Text`
  font-size: 15px;
  color: #383838;
`;

const styles = StyleSheet.create({
  box: {
    padding: 15,
    width: '100%',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#C9CED1',
    backgroundColor: 'white',
  },
  services: {
    flexDirection: 'row',
    marginTop: 8,
    justifyContent: 'space-between',
  },
  floorView: {
    marginTop: 20,
    padding: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});

export default styles;
