/* eslint-disable no-alert */
import React, {useEffect, useState} from 'react';
import {
  Text,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Linking,
} from 'react-native';
import {connect} from 'react-redux';
import moment from 'moment';
import {useNavigation} from '@react-navigation/native';
import {api} from 'store/apiCalls';
import {MyHeader} from '_shared';

import {
  Wrapper,
  NameLabelView,
  NameLabel,
  TimeLabel,
  TextLabel,
  StatusLabel,
  LocationLabel,
  PinLocationIcon,
  StatusLabelView,
  StatusWrapper,
  LocationView,
  Card,
  ServicesWrapper,
  BedroomView,
  ViewLabel,
  NumberText,
  RoomLabelText,
  TotalView,
  TotalText,
  ExtraText,
  LabelView,
  PriceLabel,
  SeparatorView,
  ServiceView,
  ServiceText,
  BottomWrapper,
  NoteView,
  NoteText,
  BtnAccept,
  BtnText,
  BtnsWrapper,
  BtnCall,
  BtnCallText,
  BtnMsg,
  BtnMsgText,
} from './style';
import {View} from 'react-native-ui-lib';
const HistoryDetails = props => {
  const navigation = useNavigation();
  const {cleanerId} = props.route.params;
  const [historyDetail, setHistoryDetail] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.apiCleanerHistoryDeatilsRequest(resDetailsFunc, cleanerId);
  }, [cleanerId]);

  const resDetailsFunc = res => {
    setLoading(false);
    if (res?.sucess) {
      setHistoryDetail([res?.sucess]);
    } else {
      alert(JSON.stringify(res));
    }
  };

  const AcceptRequest = reqId => {
    setLoading(true);
    api.apiAcceptRequest({id: reqId, status: 1}, resAcceptFunc);
  };

  const ViewMap = item => {
    navigation.navigate('MapScreen', {
      latitude: item.left_coordinate,
      longitude: item.right_coordinate,
    });
  };

  const resAcceptFunc = res => {
    setLoading(false);
    if (res?.sucess) {
      navigation.navigate('CleanerHome');
    } else {
      alert(JSON.stringify(res));
    }
  };

  const CardRendrer = ({item, index}) => {
    return (
      <View>
        <Card key={index}>
          <SeparatorView>
            <NameLabelView>
              <NameLabel>{item.user}</NameLabel>
            </NameLabelView>
            <TimeLabel>
              {moment(item.created_at).format('MM/YY HH:MM')}
            </TimeLabel>
          </SeparatorView>
          <StatusWrapper>
            <StatusLabelView>
              <TextLabel>{item.total_price}</TextLabel>
              <TextLabel>{item.cleaning_type}</TextLabel>
              <StatusLabel>
                {item.status === 'Pending' ? (
                  <Text style={{color: '#DF9F21'}}>Pending</Text>
                ) : (
                  <Text style={{color: '#00A510'}}>Accepted</Text>
                )}
              </StatusLabel>
            </StatusLabelView>
            <StatusLabelView>
              <Text>Price</Text>
              <Text>Type</Text>
              <Text>Status</Text>
            </StatusLabelView>
          </StatusWrapper>
          <SeparatorView>
            <LocationView>
              <PinLocationIcon source={require('theme/Images/Pin.png')} />
              <LocationLabel>{item.address}</LocationLabel>
            </LocationView>
          </SeparatorView>
          <ServicesWrapper>
            <ServiceView>
              <ServiceText>{item.cleaning_type}</ServiceText>
            </ServiceView>
            <BedroomView style={{flexDirection: 'row'}}>
              <NumberText>{item.bed_room}</NumberText>
            </BedroomView>
            <ViewLabel style={{flexDirection: 'row', marginTop: 8}}>
              <NumberText>{item.bath_room}</NumberText>
            </ViewLabel>
            <ViewLabel>
              <ExtraText>Extra</ExtraText>
              {item.extra?.map((extItem, i) => (
                <RoomLabelText key={i}>{extItem}</RoomLabelText>
              ))}
            </ViewLabel>
            <ViewLabel>
              <ExtraText>How to get in</ExtraText>
              <RoomLabelText>{item.how_to_get_in}</RoomLabelText>
            </ViewLabel>
            <TotalView>
              <LabelView>
                <Text>Price for the service</Text>
                <PriceLabel>${item?.service_price}</PriceLabel>
              </LabelView>
              <LabelView>
                <Text>App Fee</Text>
                <PriceLabel>${item?.app_fee}</PriceLabel>
              </LabelView>
            </TotalView>
            <LabelView>
              <Text>Total</Text>
              <TotalText>${item?.total_price}</TotalText>
            </LabelView>
          </ServicesWrapper>
        </Card>
        <BottomWrapper>
          {item?.others_note !== '' && (
            <NoteView>
              <NoteText>{item?.others_note}</NoteText>
            </NoteView>
          )}
          {item.status !== 'Accepted' && (
            <TouchableOpacity onPress={() => AcceptRequest(item.id)}>
              <BtnAccept>
                <BtnText>Accept</BtnText>
              </BtnAccept>
            </TouchableOpacity>
          )}
          {item.phone_number ?? (
            <BtnsWrapper>
              <BtnCall
                onPress={() => {
                  Linking.openURL(`tel:${item.phone_number}`);
                }}>
                <BtnCallText>Call</BtnCallText>
              </BtnCall>

              <BtnMsg
                onPress={() => {
                  Linking.openURL(`sms:${item.phone_number}`);
                }}>
                <BtnMsgText>Message</BtnMsgText>
              </BtnMsg>
            </BtnsWrapper>
          )}
          {item.left_coordinate === '0.0000000000000000' ? (
            <NoteView>
              <NoteText style={{color: 'red'}}>Location not found</NoteText>
            </NoteView>
          ) : (
            <TouchableOpacity onPress={() => ViewMap(item)}>
              <NoteView>
                <NoteText>View Map</NoteText>
              </NoteView>
            </TouchableOpacity>
          )}
        </BottomWrapper>
      </View>
    );
  };

  return (
    <>
      <MyHeader
        HeaderText="Job Details"
        onPress={() => props.navigation.goBack()}
      />
      <Wrapper>
        {loading ? (
          <ActivityIndicator size="large" color={'#4f45a8'} />
        ) : (
          <FlatList
            data={historyDetail}
            keyExtractor={item => item.id}
            renderItem={CardRendrer}
          />
        )}
      </Wrapper>
    </>
  );
};

export default connect()(HistoryDetails);
