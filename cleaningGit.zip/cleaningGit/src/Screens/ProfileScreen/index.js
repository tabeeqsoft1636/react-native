import React, {useState} from 'react';
import {View, Image, ScrollView} from 'react-native';
import {connect} from 'react-redux';
import {Colors} from '../../Theme';

import {useDispatch} from 'react-redux';
import {ButtonComponent, InputField} from '../../Components';
import ImagePicker from 'react-native-image-crop-picker';
import {api} from 'store/apiCalls';
import {ProfileHeader} from '_shared';

import {Wrapper, ProfileButton, LabelText} from './style';

const ProfileScreen = props => {
  const user = props.state.USER_DETAIL?.user;
  const [isEditable, setIsEditable] = useState(false);
  const [image, setImage] = useState(null);
  const [userInfo, setUserInfo] = useState({
    ...user,
    user: user?.user || user?.id,
  });
  const dispatch = useDispatch();

  const uploadImage = () => {
    ImagePicker.openPicker({
      cropping: true,
    }).then(img => {
      setImage(img);
    });
  };

  const textOnchange = (value, name) => {
    setUserInfo(pre => ({...pre, [name]: value}));
  };

  const INPUT_FIELDS = [
    {
      name: 'full_name',
      label: 'Full Name',
      placeholder: 'Full Name',
      value: userInfo.full_name,
      keyboardType: 'email-address',
    },
    {
      name: 'email',
      label: 'Email Address',
      placeholder: 'Email Address',
      value: userInfo.email,
      keyboardType: 'email-address',
    },
    {
      name: 'phone_number',
      label: 'Phone',
      placeholder: '+8812341234',
      value: userInfo.phone_number,
      keyboardType: 'number-pad',
    },
    {
      name: 'zip_code',
      label: 'Zipcode',
      placeholder: 'zipcode',
      value: userInfo.zip_code,
      keyboardType: 'number-pad',
    },
  ];

  const save = () => {
    const form = new FormData();
    if (image) {
      const imgObj = {
        uri: image.path,
        type: image.mime,
        name: `${new Date()}.jpg`,
      };
      form.append('avatar', imgObj);
    }

    Object.entries(userInfo).forEach(([key, value]) => {
      if (key !== 'avatar') form.append(key, value);
    });

    api.apiProfileUpdate(form, responseFunction);
  };

  const responseFunction = async resp => {
    if (resp.sucess) {
      let user_detail = props.state.USER_DETAIL;
      user_detail = {...user_detail, user: resp.sucess.data};
      dispatch({type: 'USER_DETAIL', user_detail});
      setIsEditable(false);
    } else {
      alert(JSON.stringify(resp.error));
    }
  };

  return (
    <>
      <ProfileHeader />
      <Wrapper>
        <View style={{flex: 1}}>
          <ScrollView>
            <ProfileButton onPress={() => uploadImage(true, true)}>
              <Image
                source={
                  image
                    ? {uri: image.path}
                    : require('theme/Images/userprofile.png')
                }
                style={{width: 80, height: 80, borderRadius: 50}}
              />
            </ProfileButton>

            {INPUT_FIELDS.map((item, index) => {
              return (
                <View key={index}>
                  <LabelText>{item.label}</LabelText>
                  <InputField
                    autoCapitalize="none"
                    bgColorCode={isEditable && '#f3f1ff'}
                    editable={isEditable}
                    onChangeText={text => textOnchange(text, item.name)}
                    {...item}
                  />
                </View>
              );
            })}
          </ScrollView>
        </View>
        {isEditable ? (
          <>
            <ButtonComponent
              onPress={() => save()}
              buttonText={'Save'}
              color={Colors.themeColor}
            />
            <ButtonComponent
              onPress={() => setIsEditable(false)}
              buttonText={'Cancel'}
              textStyle={{color: '#000'}}
              style={{borderColor: '#686868', borderWidth: 1}}
            />
          </>
        ) : (
          <ButtonComponent
            onPress={() => setIsEditable(true)}
            buttonText={'Edit'}
            color={Colors.themeColor}
          />
        )}
      </Wrapper>
    </>
  );
};

const mapStateToProps = state => {
  return {state};
};

export default connect(mapStateToProps)(ProfileScreen);
