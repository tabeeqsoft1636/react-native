import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';

import {connect} from 'react-redux';

import {InputField} from '../../../Components';
import {Wrapper, MainWrapper, Welcomelabel, Title} from './style';

const LoginScreen = props => {
  const [userDetail, setUserDetail] = useState({});
  const ChangePassword = () => {
    props.navigation.navigate('ChangePassword');
  };

  const textOnchange = (text, name) => {
    let user = userDetail;
    user[name] = text;
    setUserDetail(user);
  };

  return (
    <Wrapper>
      <MainWrapper>
        <Welcomelabel>Forget Password</Welcomelabel>
        <Title>{'Forgot password?'}</Title>

        <View style={{}}>
          <InputField
            placeholder={'Enter email address'}
            onChangeText={text => textOnchange(text, 'email')}
            // icon={Images.Email}
            iconStyle={{width: 20, height: 15}}
            keyboardType="email-address"
            disableFullscreenUI={true}
            autoCapitalize="none"
            secureTextEntry={false}
          />
          <Text style={{margin: 10}}>
            You will receive an email to reset password
          </Text>
        </View>

        {/* Login Button */}
        <View
          style={{
            flexDirection: 'row',
            // alignSelf: "center",
          }}>
          <TouchableOpacity
            style={{
              width: 56,
              height: 56,
              marginTop: 20,
              marginLeft: 24,
              backgroundColor: '#EFEFEF',
            }}>
            <Image
              style={{width: 18.67, height: 18.67, margin: 20}}
              source={require('../../../Theme/Images/leftarrow.png')}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              width: 156,
              height: 56,
              marginTop: 20,
              marginRight: 24,
              marginLeft: 80,
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: '#4F45A8',
            }}
            onPress={ChangePassword}>
            <Text style={{margin: 20, color: 'white'}}>Reset</Text>
            <Image
              style={{width: 18.67, height: 18.67, marginLeft: 10}}
              source={require('../../../Theme/Images/rightarrow.png')}
            />
          </TouchableOpacity>
          {/* <ButtonComponent
            buttonText={Language.ForgetPasswordButtonSendResetLink}
            onPress={forgetPasswordHandler}
            color={Colors.themeGrey}
          /> */}
        </View>
      </MainWrapper>
    </Wrapper>
  );
};

export default connect()(LoginScreen);
