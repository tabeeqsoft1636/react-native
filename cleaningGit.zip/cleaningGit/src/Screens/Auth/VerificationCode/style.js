import styled from "styled-components/native";
import { Colors } from "../../../Theme";

export const Wrapper = styled.View`
  background-color: ${Colors.white};
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const MainWrapper = styled.View`
  flex: 1;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 20px;
  color: black;
`;

export const Title = styled.Text`
  font-size: 24px;
  color: #383838;
  font-weight: 400;
`;
