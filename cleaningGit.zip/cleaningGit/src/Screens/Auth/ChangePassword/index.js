import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';

import {connect} from 'react-redux';

import {InputField, NavigationHeader} from '../../../Components';
import {LeftarrowSVG} from '../../../Theme/SVG';

import {Wrapper, MainWrapper, Title} from './style';
import {colors} from 'react-native-elements';

const ChangePassword = () => {
  const [userDetail, setUserDetail] = useState({});
  const textOnchange = (text, name) => {
    let user = userDetail;
    user[name] = text;
    setUserDetail(user);
  };

  return (
    <Wrapper>
      <NavigationHeader
        HeaderText="Change Password"
        // LeftOnPress={() => this.props.navigation.navigate("")}
        LeftIcon={<LeftarrowSVG width={20} height={20} fill={colors.black} />}
      />
      <MainWrapper>
        <View style={{}}>
          <Title>{'Current Password'}</Title>
          <InputField
            // placeholder={"Enter email address"}
            onChangeText={text => textOnchange(text, 'email')}
            // icon={Images.Email}
            iconStyle={{width: 20, height: 15}}
            // keyboardType="email-address"
            disableFullscreenUI={true}
            autoCapitalize="none"
            secureTextEntry={true}
          />
        </View>
        <View style={{}}>
          <Title>{'New Password'}</Title>
          <InputField
            // placeholder={"Enter email address"}
            onChangeText={text => textOnchange(text, 'email')}
            // icon={Images.Email}
            iconStyle={{width: 20, height: 15}}
            // keyboardType="email-address"
            disableFullscreenUI={true}
            autoCapitalize="none"
            secureTextEntry={true}
          />
        </View>
        <View style={{}}>
          <Title>{'Confirm New Password'}</Title>
          <InputField
            // placeholder={"Enter email address"}
            onChangeText={text => textOnchange(text, 'email')}
            // icon={Images.Email}
            iconStyle={{width: 20, height: 15}}
            // keyboardType="email-address"
            disableFullscreenUI={true}
            autoCapitalize="none"
            secureTextEntry={true}
          />
        </View>

        {/* Login Button */}
        <TouchableOpacity
          style={{
            width: 327,
            height: 56,
            marginTop: 300,
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: '#4F45A8',
          }}>
          <Text style={{fontSize: 17, color: 'white'}}>Change Password</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            width: 327,
            height: 56,
            marginTop: 10,
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#686868',
          }}>
          <Text style={{fontSize: 17, color: 'black'}}>Cancel</Text>
        </TouchableOpacity>
      </MainWrapper>
    </Wrapper>
  );
};

export default connect()(ChangePassword);
