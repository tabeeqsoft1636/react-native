import styled from 'styled-components/native';
import {Colors} from '../../../Theme';

export const Wrapper = styled.View`
  background-color: ${Colors.white};
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 85%;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 20px;
  color: black;
`;

export const Title = styled.Text`
  font-size: 15px;
  margin-top: 10px;
  color: #383838;
  font-weight: 400;
`;
export const ChangePasswordBtn = styled.TouchableOpacity`
  width: 327px;
  height: 56px;
  margin-top: 300px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  background-color: #4f45a8;
`;
export const CancelButton = styled.TouchableOpacity`
  width: 327px;
  height: 56px;
  margin-top: 10px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  border-width: 1px;
  border-color: #686868;
`;
export const LabelText = styled.Text`
  font-size: 17px;
  color: white;
`;
