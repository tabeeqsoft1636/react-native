/* eslint-disable no-alert */
import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {Text, TouchableOpacity, View, SafeAreaView} from 'react-native';
import {connect, useDispatch} from 'react-redux';

import {api} from 'store/apiCalls';
import {ButtonComponent, InputField} from 'components';
import {Colors, Images} from 'theme';
import {AsyncStorage} from 'theme/Libraries';
import {emailValidator, passwordValidator} from 'theme/utils';
import {GuestBtn, Wrapper, styles} from './style';
const SignupScreen = props => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [loading, setLoading] = useState(false);
  const [userDetail, setUserDetail] = useState({});
  const redirectTo = props.route?.params?.redirectTo;

  const responseFunction = async resp => {
    setLoading(false);
    if (resp.sucess) {
      const data = resp.sucess.data;
      const {token, user} = data;
      dispatch({type: 'USER_DETAIL', data});
      dispatch({type: 'TOKEN', data: token});
      await AsyncStorage.setItem('@token', JSON.stringify(token));
      await AsyncStorage.setItem('@userType', JSON.stringify(user?.user_type));

      await AsyncStorage.setItem('@credientials', JSON.stringify(userDetail));
      if (redirectTo && redirectTo === 'PaymentScreen') {
        navigation.navigate('PaymentScreen');
      } else {
        if (user?.user_type === 'cleaner') {
          navigation.navigate('CleanerStack');
        } else {
          navigation.navigate('HomeScreen');
        }
      }
    } else {
      const fieldError = Object.keys(resp.error)?.[0];
      const messageError = resp.error[fieldError]?.[0];
      alert(`${fieldError} : ${messageError}`);
    }
    setLoading(false);
  };

  const loginAction = () => {
    try {
      if (!userDetail.username) {
        alert('Email is mendatory');
      } else if (!userDetail.password) {
        alert('Password is mendatory');
      } else {
        const emailError = emailValidator(userDetail.email);
        const passwordError = passwordValidator(userDetail.password);
        if (emailError && userDetail.email) {
          alert(emailError);
        } else if (passwordError) {
          alert(passwordError);
        } else {
          setLoading(true);
          api.apiLoginRequest(userDetail, responseFunction);
        }
      }
    } catch (e) {
      setLoading(false);
    }
  };

  const signup = () => {
    navigation.navigate('SignupScreen');
  };

  const forgot = () => {
    navigation.navigate('ForgetPassword');
  };
  const textOnchange = (text, name) => {
    let user = userDetail;
    user[name] = text;
    setUserDetail(user);
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Wrapper>
        <View
          style={{
            flexDirection: 'row',
            marginTop: '10%',
          }}>
          <Text style={[styles.signupText, {fontWeight: '700'}]}>
            Log in{' '}
            <Text style={[styles.signupText, {fontWeight: '400'}]}>
              to <Text style={styles.customerText}>Lauras Cleaning</Text>
            </Text>{' '}
          </Text>
        </View>
        <View style={{marginTop: '5%'}}>
          <Text
            style={{
              fontWeight: '400',
              color: '#383838',
            }}>
            Let us know how can we help you
          </Text>
        </View>
        <View style={styles.inputView}>
          <InputField
            keyboardType="email-address"
            autoCapitalize="none"
            placeholder={'Email'}
            onChangeText={text => textOnchange(text, 'username')}
          />
        </View>
        <View style={styles.inputView}>
          <InputField
            placeholder={'Password'}
            onChangeText={text => textOnchange(text, 'password')}
            keyboardType="email-address"
            disableFullscreenUI={true}
            autoCapitalize="none"
            secureTextEntry={true}
          />
        </View>
        <TouchableOpacity
          style={{
            height: 20,
            margin: 20,
            alignSelf: 'center',
          }}
          onPress={forgot}>
          <Text style={{color: '#4F45A8'}}>Forgot Password?</Text>
        </TouchableOpacity>

        <View style={{width: '100%', alignSelf: 'center'}}>
          <ButtonComponent
            buttonText={'Log in '}
            onPress={loginAction}
            color={Colors.themeColor}
            Image={Images.RightArrow}
            loading={loading}
          />
        </View>
        <GuestBtn onPress={() => navigation.navigate('StartScreen')}>
          <Text style={{fontSize: 17, fontWeight: '800'}}>
            Continue as guest
          </Text>
        </GuestBtn>
      </Wrapper>
      <View
        style={{
          alignItems: 'center',
          alignSelf: 'center',
          flexDirection: 'row',
          justifyContent: 'center',
        }}>
        <Text style={{fontSize: 14, lineHeight: 20, fontWeight: '700'}}>
          Don't have an account?
        </Text>
        <TouchableOpacity style={{marginLeft: 5}} onPress={signup}>
          <Text
            style={{
              fontSize: 14,
              color: '#4F45A8',
              lineHeight: 20,
              fontWeight: '700',
            }}>
            Sign Up
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default connect()(SignupScreen);
