import styled from 'styled-components/native';
import {Colors} from '../../../Theme';
import {StyleSheet} from 'react-native';
export const Wrapper = styled.View`
  background-color: ${Colors.white};
  flex: 1;
  padding-horizontal: 5%;
`;

export const CredientialsWrapper = styled.View`
  flex: 1;
`;

export const LogoImage = styled.Image`
  margin-top: 100px;
  width: 200px;
  height: 185px;
  align-self: center;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 24px;
  color: ${Colors.white};
`;

export const Titlelabel = styled.Text`
  margin-top: 10px;
  align-self: center;
  margin-bottom: 30px;
  font-size: 34px;
  color: ${Colors.white};
  font-weight: 700;
`;

export const ForgetPasswordWrapper = styled.TouchableOpacity`
  margin: 10px;
  align-self: flex-end;
  font-size: 11px;
`;

export const ForgetPasswordText = styled.Text`
  font-size: 11px;
`;
export const GuestBtn = styled.TouchableOpacity`
  background-color: ${props => (props.color ? props.color : '#FFFFFF47')};
  align-self: center;
  justify-content: center;
  align-items: center;
  margin-top: 10px;
  padding: 15px;
  width: 100%;
  border-width: 1px;
`;
export const OrWrapper = styled.Text`
  font-size: 14px;
  align-self: center;
  margin: 10px;
  color: ${Colors.white};
`;
export const styles = StyleSheet.create({
  signupText: {
    fontSize: 24,
    lineHeight: 28,
  },
  customerText: {
    fontWeight: '700',
    lineHeight: 28,
    fontSize: 24,
    textDecorationLine: 'underline',
    color: '#4F45A8',
  },
  box: {
    padding: 15,
    width: '48%',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#C9CED1',
    backgroundColor: 'white',
  },
  inputView: {
    borderWidth: 1,
    marginTop: 16,
    borderColor: '#4F45A8',
    backgroundColor: '#EFEFEF',
    alignSelf: 'center',
  },
  services: {
    flexDirection: 'row',
    marginTop: 15,
    justifyContent: 'space-between',
  },
});
export default styles;
