/* eslint-disable no-alert */
import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {Checkbox} from 'react-native-paper';
import {connect, useDispatch} from 'react-redux';
import {api} from 'store/apiCalls';
import {ButtonComponent, InputField} from 'components';
import {Colors} from 'theme';
import {emailValidator, passwordValidator} from 'theme/utils';
import {GuestBtn, Wrapper, styles} from './style';
const SignupScreen = props => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [loading, setLoading] = useState(false);
  const [userDetail, setUserDetail] = useState({});
  const [checked, setChecked] = React.useState(false);
  const [remeberChecked, setRemeberChecked] = React.useState(false);
  const [userType, setUserType] = useState('customer');

  const redirectTo = props.route?.params?.redirectTo;
  const responseFunction = resp => {
    if (resp.sucess) {
      const data = resp.sucess.data;
      dispatch({type: 'USER_DETAIL', data});
      if (redirectTo && redirectTo === 'PaymentScreen') {
        navigation.navigate('PaymentScreen');
      } else {
        navigation.navigate('LoginScreen', {redirectTo});
      }
    } else {
      const fieldError = Object.keys(resp.error)?.[0];
      const messageError = resp.error[fieldError]?.[0];
      alert(`${fieldError} : ${messageError}`);
    }
    setLoading(false);
  };

  const signUpAction = async () => {
    try {
      if (!userDetail.email) {
        alert('Email is mendatory');
      } else if (!userDetail.phoneNumber) {
        alert('Phone number is mendatory');
      } else if (!userDetail.password) {
        alert('Password is mendatory');
      } else {
        const emailError = emailValidator(userDetail.email);
        const passwordError = passwordValidator(userDetail.password);
        if (emailError && userDetail.email) {
          alert(emailError);
        } else if (passwordError) {
          alert(passwordError);
        } else {
          setLoading(true);
          api.apiSignupRequest(
            {...userDetail, user_type: userType},
            responseFunction,
          );
        }
      }
    } catch (e) {
      console.log({e});
      setLoading(false);
    }
  };

  const textOnchange = (text, name) => {
    let user = userDetail;
    user[name] = text;
    setUserDetail(user);
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: 'white'}}>
      <Wrapper>
        <ScrollView>
          <View
            style={{
              flexDirection: 'row',
              marginTop: '10%',
            }}>
            <Text style={[styles.signupText, {fontWeight: '700'}]}>
              Sign Up
              <Text style={[styles.signupText, {fontWeight: '400'}]}>
                as a <Text style={styles.customerText}>{userType}</Text>
              </Text>
            </Text>
          </View>
          <View
            style={{
              marginTop: 16,
            }}>
            <Text
              style={{
                fontWeight: '400',
                // lineHeight: 28,
                color: '#383838',
              }}>
              Let us know how can we help you
            </Text>
          </View>
          <View style={styles.services}>
            <TouchableOpacity
              onPress={() => setUserType('customer')}
              style={[
                styles.box,
                {
                  backgroundColor: userType === 'customer' ? '#DCD8FF' : '#fff',
                },
              ]}>
              <Text>Customer</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setUserType('cleaner')}
              style={[
                styles.box,
                {backgroundColor: userType === 'cleaner' ? '#DCD8FF' : '#fff'},
              ]}>
              <Text>Cleaner</Text>
            </TouchableOpacity>
          </View>
          <View>
            <View style={styles.inputView}>
              <InputField
                keyboardType="email-address"
                autoCapitalize="none"
                placeholder={'Email'}
                // placeholder={Language.SignupInputPlaceholderUsername}
                onChangeText={text => textOnchange(text, 'email')}
                // icon={Images.USERNAME}
              />
            </View>
            <View style={styles.inputView}>
              <InputField
                keyboardType="phone-pad"
                placeholder={'Mobile Number'}
                // placeholder={Language.SignupInputPlaceholderUsername}
                onChangeText={text => textOnchange(text, 'phoneNumber')}
                // icon={Images.USERNAME}
              />
            </View>
            <View style={styles.inputView}>
              <InputField
                placeholder={'Password'}
                // placeholder={Language.SignupInputPlaceholderPassword}
                onChangeText={text => textOnchange(text, 'password')}
                // icon={Images.PASSWORD}
                keyboardType="email-address"
                disableFullscreenUI={true}
                secureTextEntry={true}
                autoCapitalize="none"
              />
            </View>
            <View style={styles.inputView}>
              <InputField
                // placeholder={Language.SignupInputPlaceholderPassword}
                placeholder={'Repeat Password'}
                onChangeText={text => textOnchange(text, 'password')}
                // icon={Images.PASSWORD}
                keyboardType="email-address"
                disableFullscreenUI={true}
                autoCapitalize="none"
                secureTextEntry={true}
              />
            </View>
          </View>
          <TouchableOpacity
            style={{flexDirection: 'row', marginTop: 24}}
            onPress={() => navigation.navigate('TermsandConditions')}>
            <Checkbox
              color="#4F45A8"
              status={checked ? 'checked' : 'unchecked'}
              onPress={() => {
                setChecked(!checked);
              }}
            />
            <Text style={{marginTop: 7, width: '80%'}}>
              I have read Terms and Conditions and Privacy Policy
            </Text>
          </TouchableOpacity>
          <View
            style={{flexDirection: 'row', marginTop: 16, alignItems: 'center'}}>
            <Checkbox
              color="#4F45A8"
              status={remeberChecked ? 'checked' : 'unchecked'}
              onPress={() => {
                setRemeberChecked(!remeberChecked);
              }}
            />
            <Text style={{fontSize: 14}}>Remeber</Text>
          </View>
          <ButtonComponent
            buttonText={'Sign Up'}
            onPress={signUpAction}
            color={Colors.themeColor}
            loading={loading}
          />
          <GuestBtn onPress={() => navigation.navigate('StartScreen')}>
            <Text style={{fontSize: 17, fontWeight: '800'}}>
              Continue as guest
            </Text>
          </GuestBtn>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              alignSelf: 'center',
              flexDirection: 'row',
              justifyContent: 'center',
              marginTop: 20,
            }}>
            <Text style={{fontSize: 14, lineHeight: 20, fontWeight: '700'}}>
              Already have an account?
            </Text>
            <TouchableOpacity
              style={{marginLeft: 5}}
              onPress={() => navigation.navigate('LoginScreen', {redirectTo})}>
              <Text
                style={{
                  fontSize: 14,
                  color: '#4F45A8',
                  lineHeight: 20,
                  fontWeight: '700',
                }}>
                Log in
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </Wrapper>
    </SafeAreaView>
  );
};

export default connect()(SignupScreen);
