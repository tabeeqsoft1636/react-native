import React, {useState} from 'react';
import {useNavigation} from '@react-navigation/native';
import {View, Text, Image, TouchableOpacity, SafeAreaView} from 'react-native';
import {connect} from 'react-redux';

import {InputField} from 'components';
import {Wrapper, Title} from './style';

const LoginScreen = () => {
  const [userDetail, setUserDetail] = useState({});

  const navigation = useNavigation();
  const ChangePassword = () => {
    navigation.navigate('LoginScreen');
  };

  const textOnchange = (text, name) => {
    let user = userDetail;
    user[name] = text;
    setUserDetail(user);
  };

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: '#fff',
      }}>
      <Wrapper>
        <Title>{'Forgot password?'}</Title>
        <InputField
          placeholder={'Enter email address'}
          onChangeText={text => textOnchange(text, 'email')}
          iconStyle={{width: 20, height: 15}}
          keyboardType="email-address"
          disableFullscreenUI={true}
          autoCapitalize="none"
          secureTextEntry={false}
        />
        <Text style={{margin: 10}}>
          You will receive an email to reset password
        </Text>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginTop: 10,
          }}>
          <TouchableOpacity
            onPress={() => navigation.navigate('LoginScreen')}
            style={{
              paddingHorizontal: 10,
              backgroundColor: '#EFEFEF',
            }}>
            <Image
              style={{width: 18, height: 18, margin: 20}}
              source={require('theme/Images/leftarrow.png')}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              paddingHorizontal: 10,
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: '#4F45A8',
            }}
            onPress={ChangePassword}>
            <Text style={{margin: 20, color: 'white'}}>Reset</Text>
            <Image
              style={{width: 18, height: 18, marginLeft: 10}}
              source={require('theme/Images/rightarrow.png')}
            />
          </TouchableOpacity>
        </View>
      </Wrapper>
    </SafeAreaView>
  );
};

export default connect()(LoginScreen);
