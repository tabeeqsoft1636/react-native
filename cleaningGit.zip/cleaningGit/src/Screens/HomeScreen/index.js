import React, {useEffect, useState} from 'react';
import {View, Text, SafeAreaView} from 'react-native';
import {useDispatch, useSelector, connect} from 'react-redux';
import DropDown from 'react-native-paper-dropdown';

import useRequests from 'store/request';
import {api} from 'store/apiCalls';
import {Images, Colors} from 'theme';
import {ProfileHeader} from '_shared';
import {ButtonComponent} from 'components';

import {Wrapper, MainWrapper, BottomWrapper} from './style';

const HomeScreen = props => {
  const dispatch = useDispatch();
  const reduxData = useSelector(state => state);
  const {selectionUpdate} = useRequests();

  const [bedRoomListOpen, setBedRoomListOpen] = useState(false);
  const [bathRoomListOpen, setBathRoomListOpen] = useState(false);
  const [bathRoomList, setBathRoomList] = useState([]);
  const [bedRoomList, setBedRoomList] = useState([]);
  const [data, setData] = useState({});

  useEffect(() => {
    api.apiBedroomList(bedRoomListResponse);
    api.apiBathroomList(bathRoomListResponse);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const bedromItem = data?.bedroom?.find(
      e => e.id === reduxData?.selectedBedroom,
    );
    const bathroomItem = data?.bathroom?.find(
      e => e.id === reduxData?.selectedBathroom,
    );

    let priceSum = 0.0;
    if (bedromItem) {
      priceSum += parseFloat(bedromItem.price);
    }
    if (bathroomItem) {
      priceSum += parseFloat(bathroomItem.price);
    }
    dispatch({type: 'PRICE_UPDATE', data: priceSum});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduxData?.selectedBathroom, reduxData?.selectedBedroom]);

  const bedRoomListResponse = resp => {
    const res = resp.sucess?.results;
    setData(prev => ({...prev, bedroom: res}));
    let drop = [];
    res.forEach(element => {
      drop.push({label: element.room_name, value: element.id, ...element});
    });
    dispatch({type: 'ROOMS_LIST', data: drop});
    setBedRoomList(drop);
  };

  const bathRoomListResponse = resp => {
    const res = resp.sucess?.results;
    setData(prev => ({...prev, bathroom: res}));
    let drop = [];
    res.forEach(element => {
      drop.push({label: element.room_name, value: element.id, ...element});
    });
    dispatch({type: 'BATHROOMS_LIST', data: drop});
    setBathRoomList(drop);
  };

  const login = () => {
    props.navigation.navigate('CreateNewRequest');
  };

  const dropdownSelection = (e, name) => {
    dispatch({type: name, data: e});
  };

  useEffect(() => {
    const selection = bedRoomList?.find(
      res => res.id === reduxData?.selectedBedroom,
    );

    selectionUpdate('room', selection);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduxData?.selectedBedroom]);

  useEffect(() => {
    const selection = bathRoomList?.find(
      res => res.id === reduxData?.selectedBathroom,
    );

    selectionUpdate('bathroom', selection);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduxData?.selectedBathroom]);

  return (
    <Wrapper>
      {reduxData.TOKEN ? <ProfileHeader /> : <SafeAreaView />}
      <MainWrapper>
        <View style={{padding: 30}}>
          <Text style={{alignSelf: 'center', fontSize: 24}}>
            Hi{' '}
            <Text style={{color: '#4F45A8', fontWeight: '700'}}>
              {reduxData.USER_DETAIL?.user?.full_name}
            </Text>
          </Text>

          <Text style={{alignSelf: 'center', fontSize: 16}}>
            Let's get started
          </Text>
        </View>
        <View style={{flexDirection: 'row', marginBottom: 20}}>
          <View style={{width: '48%', height: 56}}>
            <DropDown
              label={'Bed Rooms'}
              mode={'outlined'}
              visible={bedRoomListOpen}
              showDropDown={() => setBedRoomListOpen(true)}
              onDismiss={() => setBedRoomListOpen(false)}
              value={reduxData?.selectedBedroom}
              setValue={e => dropdownSelection(e, 'UPDATE_ROOM_SELECTION')}
              list={bedRoomList}
            />
          </View>
          <View style={{width: '48%', height: 56, marginLeft: '4%'}}>
            <DropDown
              label={'Bathrooms'}
              mode={'outlined'}
              visible={bathRoomListOpen}
              showDropDown={() => setBathRoomListOpen(true)}
              onDismiss={() => setBathRoomListOpen(false)}
              value={reduxData?.selectedBathroom}
              setValue={e => dropdownSelection(e, 'UPDATE_BATHROOM_SELECTION')}
              list={bathRoomList}
            />
          </View>
        </View>
        <ButtonComponent
          buttonText={`Book From $${reduxData?.price}`}
          onPress={login}
          color={Colors.themeColor}
          Image={Images.RightArrow}
        />
      </MainWrapper>
      {!reduxData.TOKEN && (
        <BottomWrapper>
          <ButtonComponent
            buttonText={'Login'}
            onPress={() => props.navigation.navigate('LoginScreen')}
            color={Colors.themeColor}
          />
          <ButtonComponent
            buttonText={'Signup'}
            onPress={() => props.navigation.navigate('SignupScreen')}
            color={Colors.themeColor}
          />
        </BottomWrapper>
      )}
    </Wrapper>
  );
};

export default connect()(HomeScreen);
