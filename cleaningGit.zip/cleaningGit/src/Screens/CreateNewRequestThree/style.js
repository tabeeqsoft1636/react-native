import styled from 'styled-components/native';
import {Colors} from '../../Theme';
import {StyleSheet} from 'react-native';
export const Wrapper = styled.View`
  background-color: ${Colors.BACKGROUND};
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 90%;
`;

export const ButtonWrapper = styled.TouchableOpacity`
  width: 50%;
  height: 56px;
  margin-top: 10px;
  border-width: 1px;
  justify-content: center;
  align-items: center;
  border-color: #c9ced1;
  background-color: ${props => (props.selected ? '#4F45A8' : '#fff')};
`;

export const Label = styled.Text`
  color: ${props => (props.selected ? '#fff' : '#000')};
`;

export const Title = styled.Text`
  font-size: 15px;
  margin-top: 15px;
  margin-bottom: 5px;
  color: #383838;
  font-weight: 400;
`;
const styles = StyleSheet.create({
  box: {
    width: '50%',
    height: 56,
    marginTop: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#C9CED1',
    backgroundColor: 'white',
  },
  services: {
    flexDirection: 'row',
    marginTop: 8,
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  floorView: {
    marginTop: 20,
    padding: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  nextButton: {
    width: '50%',
    height: 56,
    bottom: 20,
    flexDirection: 'row',
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    // borderWidth: 1,
    backgroundColor: '#4F45A8',
  },
});
export default styles;
