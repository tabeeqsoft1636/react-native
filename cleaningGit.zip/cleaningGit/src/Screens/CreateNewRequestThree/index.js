/* eslint-disable no-alert */
import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';

import useRequests from 'store/request';
import {InputTextArea, GooglePlacesInput} from 'components';
import {MyHeader, MyHeaderBalance} from '_shared';
import {api} from 'store/apiCalls';
import {Wrapper, MainWrapper, Title, ButtonWrapper, Label} from './style';
import styles from './style';
import {ScrollView} from 'react-native-gesture-handler';

const NewRequestThree = props => {
  const {selectionUpdate} = useRequests();

  const [typeGetIn, setTypeGetIn] = useState(0);
  const [getInTypes, setGetInTypes] = useState([]);
  const [params, setParams] = useState(null);

  useEffect(() => {
    api.apiGetInList(responseFunction);
  }, []);

  const responseFunction = async resp => {
    if (resp.sucess?.results) {
      setGetInTypes(resp.sucess.results);
    } else {
      alert(JSON.stringify(resp.error));
    }
  };

  const signup = () => {
    selectionUpdate('inputParams', params);
    props.navigation.navigate('RequestOverview');
  };

  const setType = item => {
    selectionUpdate('getIn', item);
    setTypeGetIn(item.id);
  };

  const setLocation = (Locdata, details) => {
    const lat = JSON.stringify(details.geometry.location.lat);
    const lng = JSON.stringify(details.geometry.location.lng);

    setParams({
      ...params,
      address: Locdata.description,
      left_coordinate: lat,
      right_coordinate: lng,
    });
  };

  return (
    <Wrapper>
      <MyHeader
        HeaderText="Create A New Request"
        onPress={() => props.navigation.goBack()}
        RightComponent={() => <MyHeaderBalance />}
      />

      <MainWrapper>
        <ScrollView>
          <Title>{'Address'}</Title>
          <View>
            <GooglePlacesInput setLocation={setLocation} />
          </View>
          <Title>{'How do we get in'}</Title>
          <View style={styles.services}>
            {getInTypes.map((item, index) => {
              return (
                <ButtonWrapper
                  key={index}
                  selected={typeGetIn === item.id}
                  onPress={e => setType(item)}>
                  <Label selected={typeGetIn === item.id}>
                    {item.get_name}
                  </Label>
                </ButtonWrapper>
              );
            })}
          </View>

          <Title>{'Other Notes'}</Title>
          <View
            style={{
              marginTop: 20,
              backgroundColor: '#efefef',
            }}>
            <View style={{padding: 20}}>
              <InputTextArea
                keyboardType="email-address"
                autoCapitalize="none"
                placeholder={'Other notes'}
                onChangeText={text => setParams({...params, others_note: text})}
              />
            </View>
          </View>
        </ScrollView>
      </MainWrapper>

      <TouchableOpacity style={styles.nextButton} onPress={signup}>
        <Text style={{fontSize: 17, color: 'white'}}>Next</Text>
      </TouchableOpacity>
    </Wrapper>
  );
};

export default connect()(NewRequestThree);
