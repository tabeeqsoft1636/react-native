import React from 'react';
import {ScrollView, Text, View} from 'react-native';
import {useSelector, connect} from 'react-redux';

import useRequests from 'store/request';
import {MyHeader} from '_shared';
import {api} from 'store/apiCalls';
import {
  Wrapper,
  MainWrapper,
  ServicesWrapper,
  BedroomView,
  ViewLabel,
  NumberText,
  RoomLabelText,
  TotalView,
  TotalText,
  ExtraText,
  SubmitButton,
  CancelButton,
  BtnText,
  CancelBtnText,
  LabelView,
  PriceLabel,
  Title,
} from './style';

const RequestOverview = props => {
  const reduxData = useSelector(state => state);
  const {userSelections} = useRequests();

  // const {extrasList, getIn, getInId, addressOthers, cleaningTypeId} =
  //   props.route?.params;
  const {price} = reduxData;
  const appFee = price * 0.5;
  const address = userSelections?.inputParams?.address;
  const others_note = userSelections?.inputParams?.others_note;
  const cleaning_types = userSelections?.cleaningType?.id;

  const submit = () => {
    const getExtras = userSelections.extras?.filter(e => e.selected);

    let extraIds = [];
    getExtras.forEach(element => {
      extraIds.push(element.id);
    });

    const body = {
      bed_room: reduxData.selectedBedroom,
      bath_room: reduxData.selectedBathroom,
      how_to_get_in: userSelections?.getIn?.id,
      service_price: price,
      app_fee: appFee,
      total_price: appFee + price,
      extra: extraIds,
      address: address,
      others_note: others_note,
      cleaning_type: cleaning_types,
      left_coordinate: reduxData.left_coordinate,
      right_coordinate: reduxData.right_coordinate,
    };

    api.apiHistoryRequest(body, responseFunction);
  };

  const responseFunction = async resp => {
    if (resp.sucess) {
      if (props.state.TOKEN) {
        props.navigation.navigate('PaymentScreen');
      } else {
        props.navigation.navigate('SignupScreen', {
          redirectTo: 'PaymentScreen',
        });
      }
    } else {
      alert(JSON.stringify(resp.error));
    }
  };

  const bedromItem = reduxData?.rooms.find(
    e => e.id === reduxData?.selectedBedroom,
  );
  const bathroomItem = reduxData?.bathrooms?.find(
    e => e.id === reduxData?.selectedBathroom,
  );

  return (
    <Wrapper>
      <MyHeader
        HeaderText="Request Overview"
        onPress={() => props.navigation.goBack()}
      />

      <MainWrapper>
        <Title>{'Deep Cleaning'}</Title>
        <ScrollView>
          <ServicesWrapper>
            <BedroomView style={{flexDirection: 'row'}}>
              <NumberText>{bedromItem?.room_name}</NumberText>
            </BedroomView>
            <ViewLabel style={{flexDirection: 'row', marginTop: 8}}>
              <NumberText>{bathroomItem?.room_name}</NumberText>
            </ViewLabel>
            <ViewLabel>
              <ExtraText>Extra</ExtraText>
              {userSelections.extras?.map(
                (item, index) =>
                  item.selected && (
                    <RoomLabelText key={index}>
                      {item.service_name}
                    </RoomLabelText>
                  ),
              )}
            </ViewLabel>
            <ViewLabel>
              <ExtraText>How to get in</ExtraText>
              <RoomLabelText>{userSelections.getIn.get_name}</RoomLabelText>
            </ViewLabel>
            <ViewLabel>
              <ExtraText>Address</ExtraText>
              <RoomLabelText>{address}</RoomLabelText>
            </ViewLabel>
            <ViewLabel>
              <ExtraText>Extras</ExtraText>
              <RoomLabelText>{others_note}</RoomLabelText>
            </ViewLabel>
            <TotalView>
              <LabelView>
                <Text>Price for the service</Text>
                <PriceLabel>${price}</PriceLabel>
              </LabelView>
              <LabelView>
                <Text>App Fee</Text>
                <PriceLabel>${appFee}</PriceLabel>
              </LabelView>
            </TotalView>
            <LabelView>
              <Text>Total</Text>
              <TotalText>${appFee + price}</TotalText>
            </LabelView>
          </ServicesWrapper>
        </ScrollView>
      </MainWrapper>
      <View style={{marginBottom: 20, width: '90%'}}>
        <SubmitButton onPress={submit}>
          <BtnText>Submit</BtnText>
        </SubmitButton>
        <CancelButton>
          <CancelBtnText>Cancel</CancelBtnText>
        </CancelButton>
      </View>
    </Wrapper>
  );
};

const mapStateToProps = state => {
  return {state};
};

export default connect(mapStateToProps)(RequestOverview);
