import styled from 'styled-components/native';
import {Colors} from '../../Theme';

export const Wrapper = styled.View`
  background-color: ${Colors.BACKGROUND};
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const MainWrapper = styled.View`
  flex: 1;
  width: 85%;
`;
export const ServicesWrapper = styled.View`
  margin-top: 16px;
`;
export const BedroomView = styled.View`
  flex-direction: row;
`;
export const ViewLabel = styled.View`
  flex-direction: row;
  margin-top: 10px;
  flex-wrap: wrap;
`;
export const TotalView = styled.View`
  margin-top: 16px;
  border-top-width: 0.5px;
  border-bottom-width: 0.5px;
`;

export const ExtraText = styled.Text`
  align-self: center;
  font-size: 14px;
  font-weight: 700;
`;
export const TotalText = styled.Text`
  font-size: 18px;
  font-weight: bold;
  color: #4f45a8;
`;

export const RoomLabelText = styled.Text`
  align-self: center;
  font-size: 12px;
  margin-left: 8px;
`;

export const NumberText = styled.Text`
  align-self: center;
  font-size: 14px;
  font-weight: bold;
`;

export const Welcomelabel = styled.Text`
  margin-top: 30px;
  align-self: center;
  font-size: 20px;
  color: black;
`;

export const Title = styled.Text`
  font-size: 24px;
  margin-top: 15px;
  margin-bottom: 5px;
  color: #4f45a8;
  font-weight: 700;
`;
export const BtnText = styled.Text`
  font-size: 17px;
  color: #fff;
`;
export const CancelBtnText = styled.Text`
  font-size: 17px;
  color: #000;
`;

export const SubmitButton = styled.TouchableOpacity`
  padding: 15px;
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-self: center;
  align-items: center;
  background-color: #4f45a8;
`;
export const CancelButton = styled.TouchableOpacity`
  padding: 15px;
  width: 100%;
  margin-top: 12px;
  flex-direction: row;
  justify-content: center;
  align-self: center;
  align-items: center;
  border-width: 1px;
`;
export const LabelView = styled.View`
  margin-top: 16px;
  flex-direction: row;
  justify-content: space-between;
`;
export const PriceLabel = styled.Text`
  font-weight: bold;
  font-size: 18px;
`;
