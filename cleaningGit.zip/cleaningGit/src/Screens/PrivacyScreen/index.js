import React from 'react';
import {View} from 'react-native';

import {connect} from 'react-redux';
import {MyHeader} from '_shared';
import {
  Wrapper,
  MainContainer,
  TextContainer,
  TextLabel,
  Welcomelabel,
  WelcomelabelView,
} from './style';
import {ScrollView} from 'react-native-gesture-handler';

const PrivacyScreen = props => {
  return (
    <Wrapper>
      <MyHeader
        HeaderText="Privacy Policy"
        onPress={() => props.navigation.goBack()}
      />
      <ScrollView>
        <MainContainer>
          <WelcomelabelView>
            <Welcomelabel>Privacy Policy</Welcomelabel>
          </WelcomelabelView>
          <TextContainer>
            <TextLabel>
              1. Your Privacy Rights This Privacy Policy describes your privacy
              rights regarding our collection, use, storage, sharing and
              protection of your personal information. Throughout this Privacy
              Policy, we use the term "personal information" to describe
              information that can be associated with a specific person and can
              be used to identify that person. We do not consider personal
              information to include information that has been made anonymous so
              that it does not identify a specific user. This Privacy Policy
              applies to the website of Laura’s Cleaning, Inc. (“Laura’s
              Cleaning”) and all related sites, applications, and services
              regardless of how you access or use them. 2. Scope and Consent You
              accept this Privacy Policy when you sign up for, access, or use
              our services, including, but not limited to, our technologies,
              processes, or functions offered on our website and all related
              sites, applications, customer service team, cleaners, and
              third-party vendors, all of which we refer to simply as the
              “Services.” This Privacy Policy is intended to govern the use of
              the Services by our users (including, without limitation those who
              use the Services in the course of their trade or business) unless
              otherwise agreed through contract.  We may amend this Privacy
              Policy at any time by posting a revised version on our website. 3.
              Collection of Personal Information We collect the following types
              of personal information in order to provide you with the use of
              the Services, and to help us personalize and improve your
              experience. A. Information We Collect Automatically When you use
              the Services, we collect information sent to us by your computer,
              mobile phone or other access device. The information sent to us
              includes, but is not limited to, the following: data about the
              pages you access, computer IP address, device ID or unique
              identifier, device type, geo-location information, computer and
              connection information, mobile network information, statistics on
              page views, traffic to and from the sites, referral URL, ad data,
              and standard web log data and other information. We also collect
              anonymous information through our use of cookies and web beacons.
              B. Information You Provide to Us We may collect and store any
              information you provide us when you use the Services, including
              when you input or add information on a web form, add or update
              your account information, participate in community discussions,
              chats, or dispute resolutions, or when you otherwise correspond
              with us regarding the Services. When you use the Services, we also
              collect information about your transactions and your activities.
              In addition, if you open a Laura’s Cleaning account or use the
              Services, we may collect the following types of information: •
              Contact information, such as your name, address, phone, email and
              other similar information. • Financial information, such as the
              full bank account numbers and/or credit card numbers that you link
              to your Laura’s Cleaning account or give us when you use the
              Services. • Detailed personal information such as your date of
              birth or national ID number. We may also collect information from
              or about you from other sources, such as through your contact with
              us, including our customer support team, your results when you
              respond to a survey, your interactions with members of the Laura’s
              Cleaning corporate family or other companies (subject to their
              privacy policies, terms of service, and applicable law), and from
              other accounts we have reason to believe you control (whether in
              part or in whole). Additionally, for quality and training purposes
              or for its own protection, Laura’s Cleaning may monitor or record
              its telephone conversations, correspondence, or other
              communication with you or anyone acting on your behalf. By
              communicating with Laura’s Cleaning, you acknowledge that your
              communication may be overheard, monitored, or recorded without
              further notice or warning. C. Information from Other Sources We
              may also obtain information about you from third parties such as
              credit bureaus and identity verification services.  You may choose
              to provide us with access to certain personal information stored
              by third parties such as social media sites (e.g., Facebook,
              Instagram, Twitter, Snapchat). The information we may receive
              varies by site and is controlled by that site. By associating an
              account managed by a third party with your Laura’s Cleaning
              account and authorizing Laura’s Cleaning to have access to this
              information, you agree that Laura’s Cleaning may collect, store
              and use this information in accordance with this Privacy Policy.
              D. Information Collected from Our Services We may collect
              information, such as, but not limited to, taking photos and
              recording videos before, during, and after the Services. If
              collected, this information will be used to check quality
              assurance, to assess safety issues, and/or to address
              Services-related concerns. E. Authentication and Fraud Detection
              In order to help protect you from fraud and misuse of your
              personal information, we may collect information about you and
              your interactions with the Services. We may also evaluate your
              computer, mobile phone or other access device to identify any
              malicious software or activity. F. Using Your Mobile Device We may
              offer you the ability to connect with the Services using a mobile
              device, either through a mobile application or via a mobile
              optimized website. The provisions of this Privacy Policy apply to
              all such mobile access and use of mobile devices.When you download
              or use our mobile applications, or access one of our mobile
              optimized sites, we may receive information about your location
              and your mobile device, including a unique identifier for your
              device. We may use this information to provide you with
              location-based services, such as advertising, search results, and
              other personalized content. Most mobile devices allow you to
              control or disable location services in the device's setting's
              menu. If you have questions about how to disable your device's
              location services, you should contact your mobile service carrier
              or the manufacture of your particular device. 4. How We Use the
              Personal Information We Collect Our primary purpose in collecting
              personal information is to provide you with a secure, smooth,
              efficient, and customized experience. We may use your personal
              information to: • provide our Services; • process transactions and
              send notices about your transactions; • verify your identity,
              including during account creation and password reset processes; •
              resolve disputes, collect fees, and troubleshoot problems; •
              manage risk, or to detect, prevent, and/or remediate fraud or
              other potentially prohibited or illegal activities; • detect,
              prevent or remediate violations of policies or applicable user
              agreements; • improve the Services by customizing your user
              experience; • measure the performance of the Services and improve
              their content and layout; • manage and protect our information
              technology infrastructure; • provide targeted marketing and
              advertising, provide service update notices, and deliver
              promotional offers based on your communication preferences; •
              contact you at any telephone number, by placing a voice call or
              through text (SMS) or email messaging; • perform creditworthiness
              and solvency checks, compare information for accuracy and verify
              it with third parties. We may contact you by phone, mail, email,
              text, or other means to notify you regarding your account, to
              troubleshoot problems with your account, to resolve a dispute, to
              collect fees or monies owed, to poll your opinions through surveys
              or questionnaires, or as otherwise necessary to service your
              account. Additionally, we may contact you to offer coupons,
              discounts and promotions, and inform you about the Services and
              the services of our corporate family. Finally, we may contact you
              as necessary to enforce our policies, applicable law, or any
              agreement we may have with you. When contacting you via phone, to
              reach you as efficiently as possible we may use, and you consent
              to receive, autodialed or prerecorded calls and text messages.
              Where applicable and permitted by law, you may decline to receive
              certain communications. 5. Marketing We may combine your personal
              information with information we collect from other companies and
              use it to improve and personalize the Services, content, and
              advertising. If you do not wish to receive marketing
              communications from us or participate in our ad-customization
              programs, simply indicate your preference by emailing us at
              info@laurascleaning.com, or by following the directions that may
              be provided within the communication or advertisement. 6. How We
              Use Cookies and Similar Technologies When you access our website
              or use our Services, we (including companies we work with) may
              place small data files on your computer or other device. These
              data files may be cookies, pixel tags, e-tags, "Flash cookies," or
              other local storage provided by your browser or associated
              applications (collectively "Cookies"). We use these technologies
              to better serve you as a customer – for example, we may use these
              to customize Services, content, and advertising; measure
              promotional effectiveness; help ensure that your account security
              is not compromised; mitigate risk and prevent fraud; and to
              promote trust and safety across our sites and Services. You are
              free to decline our Cookies if your browser or browser add-on
              permits, unless our Cookies are required to prevent fraud or
              ensure the security of websites we control. However, declining our
              Cookies may interfere with your use of our website and Services.
              7. How We Protect and Store Personal Information We store and
              process your personal information on our computers in North
              America, Asia, Europe and elsewhere in the world where our
              facilities are located. We protect your information using
              physical, technical, and administrative security measures to
              reduce the risks of loss, misuse, unauthorized access, disclosure
              and alteration. Some of the safeguards we use are firewalls and
              data encryption, physical access controls to our data centers, and
              information access authorization controls. 8. How We Share
              Personal Information with Third Parties We may share your personal
              information we collect from you, including your name, contact
              details, and transactions and activities, with: • members of the
              Laura’s Cleaning corporate family; • credit bureaus and collection
              agencies to report account information, as permitted by law; •
              companies that we plan to merge with or are acquired by; • law
              enforcement, government officials, or other third parties pursuant
              to a subpoena, court order, or other legal process or requirement
              applicable to Laura’s Cleaning or one of its affiliates; when we
              need to do so to comply with law or credit card rules; or when we
              believe, in our sole discretion, that the disclosure of personal
              information is necessary to prevent physical harm or financial
              loss, to report suspected illegal activity or to investigate
              violations of our Terms of Service; • other unaffiliated third
              parties, for the following purposes: • to customer service for
              customer service purposes, including to help service your accounts
              or resolve disputes (e.g., billing or transactional); and • to
              service providers to enable them to support our business
              operations, such as fraud prevention, bill collection, operations,
              marketing, customer service and technology services • other third
              parties with your consent or direction to do so. If you open a
              Laura’s Cleaning account directly on a third party website or via
              a third party application, any information that you enter on that
              website or application (and not directly on a Laura’s Cleaning
              website) may be shared with the owner of the third party website
              or application. These sites may be governed by their own privacy
              policies and you are encouraged to review their privacy policies
              before providing them with personal information. Laura’s Cleaning
              is not responsible for the content or information practices of
              such third parties. 9. How You Can Access or Change Your Personal
              Information You can review and edit your personal information at
              any time by logging in to your account and reviewing your account
              settings and profile. You can also close your account through the
              Laura’s Cleaning website or by emailing us
              at info@laurascleaning.com. If you close your Laura’s Cleaning
              account, we will mark your account in our database as "Inactive,"
              but may retain personal information from your account for a
              certain period of time and disclose it in a manner consistent with
              our practices under this Privacy Policy for accounts that are not
              closed. We also may retain personal information from your account
              to collect any fees owed, resolve disputes, troubleshoot problems,
              assist with any investigations, prevent fraud, enforce our Terms
              of Service, or take other actions as required or permitted by law.
              10. How You Can Contact Us about Privacy Questions If you have
              questions or concerns regarding this Privacy Policy, you should
              contact us by email at info@laurascleaning.com.
            </TextLabel>
          </TextContainer>
        </MainContainer>
      </ScrollView>
      <View
        style={{
          flexDirection: 'row',
          marginTop: 24,
          marginLeft: 56,
          width: 295,
          height: 38,
          alignItems: 'center',
        }}>
        {/* <Checkbox
          color="#4F45A8"
          status={checked ? 'checked' : 'unchecked'}
          onPress={() => {
            setChecked(!checked);
          }}
        />
        <Text style={{fontSize: 14}}>i agree</Text> */}
      </View>
    </Wrapper>
  );
};

export default connect()(PrivacyScreen);
