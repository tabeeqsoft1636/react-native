import styled from 'styled-components/native';
import {Colors} from '../../Theme';

export const Wrapper = styled.View`
  background-color: ${Colors.white};
  flex: 1;
`;

export const MainContainer = styled.View`
  flex: 1;
  padding-top: 10px;
`;
export const TextContainer = styled.View`
  align-self: center;
  align-items: center;
  padding: 20px;
`;

export const Welcomelabel = styled.Text`
  align-self: center;
  font-size: 20px;
  font-weight: bold;
  line-height: 28px;
  color: black;
`;
export const TextLabel = styled.Text`
  align-self: center;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  color: black;
  text-align: justify;
`;
export const WelcomelabelView = styled.View`
  align-self: center;
  align-items: center;
  height: 56px;
  width: 327px;
  margin-top: 15px;
`;
