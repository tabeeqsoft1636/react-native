import axios from 'axios';

export const BASE_URL = 'https://wandering-term-34267.botics.co'; // your app back-end url

const authAPI = axios.create({
  baseURL: BASE_URL,
  headers: {Accept: 'application/json', 'Content-Type': 'application/json'},
});

function apiLoginRequest(payload, myCallback) {
  const api = `${BASE_URL}/api/v1/login/`;
  axios
    .post(api, payload)
    .then(response => {
      myCallback({sucess: response});
    })
    .catch(error => {
      if (error.response) {
        let message = error.response.data;
        if (error.response.status === 500) {
          message = {Network: [error.response.statusText]};
        }
        myCallback({error: message});
      } else {
        myCallback({error: error});
      }
    });
}

const apiSignupRequest = (payload, myCallback) => {
  const api = `${BASE_URL}/api/v1/signup/`;
  axios
    .post(api, payload)
    .then(response => {
      myCallback({sucess: response});
    })
    .catch(error => {
      if (error.response) {
        let message = error.response.data;
        if (error.response.status === 500) {
          message = {Network: [error.response.statusText]};
        }
        myCallback({error: message});
      } else {
        myCallback({error: error});
      }
    });
};

const apiProfileRequest = (payload, myCallback) => {
  const api = `${BASE_URL}/api/v1/profile/`;
  axios
    .post(api, payload)
    .then(response => {
      myCallback({sucess: response});
    })
    .catch(error => {
      if (error.response) {
        let message = error.response.data;
        if (error.response.status === 500) {
          message = {Network: [error.response.statusText]};
        }
        myCallback({error: message});
      } else {
        myCallback({error: error});
      }
    });
};
const apiServiceRequest = myCallback => {
  const api = `${BASE_URL}/api/v1/service/`;
  axios
    .get(api)
    .then(response => {
      myCallback({sucess: response});
    })
    .catch(error => {
      if (error.response) {
        let message = error.response.data;
        if (error.response.status === 500) {
          message = {Network: [error.response.statusText]};
        }
        myCallback({error: message});
      } else {
        myCallback({error: error});
      }
    });
};

function apiLogoutRequest(payload) {
  return authAPI.post('/rest-auth/logout/', null, {
    headers: {Authorization: `Token ${payload.token}`},
  });
}

function apiAuthUserRequest(payload) {
  return authAPI.get('/rest-auth/user/', null, {
    headers: {Authorization: `Token ${payload.token}`},
  });
}

function apiResetPasswordRequest(payload) {
  return authAPI.post('/rest-auth/password/reset/', payload);
}

function apiFacebookLogin(payload) {
  return authAPI.post('/modules/social-auth/facebook/login/', payload);
}

function apiGoogleLogin(payload) {
  return authAPI.post('/modules/social-auth/google/login/', payload);
}

function apiAppleLogin(payload) {
  return authAPI.post('/modules/social-auth/apple/login/', payload);
}

export const api = {
  apiLoginRequest,
  apiSignupRequest,
  apiProfileRequest,
  apiServiceRequest,
  apiLogoutRequest,
  apiResetPasswordRequest,
  apiAuthUserRequest,
  apiFacebookLogin,
  apiGoogleLogin,
  apiAppleLogin,
};
