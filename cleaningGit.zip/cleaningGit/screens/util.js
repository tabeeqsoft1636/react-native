import {StyleSheet} from 'react-native';
import {Typography} from 'react-native-ui-lib';

export const gScreen = {
  SplashScreen: 'SplashScreen',
  WelcomeScreen: 'WelcomeScreen',
  SignUpScreen: 'SignUpScreen',
  LoginScreen: 'LoginScreen',
  ResetScreen: 'ResetScreen',
  ForgotScreen: 'ForgotScreen',
  TokenScreen: 'TokenScreen',
  // @modules/home
  HomeScreenRoot: 'Home',
  HomeScreen: 'HomeScreen',
  HomeScreenTab: 'HomeScreenTab',

  FeedFilterScreen: 'FeedFilterScreen',
  TutorialScreen: 'TutorialScreen',

  InvestmentsScreen: 'InvestmentsScreen',
  InvestDetailScreen: 'InvestDetailScreen',

  BorrowingScreen: 'BorrowingScreen',
  BorrowDetailScreen: 'BorrowDetailScreen',
  BorrowCreateScreen: 'BorrowCreateScreen',

  MessagesScreen: 'MessagesScreen',
  ProfileScreen: 'ProfileScreen',
  ProfileEditScreen: 'ProfileEditScreen',
  ProfileTermsScreen: 'ProfileTermsScreen',
  ProfilePrivacyScreen: 'ProfilePrivacyScreen',

  NotificationScreen: 'NotificationScreen',

  LoanDetailScreenIn: 'LoanDetailScreenIn',
  LoanDetailScreen: 'LoanDetailScreen',
  ApproveScreen: 'ApproveScreen',
};

export const gColor = {
  primary: '#36424F',
  secondary: '#01D498',
  error: '#F14336',
  loginBg: '#FFF',
  btnTextWhit: '#FFF',
  loginInputLabel: '#36424F70',
  loginBgInput: '#36424F08',

  homeBg: '#F5F8FA',
  homeBgCard: '#FFFFFF',

  homeBlue: '#007AFF',
  homeGray: '#C4C4C4',
  homeTextWhite: '#FFFFFF',
  homeDisabled: '#DDDDDD',
  textGray: '#757575',
};

export const weight = {
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
};

export const textStyles = StyleSheet.create({
  title: {
    fontFamily: 'Poppins',
    fontWeight: weight.semibold,
    fontSize: 20,
    color: gColor.primary,
  },
  body1: {
    fontFamily: 'Poppins',
    fontWeight: weight.regular,
    fontSize: 13,
    color: gColor.primary,
  },
  body2: {
    fontFamily: 'Poppins',
    fontWeight: weight.medium,
    fontSize: 13,
    color: gColor.primary,
  },
  body3: {
    fontFamily: 'Poppins',
    fontWeight: weight.semibold,
    fontSize: 13,
    color: gColor.primary,
  },
  body4: {
    fontFamily: 'Poppins',
    fontWeight: weight.bold,
    fontSize: 13,
    color: gColor.primary,
  },
  link: {
    textDecorationLine: 'underline',
  },
});

Typography.loadTypographies({
  h1: {fontSize: 58, fontWeight: '300', lineHeight: 80},
  h2: {fontSize: 17, fontWeight: '600', fontFamily: 'Poppins'},
  cg: {color: gColor.textGray},
  cb: {color: gColor.homeBlue},
  h3: {
    color: gColor.homeBlue,
    fontSize: 17,
    fontWeight: '500',
    fontFamily: 'SF Pro Text',
  },
  fz18: {fontSize: 18},
  fz17: {fontSize: 17},
  fz24: {fontSize: 24},

  b1: {...textStyles.body1},
  b2: {...textStyles.body2},
  b3: {...textStyles.body3},
  b4: {...textStyles.body4},
});
