from django.contrib import admin
from .models import StripeUserProfile

admin.site.register(StripeUserProfile)