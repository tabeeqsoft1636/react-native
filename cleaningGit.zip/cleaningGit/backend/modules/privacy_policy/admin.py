from django.contrib import admin
from .models import PrivacyPolicy

admin.site.register(PrivacyPolicy)

