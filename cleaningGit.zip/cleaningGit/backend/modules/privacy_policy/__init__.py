default_app_config = "modules.privacy_policy.apps.PrivacyPolicyConfig"
