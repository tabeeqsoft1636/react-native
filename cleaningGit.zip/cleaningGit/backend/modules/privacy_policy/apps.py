from django.apps import AppConfig


class PrivacyPolicyConfig(AppConfig):
    name = "modules.privacy_policy"
    verbose_name = "Privacy Policy"
