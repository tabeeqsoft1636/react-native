default_app_config = "modules.terms_and_conditions.apps.TermsAndConditionsConfig"
