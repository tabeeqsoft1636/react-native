# Camera

Before starting the server run:

```sh
python manage.py migrate
```
