from http.client import HTTPResponse
from django.db import models
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _
from datetime import datetime, timedelta

from django.utils import timezone
from django.core import validators
from django.db import models
from django.contrib.auth.models import AbstractUser,BaseUserManager
from django.utils.translation import gettext_lazy as _
from django.core.validators import MaxLengthValidator,MinLengthValidator
from django.conf import settings
from phonenumber_field.modelfields import PhoneNumberField
from django.db.models.signals import post_save, pre_delete
from django.core.exceptions import ValidationError

from django.dispatch import receiver


class UserManger(BaseUserManager):
    def create_user(self, email, password, **extra_fields):
        """Create and save a User with the given email and password."""
        if not email:
            raise ValueError('The given email must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        #user.fullname = full_name
        user.set_password(password)
        user.save(using=self._db)
        return user
    # def create_user(self, email, password=None):
    #     if not email:
    #         raise ValueError("User must have an email")
    #     user = self.model(email=self.normalize_email(email))
    #     user.set_password(password)
    #     user.save(using=self._db)
    #     return user

    def create_staffuser(self, email, password=None):
        user = self.create_user(email=email,  password=password)
        user.staff = True
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password, **kwargs):
        user = self.model(username=username, is_staff=True, is_superuser=True,
                          **kwargs)
        user.set_password(password)
        user.save()
        return user


class User(AbstractUser):
    # WARNING!
    """
    Some officially supported features of Crowdbotics Dashboard depend on the initial
    state of this User model (Such as the creation of superusers using the CLI
    or password reset in the dashboard). Changing, extending, or modifying this model
    may lead to unexpected bugs and or behaviors in the automated flows provided
    by Crowdbotics. Change it at your own risk.


    This model represents the User instance of the system, login system and
    everything that relates with an `User` is represented by this model.
    """

    # First Name and Last Name do not cover name patterns
    # around the globe.
    name = models.CharField(_("Name of User"), blank=True, null=True, max_length=255)

    #Two Types Of User For Signup---a) Customer b) Cleaner
    user_type = (
        
        ('customer','Customer'),
        ('cleaner','Cleaner'),
        
    )

    user_type = models.CharField(max_length=55, choices=user_type, null=True, blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']
    objects = UserManger()

    def __str__(self): #show the object's name
        return self.email

    def get_absolute_url(self):
        return reverse("users:detail", kwargs={"username": self.username})

      
#Profile 
#Fields-->Full Name,Phone Number,ZIP code,Address

class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    #avatar = models.ImageField(upload_to='profile/images/')

    full_name = models.CharField(_("Name of User"), blank=True, null=True, max_length=255)
    #address = models.CharField(_("Address"), blank=True, null=True, max_length=255)
    phone_number = PhoneNumberField()
    zip_code = models.CharField(_("Zip Code"), blank=True, null=True, max_length=255)
    def __str__(self):
        return self.user.username

    


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_profile(sender, instance, created, **kwargs):
    
    if created:
        user = Profile(user=instance,full_name=instance.name)
        user.save() 


class CleaningType(models.Model):
    cleaning_type_name = models.CharField(
        _("Select Cleaning Type"), blank=True, null=True, max_length=255)

    price = models.DecimalField(default=0,max_digits=6, decimal_places=2)    

    def __str__(self):
        return self.cleaning_type_name


# class ServiceType(models.Model):
#     cleaning_type = models.ForeignKey(
#         CleaningType, on_delete=models.CASCADE)
#     service_type_name = models.CharField(
#         _("Select Service Type"), blank=True, null=True, max_length=255)

#     def __str__(self):
#         return self.service_type_name


class Service(models.Model):
    # service_type = models.ForeignKey(
    #     ServiceType, related_name='servicetype', on_delete=models.CASCADE)
    cleaning_type = models.ForeignKey(
        CleaningType, on_delete=models.CASCADE)
    service_name = models.CharField(
        _("Service Name"), blank=True, null=True, max_length=255)

    #price = models.DecimalField(default=0,max_digits=6, decimal_places=2)    

    #string type added
    def __str__(self):
        return str(self.service_name)


    
class Extra(models.Model):
    # service_type = models.ForeignKey(
    #     ServiceType, related_name='servicetype', on_delete=models.CASCADE)
    service_name = models.CharField(
        _("Service Name"), blank=True, null=True, max_length=255)

    price = models.DecimalField(default=0,max_digits=6, decimal_places=2)       

    def __str__(self):
        return str(self.service_name)    

#Different Room
class Room(models.Model):
    room_name = models.CharField(
        _("Room Name"), blank=True, null=True, max_length=255)

    price = models.DecimalField(default=0,max_digits=6, decimal_places=2)     

    def __str__(self):
        return str(self.room_name)



#Different Number Of BathRoom
class BathRoom(models.Model):
    room_name = models.CharField(
        _("Number Of Bathrooms"), blank=True, null=True, max_length=255)


    price = models.DecimalField(default=0,max_digits=6, decimal_places=2)     

    def __str__(self):
        return str(self.room_name)        


#How Do We Get In
class HowDoWeGet(models.Model):
    get_name = models.CharField(
        _("Get Name"), blank=True, null=True, max_length=255)

    def __str__(self):
        return self.get_name          



class History(models.Model):

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
    )
    
    bed_room = models.ForeignKey(
        Room, on_delete=models.CASCADE)

    bath_room = models.ForeignKey(
        BathRoom, on_delete=models.CASCADE)    

    how_to_get_in = models.ForeignKey(
        HowDoWeGet, on_delete=models.CASCADE,null=True)
    extra = models.ManyToManyField(Extra) 
    
    service_price = models.DecimalField(default=0,max_digits=6, decimal_places=2)
    app_fee = models.DecimalField(default=0,max_digits=6, decimal_places=2)
    total_price = models.DecimalField(default=0,max_digits=6, decimal_places=2)

   

    #string type added
    def __str__(self):
        return self.user + '' + self.total_price       