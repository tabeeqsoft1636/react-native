from rest_framework.authtoken.serializers import AuthTokenSerializer
from rest_framework.viewsets import ModelViewSet, ViewSet
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.decorators import authentication_classes, permission_classes
from home.api.v1.serializers import (
    SignupSerializer,
    UserSerializer,

    PasswordSerializer,
    ProfileSerializer,
    ServiceSerializer,
    ExtraSerializer,
    RoomSerializer,
    BathRoomSerializer,
    HowDOGetserializer,
    Historyserializer
)

from users.models import Profile, Service, CleaningType,Extra,Room,BathRoom,HowDoWeGet


class SignupViewSet(ModelViewSet):
    serializer_class = SignupSerializer
    http_method_names = ["post"]


class LoginViewSet(ViewSet):
    """Based on rest_framework.authtoken.views.ObtainAuthToken"""

    serializer_class = AuthTokenSerializer

    def create(self, request):
        serializer = self.serializer_class(
            data=request.data, context={"request": request}
        )
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        token, created = Token.objects.get_or_create(user=user)
        user_serializer = UserSerializer(user)


        data = user_serializer.data
        profile_id = Profile.objects.get(user=user)

        # data.append({'phone_number':str(profile_id.phone_number),})
        data['phone_number'] = str(profile_id.phone_number)
        data['full_name'] = profile_id.full_name
        data['zip_code'] = profile_id.zip_code
        
        
        # print(data)

       
        return Response(
            {"token": token.key, "user": data, 
        # 'profile_id': profile_id.id,
        # 'full_name':profile_id.full_name,
        # 'phone_number':str(profile_id.phone_number),
        # 'zip_code':profile_id.zip_code
        
        })


# Password Reset

class ResetViewSet(ModelViewSet):
    serializer_class = ProfileSerializer
    http_method_names = ["post"]

    def get_object(self, queryset=None):
        obj = self.request.user
        return
# Profile Serializer
# @authentication_classes([TokenAuthentication])
# @permission_classes([IsAuthenticated])


class ProfileViewSet(ModelViewSet):
    serializer_class = ProfileSerializer
    http_method_names = ["post", "get", "put", "delete"]
    queryset = Profile.objects.all()

    def get(self, request, format=None):
        users = Profile.objects.all()
        serializer = ProfileSerializer(users, many=True)
        return Response(serializer.data)

    def put(self, request,  format=None):
        print("Requested User", request.data)
        #snippet = self.get_object(pk)
        # User = get_user_model()
        # _email = request.data.get('user')
        # print(_email)
        # search_user = User.objects.get(email=request.data.get('email'))
        # print(search_user)
        try:
            snippet = Profile.objects.get(user=request.data.get('user'))

            serializer = ProfileSerializer(snippet, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
        except Profile.DoesNotExist:
            return Response({"profile": 'Profile not found'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ServiceTypeViewSet(ModelViewSet):
    serializer_class = ServiceSerializer
    http_method_names = ["get"]
    queryset = Service.objects.all()
    
    def get_queryset(self):
        """
        This view should return a list of all the service types.
        """
        servicetype_list = Service.objects.all()
        return servicetype_list
        #return list(servicetype_list.values_list('cleaning_type').distinct())


#Extra info

class ExtraTypeViewSet(ModelViewSet):
    serializer_class = ExtraSerializer
    http_method_names = ["get"]
    queryset = Extra.objects.all()
    
    def get_queryset(self):
        """
        This view should return a list of all the service types.
        """
        extra_list = Extra.objects.all()
        return extra_list


#Room info

class RoomTypeViewSet(ModelViewSet):
    serializer_class = RoomSerializer
    http_method_names = ["get"]
    queryset = Room.objects.all()
    
    def get_queryset(self):
        """
        This view should return a list of all the service types.
        """
        room_list = Room.objects.all()
        return room_list        



#Room info

class BathRoomTypeViewSet(ModelViewSet):
    serializer_class = BathRoomSerializer
    http_method_names = ["get"]
    queryset = BathRoom.objects.all()
    
    def get_queryset(self):
        """
        This view should return a list of all the service types.
        """
        bathroom_list = BathRoom.objects.all()
        return bathroom_list                



#HowDoWeGetIn          

class HowDOGetViewSet(ModelViewSet):
    serializer_class = HowDOGetserializer
    http_method_names = ["get",]
    queryset = HowDoWeGet.objects.all()

    def get(self, request, format=None):
        users = HowDoWeGet.objects.all()
        serializer = HowDOGetserializer(users, many=True)
        return Response(serializer.data)          


@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
class HistoryViewSet(ModelViewSet):
    serializer_class = Historyserializer
    http_method_names = ["post"]

    def get_object(self, queryset=None):
        obj = self.request.user
        return
        