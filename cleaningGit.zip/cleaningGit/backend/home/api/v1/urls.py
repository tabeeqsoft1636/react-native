from django.urls import path, include
from rest_framework.routers import DefaultRouter

from home.api.v1.viewsets import (
    SignupViewSet,
    LoginViewSet,

    ResetViewSet,
    ProfileViewSet,
    ServiceTypeViewSet,
    ExtraTypeViewSet,
    RoomTypeViewSet,
    BathRoomTypeViewSet,
    HowDOGetViewSet,
    HistoryViewSet
    
   

)

router = DefaultRouter()
router.register("signup", SignupViewSet, basename="signup")
router.register("login", LoginViewSet, basename="login")

router.register("reset", ResetViewSet, basename="reset")
router.register("profile", ProfileViewSet, basename="profile")
#router.register("profile/<int:pk>", ProfileViewSet, basename="profile_each")
router.register("service", ServiceTypeViewSet, basename="service")
router.register("extra", ExtraTypeViewSet, basename="extra")
router.register("room", RoomTypeViewSet, basename="room")
router.register("bathroom", BathRoomTypeViewSet, basename="bathroom")
router.register("howdoweget", HowDOGetViewSet, basename="howdoweget")
router.register("history", HistoryViewSet, basename="history")




urlpatterns = [
    path("", include(router.urls)),
]
