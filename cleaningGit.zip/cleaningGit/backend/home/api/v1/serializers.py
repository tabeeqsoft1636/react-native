from django.contrib.auth import get_user_model
from django.http import HttpRequest
from django.utils.translation import ugettext_lazy as _
from allauth.account import app_settings as allauth_settings
from allauth.account.forms import ResetPasswordForm
from allauth.utils import email_address_exists, generate_unique_username
from allauth.account.adapter import get_adapter
from allauth.account.utils import setup_user_email
from rest_framework import serializers
from rest_auth.serializers import PasswordResetSerializer

from users.models import Profile,Service,CleaningType,Extra,Room,BathRoom,HowDoWeGet,History



User = get_user_model()


class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'name', 'email', 'password')
        extra_kwargs = {
            'password': {
                'write_only': True,
                'style': {
                    'input_type': 'password'
                }
            },
            'email': {
                'required': True,
                'allow_blank': False,
            }
        }

    def _get_request(self):
        request = self.context.get('request')
        if request and not isinstance(request, HttpRequest) and hasattr(request, '_request'):
            request = request._request
        return request

    def validate_email(self, email):
        email = get_adapter().clean_email(email)
        if allauth_settings.UNIQUE_EMAIL:
            if email and email_address_exists(email):
                raise serializers.ValidationError(
                    _("A user is already registered with this e-mail address."))
        return email

    def create(self, validated_data):
        user = User(
            email=validated_data.get('email'),
            name=validated_data.get('name'),
            username=generate_unique_username([
                validated_data.get('name'),
                validated_data.get('email'),
                'user'
            ])
        )
        user.set_password(validated_data.get('password'))
        user.save()
        request = self._get_request()
        setup_user_email(request, user, [])
        return user

    def save(self, request=None):
        """rest_auth passes request so we must override to accept it"""
        return super().save()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'name']


# class LoginUserSerializer(serializers.ModelSerializer):
#     cleaning_type_name = serializers.CharField(source='cleaningtype.cleaning_type_name')
#     class Meta:
#         model = User
#         fields = ['id', 'email', 'name']        


class PasswordSerializer(PasswordResetSerializer):
    """Custom serializer for rest_auth to solve reset password error"""
    password_reset_form_class = ResetPasswordForm




#Added for Reset Serializer

class ResetSerializer(serializers.ModelSerializer):
    confirm_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    class Meta:
        model = User
        fields = ['password','confirm_password']
        #fields = '__all__'
        extra_kwargs = {
            'password': {
                'write_only': True,
                'style': {
                    'input_type': 'password'
                }
            },
            
        }

    def _get_request(self):
        request = self.context.get('request')
        if request and not isinstance(request, HttpRequest) and hasattr(request, '_request'):
            request = request._request
        return request

    def validate(self, data):
        '''
        Ensure the passwords are the same
        '''
        if data['password']:
            errors = dict()
            try:
                # validate the password and catch the exception
                validators.validate_password(password=data['password'], user=get_user_model())

                # the exception raised here is different than serializers.ValidationError
            except exceptions.ValidationError as e:
                errors['password'] = list(e.messages)

            if errors:
                raise serializers.ValidationError(errors)
            if data['password'] != data['confirm_password']:
                raise serializers.ValidationError(
                    "The passwords have to be the same"
                )
        return data    

    def get_object(self):
        
        return self.request.user


    def create(self, validated_data):
        # user = get_user_model().objects.get(email=self.get_object)
        # if user:

        #     user.set_password(validated_data.get('password'))
        #     user.save()
        #     request = self._get_request()
        #     setup_user_email(request, user, [])
        #     return user
        user = User(password=validated_data.get('password'))
        #user =  self.request.user
        user.set_password(validated_data.get('password'))
        user.save()
        request = self._get_request()
        setup_user_email(request, user, [])
        return user    

    def save(self, request=None):
        """rest_auth passes request so we must override to accept it"""
        return super().save()


#Added As a Profile Serializer
class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = '__all__' 

    def validate_zip_code(self, zip_code):
        
        _zip_code = zip_code[:2]
        
        if _zip_code!= '60':
            raise serializers.ValidationError(
                {'error':"ZIP Code Only For Chicago."})
        return zip_code    
       

    


#Added As a Service Serializer
class ServiceSerializer(serializers.ModelSerializer):
    cleaning_type_name = serializers.CharField(source='cleaningtype.cleaning_type_name')
    #service_type_name = serializers.CharField(source='servicetype.service_type_name')
    class Meta:
        model = Service
        fields = ('id','service_name','cleaning_type_name',)       
         

# class ServiceTypeSerializer(serializers.ModelSerializer):
#     cleaning_type = serializers.CharField(source='cleaning_type.cleaning_type_name')
    
#     class Meta:
#         model = ServiceType
#         fields = '__all__'


class CleaningTypeSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = CleaningType
        fields = '__all__'  

class ServiceSerializer(serializers.ModelSerializer):
    cleaning_type = serializers.CharField(source='cleaning_type.cleaning_type_name')
    # service_objects = CleaningTypeSerializer(many = True, read_only = True)
    # service_types = serializers.SerializerMethodField()
    
    class Meta:
        model = Service
        fields = ('id', 'cleaning_type','service_name')
   
    # def get_service_types(self, obj):
    #     return list(obj.service_types.values_list('cleaning_type').distinct())

    
class ExtraSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Extra
        fields = '__all__'  

class RoomSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Room
        fields = '__all__'      

class BathRoomSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = BathRoom
        fields = '__all__'       





class HowDOGetserializer(serializers.ModelSerializer):
    class Meta:
        model = HowDoWeGet
        fields = '__all__'                


class Historyserializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(read_only=True, default=serializers.CurrentUserDefault())
    class Meta:
        model = History
        fields = '__all__'  


    def save(self, **kwargs):
        """Include default for read_only `user` field"""
        kwargs["user"] = self.fields["user"].get_default()
        return super().save(**kwargs)
